package com.urs.pifdamesa;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * Servidor da mesa, sem dependências (roda igual no Android e no Java do PC).
 *
 * Ele guarda cada sala como um JSON com número de versão. As regras do Pif rodam
 * no navegador de quem age: o navegador lê a sala, aplica a ação e devolve a sala
 * nova dizendo qual versão leu. Se outra pessoa salvou antes, o servidor recusa
 * (409) e o navegador refaz a ação em cima da versão nova. Assim duas ações ao
 * mesmo tempo nunca apagam uma à outra.
 */
public final class PifServer {
    public interface PageSource {
        byte[] page() throws IOException;
    }

    private static final Pattern CODE = Pattern.compile("^[2-9A-HJ-NP-Z]{8}$");
    private static final int MAX_BODY = 2 * 1024 * 1024;
    private static final long LONG_POLL_MS = 20000;
    private static final int LIST_LIMIT = 30;

    private final File roomsDir;
    private final PageSource pages;
    private final int port;
    private final Map<String, String> rooms = new HashMap<>();
    private final Map<String, Long> versions = new HashMap<>();
    private final Map<String, Long> touched = new HashMap<>();
    private final Object lock = new Object();
    private ServerSocket serverSocket;
    private ExecutorService pool;
    private volatile boolean running;

    public PifServer(File dataDir, PageSource pages, int port) {
        this.roomsDir = new File(dataDir, "rooms");
        this.pages = pages;
        this.port = port;
    }

    public int port() {
        return port;
    }

    public boolean isRunning() {
        return running;
    }

    public synchronized void start() throws IOException {
        if (running) return;
        loadRooms();
        ServerSocket socket = new ServerSocket();
        socket.setReuseAddress(true);
        socket.bind(new InetSocketAddress("0.0.0.0", port));
        serverSocket = socket;
        pool = new ThreadPoolExecutor(4, 64, 30, TimeUnit.SECONDS, new SynchronousQueue<>(), new ThreadPoolExecutor.CallerRunsPolicy());
        running = true;
        Thread acceptor = new Thread(this::acceptLoop, "pif-accept");
        acceptor.setDaemon(true);
        acceptor.start();
    }

    public synchronized void stop() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {
            // já fechado
        }
        if (pool != null) pool.shutdownNow();
        synchronized (lock) {
            lock.notifyAll();
        }
    }

    /** IPs da rede local (Wi-Fi ou roteador do celular) onde os amigos podem abrir o link. */
    public static List<String> lanAddresses() {
        List<String> preferred = new ArrayList<>();
        List<String> others = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return preferred;
            for (NetworkInterface item : Collections.list(interfaces)) {
                if (!item.isUp() || item.isLoopback()) continue;
                String name = item.getName().toLowerCase(Locale.ROOT);
                boolean cellular = name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("pdp") || name.startsWith("v4-");
                if (cellular) continue;
                for (InetAddress address : Collections.list(item.getInetAddresses())) {
                    if (!(address instanceof Inet4Address) || !address.isSiteLocalAddress()) continue;
                    String ip = address.getHostAddress();
                    boolean wifi = name.startsWith("wlan") || name.startsWith("swlan") || name.startsWith("ap") || name.startsWith("softap") || name.startsWith("eth");
                    (wifi ? preferred : others).add(ip);
                }
            }
        } catch (SocketException ignored) {
            // sem rede
        }
        preferred.addAll(others);
        return preferred;
    }

    // ---------------------------------------------------------------- dados

    private void loadRooms() {
        roomsDir.mkdirs();
        File[] files = roomsDir.listFiles((dir, name) -> name.endsWith(".json"));
        if (files == null) return;
        synchronized (lock) {
            for (File file : files) {
                String code = file.getName().substring(0, file.getName().length() - 5);
                if (!CODE.matcher(code).matches()) continue;
                try {
                    rooms.put(code, new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
                    versions.put(code, 1L);
                    touched.put(code, file.lastModified());
                } catch (IOException ignored) {
                    // arquivo ilegível: ignora
                }
            }
        }
    }

    private void persist(String code, String json) {
        File target = new File(roomsDir, code + ".json");
        File temp = new File(roomsDir, code + ".json.tmp");
        try (FileOutputStream out = new FileOutputStream(temp)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (IOException error) {
            return;
        }
        if (!temp.renameTo(target)) {
            target.delete();
            temp.renameTo(target);
        }
    }

    // ---------------------------------------------------------------- http

    private void acceptLoop() {
        while (running) {
            try {
                Socket client = serverSocket.accept();
                pool.execute(() -> handle(client));
            } catch (IOException error) {
                if (!running) return;
            } catch (RuntimeException error) {
                if (!running) return;
            }
        }
    }

    private static final class Request {
        String method;
        String path;
        Map<String, String> query = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        byte[] body = new byte[0];
    }

    private void handle(Socket client) {
        try (Socket socket = client) {
            socket.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(socket.getInputStream());
            OutputStream out = socket.getOutputStream();
            Request request = read(in);
            if (request == null) return;
            route(request, out);
        } catch (IOException | RuntimeException ignored) {
            // conexão caiu
        }
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream line = new ByteArrayOutputStream();
        int previous = -1;
        while (true) {
            int value = in.read();
            if (value == -1) return line.size() == 0 && previous == -1 ? null : line.toString("UTF-8");
            if (value == '\n') {
                String text = line.toString("UTF-8");
                return text.endsWith("\r") ? text.substring(0, text.length() - 1) : text;
            }
            line.write(value);
            previous = value;
            if (line.size() > 16384) throw new IOException("linha muito longa");
        }
    }

    private static Request read(InputStream in) throws IOException {
        String first = readLine(in);
        if (first == null || first.isEmpty()) return null;
        String[] parts = first.split(" ");
        if (parts.length < 2) return null;
        Request request = new Request();
        request.method = parts[0].toUpperCase(Locale.ROOT);
        String target = parts[1];
        int question = target.indexOf('?');
        request.path = question >= 0 ? target.substring(0, question) : target;
        if (question >= 0) {
            for (String pair : target.substring(question + 1).split("&")) {
                int equals = pair.indexOf('=');
                if (equals > 0) request.query.put(decode(pair.substring(0, equals)), decode(pair.substring(equals + 1)));
            }
        }
        String header;
        int count = 0;
        while ((header = readLine(in)) != null && !header.isEmpty()) {
            int colon = header.indexOf(':');
            if (colon > 0) request.headers.put(header.substring(0, colon).trim().toLowerCase(Locale.ROOT), header.substring(colon + 1).trim());
            if (++count > 100) throw new IOException("cabeçalhos demais");
        }
        String length = request.headers.get("content-length");
        if (length != null) {
            int size = Integer.parseInt(length.trim());
            if (size < 0 || size > MAX_BODY) throw new IOException("corpo grande demais");
            byte[] body = new byte[size];
            int offset = 0;
            while (offset < size) {
                int got = in.read(body, offset, size - offset);
                if (got == -1) throw new IOException("corpo incompleto");
                offset += got;
            }
            request.body = body;
        }
        return request;
    }

    private static String decode(String value) {
        try {
            return URLDecoder.decode(value, "UTF-8");
        } catch (Exception error) {
            return value;
        }
    }

    private static void send(OutputStream out, int status, String type, byte[] body) throws IOException {
        String reason = status == 200 ? "OK" : status == 201 ? "Created" : status == 404 ? "Not Found" : status == 409 ? "Conflict" : status == 400 ? "Bad Request" : status == 405 ? "Method Not Allowed" : "Error";
        String head = "HTTP/1.1 " + status + " " + reason + "\r\n"
            + "Content-Type: " + type + "\r\n"
            + "Content-Length: " + body.length + "\r\n"
            + "Cache-Control: no-store\r\n"
            + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }

    private static void json(OutputStream out, int status, String body) throws IOException {
        send(out, status, "application/json; charset=utf-8", body.getBytes(StandardCharsets.UTF_8));
    }

    private static String quote(String text) {
        StringBuilder builder = new StringBuilder("\"");
        for (char c : text.toCharArray()) {
            if (c == '"' || c == '\\') builder.append('\\').append(c);
            else if (c < 0x20) builder.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
            else builder.append(c);
        }
        return builder.append('"').toString();
    }

    private static String error(String message) {
        return "{\"error\":" + quote(message) + "}";
    }

    private static long number(String value, long fallback) {
        try {
            return value == null ? fallback : Long.parseLong(value);
        } catch (NumberFormatException error) {
            return fallback;
        }
    }

    private void route(Request request, OutputStream out) throws IOException {
        String path = request.path;
        if (path.equals("/") || path.equals("/index.html")) {
            if (!request.method.equals("GET") && !request.method.equals("HEAD")) {
                json(out, 405, error("Método não permitido."));
                return;
            }
            send(out, 200, "text/html; charset=utf-8", pages.page());
            return;
        }
        if (path.equals("/api/health")) {
            json(out, 200, "{\"status\":\"ok\"}");
            return;
        }
        if (path.equals("/api/info")) {
            StringBuilder list = new StringBuilder("[");
            for (String ip : lanAddresses()) {
                if (list.length() > 1) list.append(',');
                list.append(quote(ip));
            }
            json(out, 200, "{\"addresses\":" + list.append(']') + ",\"port\":" + port + "}");
            return;
        }
        if (path.equals("/api/rooms") && request.method.equals("GET")) {
            listRooms(out);
            return;
        }
        if (path.startsWith("/api/rooms/")) {
            String code = path.substring("/api/rooms/".length()).toUpperCase(Locale.ROOT);
            if (!CODE.matcher(code).matches()) {
                json(out, 400, error("Código de sala inválido."));
                return;
            }
            if (request.method.equals("GET")) {
                getRoom(code, number(request.query.get("since"), -1), out);
                return;
            }
            if (request.method.equals("PUT") || request.method.equals("POST")) {
                putRoom(code, number(request.query.get("expect"), -1), request.body, out);
                return;
            }
            json(out, 405, error("Método não permitido."));
            return;
        }
        json(out, 404, error("Endereço não encontrado."));
    }

    private void listRooms(OutputStream out) throws IOException {
        StringBuilder body = new StringBuilder("[");
        synchronized (lock) {
            List<String> codes = new ArrayList<>(rooms.keySet());
            codes.sort((a, b) -> Long.compare(touched.getOrDefault(b, 0L), touched.getOrDefault(a, 0L)));
            int count = 0;
            for (String code : codes) {
                if (count++ >= LIST_LIMIT) break;
                if (body.length() > 1) body.append(',');
                body.append(rooms.get(code));
            }
        }
        json(out, 200, body.append(']').toString());
    }

    private void getRoom(String code, long since, OutputStream out) throws IOException {
        String room;
        long version;
        synchronized (lock) {
            long deadline = System.currentTimeMillis() + LONG_POLL_MS;
            while (running && rooms.containsKey(code) && since >= 0 && versions.get(code) <= since) {
                long left = deadline - System.currentTimeMillis();
                if (left <= 0) break;
                try {
                    lock.wait(left);
                } catch (InterruptedException error) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            room = rooms.get(code);
            version = versions.getOrDefault(code, 0L);
        }
        if (room == null) {
            json(out, 404, error("Não encontramos essa mesa. Confira o código do convite."));
            return;
        }
        json(out, 200, "{\"version\":" + version + ",\"room\":" + room + "}");
    }

    private void putRoom(String code, long expect, byte[] bytes, OutputStream out) throws IOException {
        String body = new String(bytes, StandardCharsets.UTF_8).trim();
        if (!body.startsWith("{") || !body.endsWith("}")) {
            json(out, 400, error("Dados da mesa inválidos."));
            return;
        }
        long version;
        synchronized (lock) {
            long current = versions.getOrDefault(code, 0L);
            if (expect != current) {
                String room = rooms.get(code);
                json(out, 409, "{\"version\":" + current + ",\"room\":" + (room == null ? "null" : room) + "}");
                return;
            }
            version = current + 1;
            rooms.put(code, body);
            versions.put(code, version);
            touched.put(code, System.currentTimeMillis());
            persist(code, body);
            lock.notifyAll();
        }
        json(out, expect == 0 ? 201 : 200, "{\"version\":" + version + "}");
    }

    /** Para testar no PC: java PifServer.java pasta-de-dados pagina.html [porta] */
    public static void main(String[] args) throws Exception {
        File page = new File(args[1]);
        PifServer server = new PifServer(new File(args[0]), () -> Files.readAllBytes(page.toPath()), args.length > 2 ? Integer.parseInt(args[2]) : 8080);
        server.start();
        System.out.println("Pif da Mesa ouvindo na porta " + server.port() + " " + lanAddresses());
        Thread.currentThread().join();
    }
}
