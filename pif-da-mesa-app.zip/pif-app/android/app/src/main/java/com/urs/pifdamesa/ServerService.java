package com.urs.pifdamesa;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Mantém o servidor da mesa ligado enquanto o app está aberto (inclusive com a tela
 * apagada) e mostra uma notificação com o link e o botão "Desligar".
 * Fechar o app ou tirar ele da lista de recentes desliga tudo.
 */
public class ServerService extends Service {
    private static final String CHANNEL_ID = "mesa";
    private static final int NOTIFICATION_ID = 1;
    private static final int FIRST_PORT = 8080;

    private static PifServer server;
    private static byte[] pageCache;

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    /** Liga o servidor (se ainda não estiver ligado). Chamar fora da thread principal. */
    public static synchronized PifServer ensureServer(Context context) throws IOException {
        if (server != null && server.isRunning()) return server;
        final Context app = context.getApplicationContext();
        IOException last = null;
        for (int port = FIRST_PORT; port < FIRST_PORT + 10; port++) {
            PifServer candidate = new PifServer(app.getFilesDir(), () -> page(app), port);
            try {
                candidate.start();
                server = candidate;
                return server;
            } catch (IOException error) {
                last = error;
            }
        }
        throw last != null ? last : new IOException("Nenhuma porta livre");
    }

    public static synchronized PifServer current() {
        return server;
    }

    private static synchronized void shutdownServer() {
        if (server != null) server.stop();
        server = null;
    }

    private static synchronized byte[] page(Context context) throws IOException {
        if (pageCache != null) return pageCache;
        try (InputStream in = context.getAssets().open("www/index.html")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[16384];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            pageCache = out.toByteArray();
            return pageCache;
        }
    }

    public static String link() {
        PifServer running = current();
        if (running == null) return null;
        List<String> addresses = PifServer.lanAddresses();
        return addresses.isEmpty() ? null : "http://" + addresses.get(0) + ":" + running.port();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Mesa ligada", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Aparece enquanto a mesa de Pif está ligada neste celular.");
        manager.createNotificationChannel(channel);

        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        PowerManager power = getSystemService(PowerManager.class);
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PifDaMesa:servidor");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(6 * 60 * 60 * 1000L);
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifi != null) {
            wifiLock = wifi.createWifiLock(Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "PifDaMesa:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        }

        new Thread(() -> {
            try {
                ensureServer(this);
                getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification());
            } catch (IOException ignored) {
                // a tela principal mostra o erro
            }
        }, "pif-start").start();
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openIntent = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(MainActivity.EXTRA_SHUTDOWN, true);
        PendingIntent stopIntent = PendingIntent.getActivity(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String link = link();
        return new Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Mesa de Pif ligada")
            .setContentText(link != null ? "Link para os amigos: " + link : "Ligue o roteador do celular ou um Wi-Fi para os amigos entrarem")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(null, "Desligar", stopIntent).build())
            .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Tirou o app dos recentes: desliga a mesa.
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        shutdownServer();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
