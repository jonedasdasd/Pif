package com.urs.pifdamesa;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

/**
 * Tela do app: liga o servidor, abre a mesa numa WebView e desliga tudo ao sair.
 */
public class MainActivity extends Activity {
    public static final String EXTRA_SHUTDOWN = "shutdown";

    private WebView webView;
    private boolean shuttingDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent().getBooleanExtra(EXTRA_SHUTDOWN, false)) {
            shutdown();
            return;
        }
        getWindow().setStatusBarColor(Color.parseColor("#1B402D"));

        TextView loading = new TextView(this);
        loading.setText("Ligando a mesa...");
        loading.setGravity(Gravity.CENTER);
        loading.setTextSize(18);
        loading.setTextColor(Color.parseColor("#202C24"));
        loading.setBackgroundColor(Color.parseColor("#F4F5F1"));
        setContentView(loading);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 1);
        }

        startForegroundService(new Intent(this, ServerService.class));

        new Thread(() -> {
            try {
                PifServer server = ServerService.ensureServer(this);
                runOnUiThread(() -> showTable(server.port()));
            } catch (Exception error) {
                runOnUiThread(() -> loading.setText("Não foi possível ligar a mesa.\n" + error.getMessage()));
            }
        }, "pif-open").start();
    }

    private void showTable(int port) {
        if (shuttingDown || isFinishing()) return;
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#F4F5F1"));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("http://127.0.0.1:" + port + "/");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getBooleanExtra(EXTRA_SHUTDOWN, false)) shutdown();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("Desligar a mesa?")
            .setMessage("Os amigos vão perder a conexão. As partidas ficam salvas neste celular.")
            .setPositiveButton("Desligar", (dialog, which) -> shutdown())
            .setNegativeButton("Continuar jogando", null)
            .show();
    }

    private void shutdown() {
        if (shuttingDown) return;
        shuttingDown = true;
        stopService(new Intent(this, ServerService.class));
        finishAndRemoveTask();
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) stopService(new Intent(this, ServerService.class));
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
