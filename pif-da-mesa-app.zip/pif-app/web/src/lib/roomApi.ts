// Camada de dados: conversa com o servidor que roda dentro do app no celular do anfitrião.
import { applyAction, makeCode, newRoom, uuid, type Action } from './engine'

export type Player = { id: string; userId?: string; name: string; inGame: boolean; joinedAt: string; leftAt: string | null }
export type Round = {
  id: string
  number: number
  winnerId?: string
  winnerName?: string
  playerIds?: string[]
  firstPlayerId?: string
  foldedPlayerIds?: string[]
  doubledByPlayerIds?: string[]
  value: number
  createdAt: string
  correctedAt?: string
  startedAt?: string
  announcedAt?: string
}
export type Entry = { id: string; playerId: string; playerName: string; description: string; amount: number; createdAt: string }
export type Transfer = { fromPlayerId: string; from: string; toPlayerId: string; to: string; amount: number }
export type Activity = { id: string; type: string; message: string; actor: string; details: Record<string, unknown>; createdAt: string }
export type Room = {
  id: string
  code: string
  name: string
  hostUserId: string
  ownerPlayerId: string
  nextOpenerId: string | null
  roundNumber: number
  status: 'waiting' | 'playing' | 'finished'
  createdAt: string
  startedAt: string | null
  finishedAt: string | null
  players: Player[]
  rounds: Round[]
  activeRound: {
    number: number
    phase: 'dealing' | 'announcing' | 'responding' | 'playing'
    value: number | null
    firstPlayerId: string
    playerIds: string[]
    startedAt: string
    announcedAt?: string
    cardConfirmations: string[]
    responses: Record<string, 'play' | 'fold' | 'pending'>
    playingPlayerIds: string[]
    foldedPlayerIds: string[]
    cancelVotes: string[]
    doubledByPlayerIds: string[]
    redealCount: number
    lastDealError: { playerId: string; playerName: string; count: number; createdAt: string } | null
  } | null
  entries: Entry[]
  activity: Activity[]
  finalReport: { transfers: Transfer[]; balances: { playerId: string; playerName: string; amount: number }[] } | null
}

export type RoomSummary = { code: string; name: string; status: Room['status']; createdAt: string; players: number; host: string }

export type Platform = { userId: string }
export type PlatformResult = { ok: true; platform: Platform } | { ok: false; reason: 'no-claude' | 'signed-out' }

// Cada aparelho ganha um id aleatório guardado no navegador; é ele que diz qual
// participante da mesa é "você" neste celular.
function deviceId() {
  const key = 'pif-device-id'
  try {
    const saved = localStorage.getItem(key)
    if (saved) return saved
    const created = uuid()
    localStorage.setItem(key, created)
    return created
  } catch {
    return uuid()
  }
}

let platform: Platform | null = null
export async function connect(): Promise<PlatformResult> {
  platform ??= { userId: deviceId() }
  return { ok: true, platform }
}

const sleep = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms))
const roomUrl = (code: string) => `/api/rooms/${encodeURIComponent(code.toUpperCase())}`

async function fetchJson(url: string, init?: RequestInit) {
  let response: Response
  try {
    response = await fetch(url, init)
  } catch {
    throw new Error('Sem conexão com o celular do anfitrião. Confira se você está no Wi-Fi/roteador dele e se o app está aberto.')
  }
  let data: unknown = null
  try {
    data = await response.json()
  } catch {
    // corpo vazio
  }
  return { status: response.status, data: data as Record<string, unknown> | null }
}

async function readRoom(code: string): Promise<{ version: number; room: Room }> {
  const { status, data } = await fetchJson(roomUrl(code))
  if (status === 404) throw new Error('Não encontramos essa mesa. Confira o código do convite.')
  if (status !== 200 || !data) throw new Error('Não foi possível ler a mesa. Tente de novo.')
  return { version: Number(data.version), room: data.room as Room }
}

export function subscribeRoom(_platform: Platform, code: string, onRoom: (room: Room | null) => void, onError: (message: string) => void) {
  let active = true
  let failures = 0
  void (async () => {
    let since = -1
    while (active) {
      try {
        const { status, data } = await fetchJson(`${roomUrl(code)}?since=${since}`)
        if (!active) return
        if (status === 404) {
          onRoom(null)
          return
        }
        if (status === 200 && data) {
          failures = 0
          const version = Number(data.version)
          if (version !== since) {
            since = version
            onRoom(data.room as Room)
          }
          continue
        }
        throw new Error('Resposta inesperada do celular do anfitrião.')
      } catch (error) {
        if (!active) return
        failures += 1
        if (failures === 3) onError(error instanceof Error ? error.message : 'Conexão perdida com a mesa.')
        await sleep(Math.min(5000, 800 * failures))
      }
    }
  })()
  return () => { active = false }
}

export function subscribeRoomList(_platform: Platform, onList: (rooms: RoomSummary[]) => void) {
  let active = true
  void (async () => {
    while (active) {
      try {
        const { status, data } = await fetchJson('/api/rooms')
        if (active && status === 200 && Array.isArray(data)) {
          const rooms = (data as unknown as Room[]).filter((room) => room && room.code && room.players)
          rooms.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
          onList(rooms.map((room) => ({
            code: room.code,
            name: room.name,
            status: room.status,
            createdAt: room.createdAt,
            players: room.players.filter((player) => player.inGame).length,
            host: room.players.find((player) => player.id === room.ownerPlayerId)?.name ?? '',
          })))
        }
      } catch {
        // tenta de novo no próximo ciclo
      }
      await sleep(4000)
    }
  })()
  return () => { active = false }
}

export async function createRoom(current: Platform, name: string, playerName: string) {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const room = newRoom(name, playerName, current.userId, makeCode())
    const { status } = await fetchJson(`${roomUrl(room.code)}?expect=0`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(room) })
    if (status === 201) return room
    if (status !== 409) throw new Error('Não foi possível criar a mesa. Tente de novo.')
  }
  throw new Error('Não foi possível gerar um código de sala. Tente de novo.')
}

/** Lê a versão atual, aplica a ação e grava; se alguém salvou antes, refaz em cima da versão nova. */
export async function mutateRoom(current: Platform, code: string, action: Action): Promise<Room> {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const { version, room } = await readRoom(code)
    const updated = applyAction(room, action, current.userId)
    const { status } = await fetchJson(`${roomUrl(code)}?expect=${version}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updated) })
    if (status === 200) return updated
    if (status !== 409) throw new Error('Não foi possível salvar. Tente de novo.')
    await sleep(60 + Math.random() * 140)
  }
  throw new Error('A mesa está movimentada demais agora. Tente de novo.')
}
