import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { viteSingleFile } from 'vite-plugin-singlefile'

// Gera um único HTML com JS e CSS embutidos, para publicar como página no Claude.
export default defineConfig({
  plugins: [react(), viteSingleFile()],
})
