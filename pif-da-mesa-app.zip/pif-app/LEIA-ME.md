# Pif da Mesa — app Android

O app transforma o celular do anfitrião no servidor da mesa:

- **Abriu o app:** a mesa liga sozinha e aparece o link e o QR code para os amigos.
- **Os amigos** abrem o link no navegador do celular, digitam o nome e jogam. Ninguém precisa de conta nem de instalar nada.
- **Você** joga pela própria tela do app.
- **Fechou o app** (botão voltar → "Desligar", botão "Desligar" na notificação, ou tirou o app dos recentes): tudo desliga.

As partidas e o histórico ficam salvos no celular e continuam lá na próxima vez que você abrir o app.

**Importante:** os amigos precisam estar na mesma rede que o seu celular. O jeito mais fácil é ligar o **roteador do celular** (hotspot) e todo mundo se conectar nele. Quem estiver usando os próprios dados móveis (4G/5G) não consegue entrar.

---

## 1. Gerar o APK (uma vez só, pelo GitHub)

1. Crie uma conta grátis em https://github.com e clique em **New repository**. Dê um nome (ex.: `pif-da-mesa`), deixe **Private** e clique em **Create repository**.
2. Na página do repositório, clique em **uploading an existing file**.
3. Descompacte o `pif-da-mesa-app.zip` no computador, abra a pasta `pif-app` e **arraste tudo o que está dentro dela** para a página (as pastas `android`, `web`, `.github` e os arquivos). Clique em **Commit changes**.
   - Se a pasta `.github` não aparecer (ela pode estar oculta), crie o arquivo à mão: **Add file → Create new file**, digite o nome `.github/workflows/gerar-apk.yml` e cole o conteúdo do arquivo `gerar-apk.yml` que está no zip.
4. Abra a aba **Actions**. Vai aparecer **Gerar APK** rodando (bolinha amarela). Espere uns 5 a 10 minutos até ficar verde ✓.
   - Se ficar vermelho ✗, clique nele, abra o passo que falhou e mande um print pro Claude.
5. Clique na execução verde e, lá embaixo em **Artifacts**, baixe **PifDaMesa-apk**. Vem um `.zip` com o arquivo `app-debug.apk` dentro.

## 2. Instalar no celular

1. Passe o `app-debug.apk` para o celular (ou baixe direto pelo navegador do celular, logado no GitHub) e toque nele.
2. O Android vai pedir para **permitir instalar apps desta fonte**: permita.
3. Se o Play Protect avisar que o app é desconhecido, toque em **Mais detalhes → Instalar assim mesmo**. Isso acontece com todo app que não veio da Play Store.
4. Na primeira vez, permita as **notificações**. É a notificação que mantém a mesa ligada com a tela apagada.
5. Samsung: em **Configurações → Aplicativos → Pif da Mesa → Bateria**, escolha **Sem restrições**. Assim o Android não desliga a mesa no meio da partida.

## 3. Jogar

1. Ligue o **roteador do celular** (hotspot) e peça para os amigos se conectarem.
2. Abra o **Pif da Mesa**. O link e o QR code aparecem no topo.
3. Crie a sala. Os amigos leem o QR code com a câmera (ou abrem o link) e entram com o nome.
4. Se alguém trocar de celular ou fechar o navegador, é só abrir o link de novo e digitar o mesmo nome: a pessoa volta pro lugar dela (isso fica anotado no histórico).
5. No fim, use **Encerrar para todos**. Depois volte e toque em **Desligar**.

Se o QR code não abrir nos celulares dos amigos, confira se eles estão mesmo no seu hotspot. Alguns aparelhos isolam quem está no hotspot; nesse caso use um roteador Wi-Fi comum, com todo mundo na mesma rede.

---

## Para quem mexe no código

- `web/` — interface React (a mesma do Pif da Mesa). As regras do jogo ficam em `web/src/lib/engine.ts` e rodam no navegador de quem age. `npm run build` gera um único `dist/index.html`.
- `android/app/src/main/java/com/urs/pifdamesa/PifServer.java` — servidor HTTP sem dependências. Guarda cada sala como JSON com número de versão e recusa (409) quem tentar salvar em cima de uma versão antiga; o navegador então refaz a ação. Também roda no PC para testar: `javac -d out PifServer.java && java -cp out com.urs.pifdamesa.PifServer dados web/dist/index.html 8080`.
- `ServerService.java` — mantém o servidor ligado (serviço em primeiro plano, trava de Wi-Fi e de CPU) e mostra a notificação com o link e o botão Desligar.
- `MainActivity.java` — liga o servidor, abre a mesa numa WebView e desliga tudo ao sair.
- `.github/workflows/gerar-apk.yml` — compila a interface, coloca dentro do app e gera o APK.
