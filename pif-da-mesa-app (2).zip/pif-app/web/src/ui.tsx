// Peças usadas em várias telas: confirmação, brilho na sua vez, ajuda e tela de abertura.
import { useEffect, useState, type ReactNode } from 'react'
import { CircleHelp, Spade, X } from 'lucide-react'
import { getLook } from './lib/settings'

// ------------------------------------------------------------------ confirmação ("Tem certeza?")

type Ask = { title: string; message: ReactNode; confirm: string; danger?: boolean; resolve: (ok: boolean) => void }
let showAsk: ((ask: Ask | null) => void) | null = null

/** Pergunta antes de uma jogada importante. Se a opção estiver desligada, segue direto. */
export function askConfirm(title: string, message: ReactNode, confirm = 'Confirmar', danger = false): Promise<boolean> {
  if (!getLook().confirm || !showAsk) return Promise.resolve(true)
  return new Promise((resolve) => showAsk?.({ title, message, confirm, danger, resolve }))
}

export function ConfirmHost() {
  const [ask, setAsk] = useState<Ask | null>(null)
  useEffect(() => {
    showAsk = setAsk
    return () => { showAsk = null }
  }, [])
  if (!ask) return null
  const close = (ok: boolean) => {
    ask.resolve(ok)
    setAsk(null)
  }
  return <div className="modal-backdrop confirm-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) close(false) }}>
    <section className="modal confirm-modal" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title">
      <h2 id="confirm-title">{ask.title}</h2>
      <div className="confirm-message">{ask.message}</div>
      <div className="confirm-actions">
        <button type="button" className="button button-secondary" onClick={() => close(false)}>Voltar</button>
        <button type="button" className={`button ${ask.danger ? 'button-danger' : 'button-primary'}`} onClick={() => close(true)} autoFocus>{ask.confirm}</button>
      </div>
      <p className="form-hint">Dá para desligar essa pergunta em Configurações.</p>
    </section>
  </div>
}

// ------------------------------------------------------------------ brilho na borda quando chega a sua vez

export function TurnFlash({ turnKey }: { turnKey: string }) {
  const [shown, setShown] = useState('')
  useEffect(() => {
    if (!turnKey || !getLook().turnFlash) return
    setShown(turnKey)
    const timer = window.setTimeout(() => setShown(''), 1400)
    return () => window.clearTimeout(timer)
  }, [turnKey])
  return shown ? <div className="turn-flash" key={shown} aria-hidden="true" /> : null
}

// ------------------------------------------------------------------ ajuda dentro do app

export type HelpTopic = 'inicio' | 'mesa' | 'treino' | 'treino-jogo' | 'configuracoes' | 'historico' | 'virtual'

const HELP: Record<HelpTopic, { title: string; items: [string, string][] }> = {
  inicio: {
    title: 'Tela inicial',
    items: [
      ['Criar sala', 'Abre uma mesa para os amigos entrarem pelo link ou QR code. Todos precisam estar no seu Wi-Fi ou no roteador do seu celular.'],
      ['Mesa rápida', 'Cria a sala com o último nome de mesa e o seu nome, num toque só.'],
      ['Cartas', 'Físicas: vocês jogam com baralho de verdade e o app marca as rodadas. Virtuais: cada um joga no próprio celular, sem baralho.'],
      ['Modo solo', 'Os amigos não precisam entrar: você digita o nome de cada um e marca tudo.'],
      ['PIN', 'Um código de 4 números que os amigos digitam para entrar. Evita gente de fora.'],
      ['Treinar com cartas', 'Pif com cartas de verdade contra robôs ou sozinho, sem dinheiro.'],
      ['Histórico geral', 'Quem ganhou e perdeu somando todas as partidas, a caderneta de dívidas e a planilha.'],
    ],
  },
  mesa: {
    title: 'Na mesa',
    items: [
      ['Começar rodada', 'O anfitrião ou quem abre toca para começar. Entram todos que estão na mesa.'],
      ['Anunciar', 'Quem abre diz o valor por pessoa. Quem anunciou não pode dobrar.'],
      ['Jogar, sair ou dobrar', 'Os outros decidem. Quem sai antes do jogo não paga nada. Cada um pode dobrar uma vez.'],
      ['Registrar quem bateu', 'O anfitrião marca o vencedor. Os saldos mudam na hora.'],
      ['Cancelar', 'A maioria de quem está jogando pode cancelar a mão sem mexer nos saldos.'],
      ['Sair', 'Para jogador, a mesa acaba só para ele (o saldo fica salvo). Para o anfitrião, acaba para todos.'],
      ['Visual', 'O botão de quadradinhos troca entre o layout Clássico e o Mesa.'],
    ],
  },
  treino: {
    title: 'Treino',
    items: [
      ['Tutorial', 'Uma partida guiada que ensina passo a passo.'],
      ['Desafio do dia', 'A mesma mão para todo mundo hoje, com meta de compras.'],
      ['Dificuldade', 'Fácil, normal, difícil (lembra o que já saiu) e mestre (o mais forte).'],
      ['Conquistas', 'Medalhas que você ganha jogando. Veja quais faltam lá embaixo.'],
      ['Modo aula', 'As cartas dos robôs ficam abertas para aprender. Não conta nas estatísticas.'],
    ],
  },
  'treino-jogo': {
    title: 'Jogando',
    items: [
      ['Comprar', 'Toque no monte ou no lixo, ou arraste a carta até a sua mão.'],
      ['Descartar', 'Toque na carta e depois no lixo, arraste até o lixo, ou toque duas vezes rápido na carta.'],
      ['Organizar', 'Arraste as cartas na mão, ou use Por jogos, Naipe e Número.'],
      ['Bater', 'Quando 9 cartas formam 3 jogos. Se alguém descartar a carta que você espera, aparece BATER com a carta.'],
      ['Dica', 'Verde: já forma jogo. Amarelo: sugestão de descarte. Pifado: as cartas que fazem você bater.'],
      ['Sair', 'A partida fica salva para continuar depois.'],
    ],
  },
  configuracoes: {
    title: 'Configurações',
    items: [
      ['Neste celular', 'Visual, tema, letra maior, uma mão, confirmações e avisos valem só para este aparelho.'],
      ['Da mesa', 'Valor padrão, Pix, enviar imagem e estatísticas valem para todos (só no celular do anfitrião).'],
      ['Backup', 'Guarde um arquivo com todo o histórico antes de trocar de celular.'],
    ],
  },
  historico: {
    title: 'Histórico geral',
    items: [
      ['Quem ganhou e perdeu', 'Soma de todas as partidas encerradas. Toque num nome para ver as partidas dele.'],
      ['Caderneta', 'O que ficou devendo de cada noite. Marque como pago quando acertarem.'],
      ['Planilha', 'Exporta tudo para abrir no Excel ou Google Planilhas.'],
      ['Apagar', 'Só no celular do anfitrião, para limpar mesas de teste.'],
    ],
  },
  virtual: {
    title: 'Cartas virtuais',
    items: [
      ['Como funciona', 'Cada um vê só as próprias cartas no celular. O anfitrião toca em Distribuir para começar cada mão.'],
      ['Valor', 'Quem bate recebe o valor combinado de cada um que estava na mão. Entra no saldo e no histórico.'],
      ['Bater com o descarte', 'Se alguém jogar a carta que você espera, toque em BATER durante a contagem. Se dois baterem, ganha o próximo da vez.'],
    ],
  },
}

export function HelpButton({ topic, label = false }: { topic: HelpTopic; label?: boolean }) {
  const [open, setOpen] = useState(false)
  const help = HELP[topic]
  return <>
    <button type="button" className="help-button" onClick={() => setOpen(true)} aria-label={`Ajuda: ${help.title}`}><CircleHelp size={16} />{label && <span>Ajuda</span>}</button>
    {open && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setOpen(false) }}>
      <section className="modal help-modal" role="dialog" aria-modal="true" aria-labelledby="help-title">
        <div className="modal-heading"><div><span className="section-kicker">AJUDA</span><h2 id="help-title">{help.title}</h2></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Fechar"><X size={19} /></button></div>
        <dl className="help-list">{help.items.map(([term, text]) => <div key={term}><dt>{term}</dt><dd>{text}</dd></div>)}</dl>
        <button type="button" className="button button-primary full-button" onClick={() => setOpen(false)}>Entendi</button>
      </section>
    </div>}
  </>
}

// ------------------------------------------------------------------ tela de abertura

export function Splash() {
  const [visible, setVisible] = useState(() => {
    try {
      return !sessionStorage.getItem('pif-splash')
    } catch {
      return true
    }
  })
  useEffect(() => {
    if (!visible) return
    try {
      sessionStorage.setItem('pif-splash', '1')
    } catch {
      // sem armazenamento
    }
    const timer = window.setTimeout(() => setVisible(false), 1500)
    return () => window.clearTimeout(timer)
  }, [visible])
  if (!visible) return null
  return <div className="splash" aria-hidden="true" onClick={() => setVisible(false)}>
    <div className="splash-logo">
      <span className="splash-cards"><i>♠</i><i>♥</i><i>♣</i></span>
      <span className="brand-mark splash-mark"><Spade size={34} fill="currentColor" /></span>
      <strong>Pif <span>da mesa</span></strong>
    </div>
  </div>
}
