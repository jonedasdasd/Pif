import { useEffect, useMemo, useState, type ChangeEvent } from 'react'
import { ArrowLeft, Download, Save, Spade, Upload } from 'lucide-react'
import type { RoomSummary } from './lib/engine'
import { canKeepScreenOn, exportBackup, getTurnAlerts, importBackup, nameKey, saveSettings, setLook, setTurnAlerts, turnAlert, useLook, useSettings, FELTS, FELT_LABEL, type Settings, type Theme } from './lib/settings'

function Toggle({ id, checked, onChange, title, children }: { id: string; checked: boolean; onChange: (value: boolean) => void; title: string; children: string }) {
  return <label className="setting-toggle" htmlFor={id}>
    <input id={id} type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
    <span><strong>{title}</strong><small>{children}</small></span>
    <span className={`setting-state ${checked ? 'on' : ''}`}>{checked ? 'Ligado' : 'Desligado'}</span>
  </label>
}

export function SettingsScreen({ summaries, isHostDevice, onBack }: { summaries: RoomSummary[]; isHostDevice: boolean; onBack: () => void }) {
  const saved = useSettings()
  const [draft, setDraft] = useState<Settings>(saved)
  const [dirty, setDirty] = useState(false)
  const [alerts, setAlerts] = useState(getTurnAlerts)
  const look = useLook()
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!dirty) setDraft(saved)
  }, [saved, dirty])

  const names = useMemo(() => {
    const map = new Map<string, string>()
    for (const summary of summaries) for (const player of summary.players) if (!map.has(nameKey(player.name))) map.set(nameKey(player.name), player.name)
    for (const key of Object.keys(draft.pix)) if (!map.has(key)) map.set(key, key)
    return [...map.entries()].sort((a, b) => a[1].localeCompare(b[1], 'pt-BR'))
  }, [summaries, draft.pix])

  const update = (patch: Partial<Settings>) => {
    setDraft((previous) => ({ ...previous, ...patch }))
    setDirty(true)
    setStatus('')
  }

  async function save() {
    setBusy(true)
    try {
      await saveSettings(draft)
      setDirty(false)
      setStatus('Configurações salvas. Valem para todos que estão na mesa.')
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Não foi possível salvar.')
    } finally { setBusy(false) }
  }

  async function doExport() {
    setBusy(true)
    try {
      setStatus(await exportBackup())
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Não foi possível gerar o backup.')
    } finally { setBusy(false) }
  }

  async function doImport(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    setBusy(true)
    try {
      setStatus(await importBackup(file))
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Não foi possível importar.')
    } finally { setBusy(false) }
  }

  return <main className="gate-shell history-shell">
    <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
    <section className="gate-panel history-panel settings-panel">
      <button type="button" className="text-action back-action" onClick={onBack}><ArrowLeft size={15} /> Voltar ao início</button>
      <h1>Configurações</h1>
      <p className="gate-copy">Os recursos abaixo vêm desligados. Ligue só o que quiser usar.</p>

      <section className="settings-group">
        <span className="section-kicker">VISUAL (NESTE CELULAR)</span>
        <div className="layout-options" role="radiogroup" aria-label="Visual">
          <button type="button" role="radio" aria-checked={look.layout === 'classico'} className={`layout-option ${look.layout === 'classico' ? 'selected' : ''}`} onClick={() => setLook({ layout: 'classico' })}>
            <span className="layout-preview preview-classico"><i /><i /><i /></span>
            <strong>Clássico</strong><small>Painéis claros com listas</small>
          </button>
          <button type="button" role="radio" aria-checked={look.layout === 'mesa'} className={`layout-option ${look.layout === 'mesa' ? 'selected' : ''}`} onClick={() => setLook({ layout: 'mesa' })}>
            <span className={`layout-preview preview-mesa felt-${look.felt}`}><b /><i /><i /><i /><i /></span>
            <strong>Mesa</strong><small>Feltro e jogadores em volta da mesa</small>
          </button>
        </div>
        <div className="setting-field">Cor do feltro (layout Mesa e treino)<div className="felt-options" role="radiogroup" aria-label="Cor do feltro">
          {FELTS.map((felt) => <button type="button" role="radio" aria-checked={look.felt === felt} key={felt} className={`felt-option felt-${felt} ${look.felt === felt ? 'selected' : ''}`} onClick={() => setLook({ felt })}><span />{FELT_LABEL[felt]}</button>)}
        </div></div>
        <div className="setting-field">Tema<div className="felt-options" role="radiogroup" aria-label="Tema">
          {([['claro', 'Claro'], ['escuro', 'Escuro'], ['auto', 'Igual ao celular']] as [Theme, string][]).map(([theme, label]) => <button type="button" role="radio" aria-checked={look.theme === theme} key={theme} className={`felt-option ${look.theme === theme ? 'selected' : ''}`} onClick={() => setLook({ theme })}>{label}</button>)}
        </div></div>
        <Toggle id="set-big" checked={look.big} onChange={(value) => setLook({ big: value })} title="Letra maior">Textos, botões e cartas ficam maiores.</Toggle>
        <Toggle id="set-onehand" checked={look.oneHand} onChange={(value) => setLook({ oneHand: value })} title="Jogar com uma mão">Os botões de jogar ficam grandes e presos embaixo da tela, perto do dedão.</Toggle>
        <Toggle id="set-confirm" checked={look.confirm} onChange={(value) => setLook({ confirm: value })} title="Pedir confirmação">Pergunta "Tem certeza?" antes de registrar quem bateu, lançar acerto e outras jogadas com dinheiro.</Toggle>
        <Toggle id="set-flash" checked={look.turnFlash} onChange={(value) => setLook({ turnFlash: value })} title="Piscar na sua vez">A borda da tela brilha de leve quando chega a sua vez.</Toggle>
        {canKeepScreenOn() && <Toggle id="set-screen" checked={look.keepScreenOn} onChange={(value) => setLook({ keepScreenOn: value })} title="Manter a tela ligada">A tela deste celular não apaga enquanto o app estiver aberto. Gasta mais bateria.</Toggle>}
      </section>

      <section className="settings-group">
        <span className="section-kicker">NESTE CELULAR</span>
        <Toggle id="set-alerts" checked={alerts} onChange={(value) => { setAlerts(value); setTurnAlerts(value); if (value) turnAlert() }} title="Aviso de vez">Vibra e toca um bipe quando for a sua vez de anunciar ou de responder.</Toggle>
      </section>

      {isHostDevice ? <>
        <section className="settings-group">
          <span className="section-kicker">DA MESA (VALE PARA TODOS)</span>
          <Toggle id="set-default" checked={draft.defaultValue !== null} onChange={(value) => update({ defaultValue: value ? draft.defaultValue ?? 10 : null })} title="Valor padrão">O valor já vem preenchido na hora de anunciar. Dá para mudar se quiser.</Toggle>
          {draft.defaultValue !== null && <label className="setting-field">Valor padrão por pessoa<div className="currency-input"><span>R$</span><input id="set-default-value" type="number" inputMode="decimal" min="0.01" step="0.01" value={draft.defaultValue} onChange={(event) => update({ defaultValue: Number(event.target.value) || 0.01 })} /></div></label>}

          <Toggle id="set-pix" checked={draft.pixEnabled} onChange={(value) => update({ pixEnabled: value })} title="Chave Pix no fechamento">No resultado aparece a chave Pix de quem vai receber, com botão de copiar.</Toggle>
          {draft.pixEnabled && <div className="setting-pix-list">
            {names.length ? names.map(([key, label]) => <label className="setting-field" key={key}>{label}<input id={`pix-${key}`} value={draft.pix[key] ?? ''} placeholder="Chave Pix (celular, e-mail, CPF...)" maxLength={120} onChange={(event) => update({ pix: { ...draft.pix, [key]: event.target.value } })} /></label>)
              : <p className="form-hint">Os nomes aparecem aqui depois da primeira partida.</p>}
          </div>}

          <Toggle id="set-share" checked={draft.shareImageEnabled} onChange={(value) => update({ shareImageEnabled: value })} title="Enviar imagem direto">Junto do "Salvar imagem" aparece "Enviar", que abre o WhatsApp e outros apps.</Toggle>
          <Toggle id="set-stats" checked={draft.statsEnabled} onChange={(value) => update({ statsEnabled: value })} title="Estatísticas no histórico">Aba com recordes: quem mais ganhou rodadas, maior pote, maior sequência de vitórias.</Toggle>
          <button type="button" className="button button-primary full-button" disabled={!dirty || busy} onClick={() => void save()}><Save size={16} /> {dirty ? 'Salvar configurações' : 'Tudo salvo'}</button>
        </section>

        <section className="settings-group">
          <span className="section-kicker">BACKUP DO HISTÓRICO</span>
          <p className="form-hint">O histórico fica só neste celular. Guarde um backup antes de trocar de aparelho ou desinstalar o app.</p>
          <button type="button" className="button button-secondary full-button" disabled={busy} onClick={() => void doExport()}><Download size={16} /> Exportar backup</button>
          <label className="button button-secondary full-button file-button"><Upload size={16} /> Importar backup<input id="import-backup" type="file" accept="application/json,.json" onChange={(event) => void doImport(event)} /></label>
        </section>
      </> : <p className="form-hint">As configurações da mesa e o backup ficam no celular do anfitrião.</p>}

      {status && <p className="gate-message settings-status" role="status">{status}</p>}
    </section>
  </main>
}
