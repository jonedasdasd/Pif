// Telas novas: histórico geral, resultado ao sair, rodadas detalhadas e imagem da noite.
import { useEffect, useMemo, useState } from 'react'
import { ArrowDownLeft, ArrowLeft, ArrowUpRight, Check, Copy, Download, FileSpreadsheet, Image as ImageIcon, Send, Spade, Trash2, Trophy, Undo2, X } from 'lucide-react'
import { balancesInReais, calculateReport, type RoomSummary } from './lib/engine'
import type { Room } from './lib/roomApi'
import { deleteRoom, downloadText, nameKey, saveSettings, useSettings } from './lib/settings'

function PixKey({ name }: { name: string }) {
  const settings = useSettings()
  const [copied, setCopied] = useState(false)
  const key = settings.pixEnabled ? settings.pix[nameKey(name)] : undefined
  if (!key) return null
  return <button type="button" className="pix-key" onClick={() => { void navigator.clipboard?.writeText(key).then(() => { setCopied(true); window.setTimeout(() => setCopied(false), 1500) }).catch(() => undefined) }}>
    <span>Pix de {name}: <b>{key}</b></span> <Copy size={13} /> {copied ? 'copiado' : ''}
  </button>
}

export function money(value: number) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)
}

function signedMoney(value: number) {
  if (Math.abs(value) < 0.005) return money(0)
  return `${value > 0 ? '+' : '−'}${money(Math.abs(value))}`
}

function shortDate(value: string | null) {
  if (!value) return ''
  return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(value))
}

const tone = (value: number) => (value > 0.004 ? 'positive' : value < -0.004 ? 'negative' : 'neutral')
const normalize = (name: string) => name.trim().toLocaleLowerCase('pt-BR')
const nameOf = (room: Room, id?: string) => room.players.find((player) => player.id === id)?.name ?? 'Participante'

// ------------------------------------------------------------------ rodadas

/** Lista de todas as rodadas: quem abriu, quem jogou, valores e quanto cada um ganhou ou perdeu. */
export function RoundsHistory({ room, onCorrect }: { room: Room; onCorrect?: (roundId: string) => void }) {
  if (!room.rounds.length) return <p className="empty-copy">Nenhuma rodada registrada ainda.</p>
  return <ol className="rounds-history">
    {room.rounds.map((round) => {
      const ids = round.playerIds ?? []
      const losers = Math.max(0, ids.length - 1)
      return <li className="rounds-history-item" key={round.id}>
        <div className="rounds-history-head">
          <strong>Rodada {round.number}</strong>
          <span className="rounds-history-value">{money(round.value)} por jogador</span>
        </div>
        <p className="rounds-history-meta">
          Abriu: <b>{nameOf(room, round.firstPlayerId)}</b>
          {round.doubledByPlayerIds?.length ? <> · Dobrou: <b>{round.doubledByPlayerIds.map((id) => nameOf(room, id)).join(', ')}</b></> : null}
          {round.foldedPlayerIds?.length ? <> · Saíram: {round.foldedPlayerIds.map((id) => nameOf(room, id)).join(', ')}</> : null}
          {round.correctedAt ? ' · corrigida' : ''}
        </p>
        <div className="rounds-history-chips">
          {ids.map((id) => {
            const won = id === round.winnerId
            const amount = won ? round.value * losers : -round.value
            return <span key={id} className={`round-chip ${won ? 'round-chip-winner' : ''}`}>
              {won && <Trophy size={12} />} {nameOf(room, id)} <b className={tone(amount)}>{signedMoney(amount)}</b>
            </span>
          })}
        </div>
        {onCorrect && round.winnerId && <button type="button" className="correct-round-button" onClick={() => onCorrect(round.id)}>Corrigir vencedor</button>}
      </li>
    })}
  </ol>
}

// ------------------------------------------------------------------ resultado

const CONFETTI_COLORS = ['#e9c46a', '#e76f51', '#2a9d8f', '#f4a261', '#8ab17d', '#d1495b', '#ffffff']

/** Chuva de confete (uma vez, some sozinha). */
export function Confetti() {
  const [on, setOn] = useState(true)
  useEffect(() => {
    const timer = window.setTimeout(() => setOn(false), 4200)
    return () => window.clearTimeout(timer)
  }, [])
  const pieces = useMemo(() => Array.from({ length: 60 }, (_, index) => ({
    left: Math.random() * 100,
    delay: Math.random() * 1.2,
    duration: 2.2 + Math.random() * 1.6,
    color: CONFETTI_COLORS[index % CONFETTI_COLORS.length],
    rotate: Math.random() * 360,
    wide: Math.random() > 0.5,
  })), [])
  if (!on) return null
  return <div className="confetti" aria-hidden="true">
    {pieces.map((piece, index) => <i key={index} className={piece.wide ? 'wide' : ''} style={{ left: `${piece.left}%`, background: piece.color, animationDelay: `${piece.delay}s`, animationDuration: `${piece.duration}s`, transform: `rotate(${piece.rotate}deg)` }} />)}
  </div>
}

/** Pódio com os três primeiros da noite. */
export function Podium({ room, balances }: { room: Room; balances: Map<string, number> }) {
  const ranked = [...room.players].filter((player) => room.rounds.some((round) => round.playerIds?.includes(player.id)) || Math.abs(balances.get(player.id) ?? 0) > 0.004)
    .sort((a, b) => (balances.get(b.id) ?? 0) - (balances.get(a.id) ?? 0)).slice(0, 3)
  if (ranked.length < 2) return null
  // Ordem visual: 2º, 1º, 3º.
  const order = [ranked[1], ranked[0], ranked[2]].filter(Boolean)
  return <div className="podium" aria-label="Pódio da noite">
    {order.map((player) => {
      const place = ranked.indexOf(player) + 1
      const amount = balances.get(player.id) ?? 0
      return <div className={`podium-step podium-${place}`} key={player.id}>
        <span className="podium-avatar">{player.avatar || (place === 1 ? '👑' : player.name.slice(0, 1).toUpperCase())}</span>
        <strong>{player.name}</strong>
        <small className={tone(amount)}>{signedMoney(amount)}</small>
        <span className="podium-block">{place}º</span>
      </div>
    })}
  </div>
}

/** Resultado da mesa para quem está saindo (ou para todos, quando encerrada). */
export function ResultView({ room, playerId }: { room: Room; playerId: string }) {
  const balances = useMemo(() => balancesInReais(room), [room])
  const report = useMemo(() => room.finalReport ?? calculateReport(room), [room])
  const mine = balances.get(playerId) ?? 0
  const me = room.players.find((player) => player.id === playerId)
  const ranking = [...room.players].sort((a, b) => (balances.get(b.id) ?? 0) - (balances.get(a.id) ?? 0))
  const personal = report.transfers.filter((transfer) => transfer.fromPlayerId === playerId || transfer.toPlayerId === playerId)
  return <div className="result-view">
    {room.status === 'finished' && room.rounds.length > 0 && <Confetti />}
    {room.rounds.length > 0 && <Podium room={room} balances={balances} />}
    {me && <div className={`personal-balance ${mine > 0 ? 'balance-credit' : mine < 0 ? 'balance-debit' : ''}`}>
      <span>{mine > 0 ? 'VOCÊ TEM A RECEBER' : mine < 0 ? 'VOCÊ PRECISA PAGAR' : 'SEU SALDO'}</span>
      <strong>{money(Math.abs(mine))}</strong>
      <small>{room.status === 'finished' ? 'Resultado final da mesa.' : 'Seu saldo até agora. A mesa continua para quem ficou.'}</small>
    </div>}
    {me && personal.length > 0 && <div className="report-transfer-list">{personal.map((transfer) => {
      const paying = transfer.fromPlayerId === playerId
      return <div className="report-transfer" key={`${transfer.fromPlayerId}-${transfer.toPlayerId}`}>
        <span className={`report-direction ${paying ? 'negative' : 'positive'}`}>{paying ? <ArrowUpRight size={17} /> : <ArrowDownLeft size={17} />}</span>
        <span>{paying ? <>Você paga <strong>{transfer.to}</strong></> : <><strong>{transfer.from}</strong> paga para você</>}</span>
        <strong className="report-amount">{money(transfer.amount)}</strong>
        {paying && <PixKey name={transfer.to} />}
      </div>
    })}</div>}

    <section className="result-section">
      <span className="section-kicker">SALDO DE CADA UM</span>
      {ranking.map((player) => {
        const amount = balances.get(player.id) ?? 0
        return <div className="result-row" key={player.id}>
          <span>{player.name}{player.id === playerId ? ' (você)' : ''}{!player.inGame && room.status !== 'finished' ? ' · saiu' : ''}</span>
          <strong className={tone(amount)}>{signedMoney(amount)}</strong>
        </div>
      })}
    </section>

    <section className="result-section">
      <span className="section-kicker">QUEM PAGA QUEM</span>
      {report.transfers.length ? report.transfers.map((transfer) => <div className="result-row result-row-wrap" key={`all-${transfer.fromPlayerId}-${transfer.toPlayerId}`}>
        <span>{transfer.from} paga para {transfer.to}</span><strong>{money(transfer.amount)}</strong>
        <PixKey name={transfer.to} />
      </div>) : <p className="empty-copy">Ninguém deve nada.</p>}
    </section>

    <section className="result-section">
      <span className="section-kicker">RODADAS ({room.rounds.length})</span>
      <RoundsHistory room={room} />
    </section>

    <NightImageButton room={room} />
  </div>
}

// ------------------------------------------------------------------ imagem

function drawNightImage(room: Room): string {
  const balances = balancesInReais(room)
  const report = room.finalReport ?? calculateReport(room)
  const ranking = [...room.players].filter((player) => room.rounds.some((round) => round.playerIds?.includes(player.id)) || Math.abs(balances.get(player.id) ?? 0) > 0.004)
    .sort((a, b) => (balances.get(b.id) ?? 0) - (balances.get(a.id) ?? 0))
  const roundLines = room.rounds.slice(-12)
  const hiddenRounds = room.rounds.length - roundLines.length
  const W = 1080
  const pad = 64
  const row = 64
  const podium = ranking.length >= 2 ? 360 : 0
  const height = 300 + podium + 90 + ranking.length * row + 60
    + 90 + Math.max(1, report.transfers.length) * 56 + 40
    + 90 + roundLines.length * 52 + (hiddenRounds ? 52 : 0) + 140
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = height
  const g = canvas.getContext('2d')!
  const sans = '"Trebuchet MS", "Segoe UI", Roboto, sans-serif'
  const serif = 'Georgia, "Times New Roman", serif'
  g.fillStyle = '#f4f5f1'
  g.fillRect(0, 0, W, height)
  g.fillStyle = '#1b402d'
  g.fillRect(0, 0, W, 260)
  if (ranking.length >= 2) {
    // Confetes no cabeçalho (atrás do texto).
    const colors = ['#e9c46a', '#e76f51', '#2a9d8f', '#f4a261', '#ffffff']
    g.globalAlpha = 0.55
    for (let index = 0; index < 70; index += 1) {
      g.fillStyle = colors[index % colors.length]
      g.save()
      g.translate((index * 151) % W, 20 + ((index * 97) % 220))
      g.rotate(index)
      g.fillRect(-7, -3, 14, 6)
      g.restore()
    }
    g.globalAlpha = 1
  }
  g.fillStyle = '#ffffff'
  g.font = `bold 40px ${sans}`
  g.fillText('♠ Pif da Mesa', pad, 92)
  g.font = `600 64px ${serif}`
  g.fillText(room.name.length > 26 ? `${room.name.slice(0, 25)}…` : room.name, pad, 178)
  g.font = `30px ${sans}`
  g.fillStyle = '#c9dccb'
  const date = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'full' }).format(new Date(room.startedAt ?? room.createdAt))
  g.fillText(`${date} · ${room.rounds.length} ${room.rounds.length === 1 ? 'rodada' : 'rodadas'}`, pad, 228)

  let y = 340
  if (podium) {
    // Pódio: 2º, 1º, 3º, com blocos de alturas diferentes.
    const top3 = ranking.slice(0, 3)
    const slots = [top3[1], top3[0], top3[2]]
    const blockW = 260
    const gap = 36
    const startX = (W - (blockW * 3 + gap * 2)) / 2
    const base = y + 300
    const heights = [210, 150, 110]
    const fills = ['#e9c46a', '#c0c7cc', '#d29a6a']
    slots.forEach((player, slot) => {
      if (!player) return
      const place = top3.indexOf(player) + 1
      const x = startX + slot * (blockW + gap)
      const h = heights[place - 1]
      g.fillStyle = fills[place - 1]
      if (typeof g.roundRect === 'function') {
        g.beginPath()
        g.roundRect(x, base - h, blockW, h, 18)
        g.fill()
      } else g.fillRect(x, base - h, blockW, h)
      g.fillStyle = '#1b402d'
      g.font = `bold 64px ${serif}`
      g.textAlign = 'center'
      g.fillText(`${place}º`, x + blockW / 2, base - h / 2 + 22)
      g.font = `60px ${sans}`
      g.fillText(player.avatar || (place === 1 ? '👑' : '★'), x + blockW / 2, base - h - 92)
      g.fillStyle = '#202c24'
      g.font = `bold 32px ${sans}`
      const label = player.name.length > 13 ? `${player.name.slice(0, 12)}…` : player.name
      g.fillText(label, x + blockW / 2, base - h - 44)
      const amount = balances.get(player.id) ?? 0
      g.font = `bold 28px ${sans}`
      g.fillStyle = amount > 0.004 ? '#24764a' : amount < -0.004 ? '#b3402a' : '#5b6b5f'
      g.fillText(signedMoney(amount), x + blockW / 2, base - h - 12)
      g.textAlign = 'left'
    })
    y = base + 90
  }
  const title = (text: string) => {
    g.fillStyle = '#5b6b5f'
    g.font = `bold 26px ${sans}`
    g.fillText(text, pad, y)
    y += 50
  }
  const line = (left: string, right: string, color: string, size = 36) => {
    g.font = `${size}px ${sans}`
    g.fillStyle = '#202c24'
    g.textAlign = 'left'
    g.fillText(left, pad, y)
    g.font = `bold ${size}px ${sans}`
    g.fillStyle = color
    g.textAlign = 'right'
    g.fillText(right, W - pad, y)
    g.textAlign = 'left'
  }
  const color = (value: number) => (value > 0.004 ? '#24764a' : value < -0.004 ? '#b3402a' : '#5b6b5f')

  title(room.status === 'finished' ? 'RESULTADO DA NOITE' : 'PARCIAL DA NOITE')
  ranking.forEach((player, index) => {
    const amount = balances.get(player.id) ?? 0
    line(`${index === 0 && amount > 0 ? '🏆 ' : ''}${player.name}`, signedMoney(amount), color(amount), 40)
    y += row
  })
  y += 40
  title('QUEM PAGA QUEM')
  if (report.transfers.length) {
    for (const transfer of report.transfers) {
      line(`${transfer.from} → ${transfer.to}`, money(transfer.amount), '#202c24', 32)
      y += 56
    }
  } else {
    line('Ninguém deve nada', '', '#202c24', 32)
    y += 56
  }
  y += 40
  title('RODADAS')
  if (hiddenRounds) {
    line(`+ ${hiddenRounds} rodadas anteriores`, '', '#5b6b5f', 28)
    y += 52
  }
  for (const round of roundLines) {
    line(`${round.number}. ${round.winnerName ?? '?'} bateu · ${round.playerIds?.length ?? 0} jogadores`, money(round.value), '#202c24', 28)
    y += 52
  }
  y += 30
  g.fillStyle = '#8a978d'
  g.font = `24px ${sans}`
  g.fillText('Gerado pelo Pif da Mesa', pad, y)
  // Corta a sobra do fim da imagem.
  const finalHeight = Math.min(height, y + 50)
  const cropped = document.createElement('canvas')
  cropped.width = W
  cropped.height = finalHeight
  cropped.getContext('2d')!.drawImage(canvas, 0, 0)
  return cropped.toDataURL('image/png')
}

export function NightImageButton({ room }: { room: Room }) {
  const settings = useSettings()
  const [image, setImage] = useState<string | null>(null)
  const [status, setStatus] = useState('')
  const fileName = `pif-${room.name.replace(/[^\p{L}\p{N}]+/gu, '-').toLowerCase()}-${(room.startedAt ?? room.createdAt).slice(0, 10)}.png`

  function save() {
    if (!image) return
    const base64 = image.split(',')[1] ?? ''
    if (window.PifAndroid?.saveImage) {
      let ok = false
      try {
        ok = window.PifAndroid.saveImage(base64, fileName)
      } catch {
        ok = false
      }
      setStatus(ok ? 'Imagem salva na galeria, na pasta Pictures/PifDaMesa.' : 'Não foi possível salvar a imagem.')
      return
    }
    const link = document.createElement('a')
    link.href = image
    link.download = fileName
    document.body.appendChild(link)
    link.click()
    link.remove()
    setStatus('Se o download não começar, toque e segure na imagem para salvar.')
  }

  async function share() {
    if (!image) return
    const base64 = image.split(',')[1] ?? ''
    if (window.PifAndroid?.shareImage) {
      let ok = false
      try {
        ok = window.PifAndroid.shareImage(base64, fileName)
      } catch {
        ok = false
      }
      if (!ok) setStatus('Não foi possível abrir o envio. Salve a imagem e mande pela galeria.')
      return
    }
    try {
      const blob = await (await fetch(image)).blob()
      const file = new File([blob], fileName, { type: 'image/png' })
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: room.name })
        return
      }
    } catch {
      // cai no aviso abaixo
    }
    setStatus('Este navegador não envia direto. Salve a imagem e mande pela galeria.')
  }

  return <>
    <button type="button" className="button button-secondary full-button" onClick={() => { setStatus(''); setImage(drawNightImage(room)) }}><ImageIcon size={16} /> Gerar imagem para o grupo</button>
    {image && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setImage(null) }}>
      <section className="modal image-modal" role="dialog" aria-modal="true" aria-label="Imagem da partida">
        <div className="modal-heading"><div><span className="section-kicker">PARA O GRUPO</span><h2>Imagem da partida</h2></div><button className="icon-button" onClick={() => setImage(null)} aria-label="Fechar"><X size={19} /></button></div>
        <img className="night-image" src={image} alt={`Resultado da mesa ${room.name}`} />
        <button type="button" className="button button-primary full-button" onClick={save}><Download size={16} /> Salvar imagem</button>
        {settings.shareImageEnabled && <button type="button" className="button button-secondary full-button" onClick={() => void share()}><Send size={16} /> Enviar (WhatsApp e outros)</button>}
        {status && <p className="form-hint">{status}</p>}
      </section>
    </div>}
  </>
}

// ------------------------------------------------------------------ histórico geral

type Ranked = { name: string; total: number; games: number; wins: number }

const csvCell = (value: string | number) => {
  const text = typeof value === 'number' ? value.toFixed(2).replace('.', ',') : value
  return /[;"\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

/** Planilha (CSV com ; e acentos certos, abre no Excel e no Google Planilhas). */
export function buildCsv(games: RoomSummary[]): string {
  const rows: (string | number)[][] = [['SALDOS POR PARTIDA'], ['Data', 'Partida', 'Jogador', 'Saldo (R$)']]
  for (const game of games) {
    const date = shortDate(game.startedAt ?? game.createdAt)
    for (const player of game.players) rows.push([date, game.name, player.name, player.amount])
  }
  rows.push([], ['RODADAS'], ['Data', 'Partida', 'Rodada', 'Abriu', 'Quem bateu', 'Valor por jogador (R$)', 'Jogadores', 'Pote (R$)'])
  for (const game of games) {
    const date = shortDate(game.startedAt ?? game.createdAt)
    for (const round of game.rounds) rows.push([date, game.name, String(round.number), round.opener, round.winner, round.value, String(round.players), round.value * Math.max(0, round.players - 1)])
  }
  rows.push([], ['QUEM PAGA QUEM'], ['Data', 'Partida', 'Paga', 'Recebe', 'Valor (R$)'])
  for (const game of games) {
    const date = shortDate(game.startedAt ?? game.createdAt)
    for (const transfer of game.transfers ?? []) rows.push([date, game.name, transfer.from, transfer.to, transfer.amount])
  }
  return '\ufeff' + rows.map((row) => row.map(csvCell).join(';')).join('\r\n')
}

const paidKey = (code: string, from: string, to: string) => `${code}|${nameKey(from)}|${nameKey(to)}`

/** Caderneta: dívidas das noites anteriores que ainda não foram pagas. */
function Caderneta({ games, canEdit }: { games: RoomSummary[]; canEdit: boolean }) {
  const settings = useSettings()
  const [override, setPaid] = useState<Record<string, string> | null>(null)
  const paid = override ?? settings.paid
  const [error, setError] = useState('')
  const [showPaid, setShowPaid] = useState(false)
  const debts = games.flatMap((game) => (game.transfers ?? []).map((transfer) => ({ ...transfer, game, key: paidKey(game.code, transfer.from, transfer.to) })))
  const pending = debts.filter((debt) => !paid[debt.key])
  const done = debts.filter((debt) => paid[debt.key])
  // Soma por dupla (quem deve para quem, juntando várias noites).
  const pairs = new Map<string, { from: string; to: string; amount: number }>()
  for (const debt of pending) {
    const key = `${nameKey(debt.from)}>${nameKey(debt.to)}`
    const reverse = `${nameKey(debt.to)}>${nameKey(debt.from)}`
    if (pairs.has(reverse)) {
      const entry = pairs.get(reverse)!
      entry.amount -= debt.amount
      if (entry.amount < -0.004) {
        pairs.delete(reverse)
        pairs.set(key, { from: debt.from, to: debt.to, amount: -entry.amount })
      }
      continue
    }
    const entry = pairs.get(key) ?? { from: debt.from, to: debt.to, amount: 0 }
    entry.amount += debt.amount
    pairs.set(key, entry)
  }
  const totals = [...pairs.values()].filter((pair) => pair.amount > 0.004).sort((a, b) => b.amount - a.amount)

  async function toggle(key: string, value: boolean) {
    const next = { ...paid }
    if (value) next[key] = new Date().toISOString()
    else delete next[key]
    setPaid(next)
    setError('')
    try {
      await saveSettings({ ...settings, paid: next })
    } catch (reason) {
      setPaid(paid)
      setError(reason instanceof Error ? reason.message : 'Não foi possível salvar.')
    }
  }

  if (!debts.length) return <p className="empty-copy">Nenhuma dívida registrada. Quando uma mesa for encerrada, quem paga quem aparece aqui.</p>
  return <div className="caderneta">
    {error && <p className="gate-message" role="alert">{error}</p>}
    <p className="form-hint">Dívidas das noites encerradas que ainda não foram pagas.{canEdit ? ' Toque em “Pago” quando acertarem.' : ' Só o celular do anfitrião marca como pago.'}</p>
    {totals.length > 0 && <section className="result-section">
      <span className="section-kicker">TOTAL EM ABERTO</span>
      {totals.map((pair) => <div className="result-row" key={`${pair.from}>${pair.to}`}><span>{pair.from} deve para {pair.to}</span><strong className="negative">{money(pair.amount)}</strong></div>)}
    </section>}
    <section className="result-section">
      <span className="section-kicker">EM ABERTO ({pending.length})</span>
      {pending.length ? pending.map((debt) => <div className="caderneta-row" key={debt.key}>
        <span><strong>{debt.from} → {debt.to}</strong><small>{debt.game.name} · {shortDate(debt.game.finishedAt ?? debt.game.createdAt)}</small></span>
        <b>{money(debt.amount)}</b>
        {canEdit && <button type="button" className="button button-secondary caderneta-pay" onClick={() => void toggle(debt.key, true)}><Check size={14} /> Pago</button>}
      </div>) : <p className="empty-copy">Tudo pago! 🎉</p>}
    </section>
    {done.length > 0 && <section className="result-section">
      <button type="button" className="text-action" onClick={() => setShowPaid(!showPaid)}>{showPaid ? 'Esconder' : 'Ver'} as já pagas ({done.length})</button>
      {showPaid && done.map((debt) => <div className="caderneta-row is-paid" key={debt.key}>
        <span><strong>{debt.from} → {debt.to}</strong><small>{debt.game.name} · pago em {shortDate(paid[debt.key])}</small></span>
        <b>{money(debt.amount)}</b>
        {canEdit && <button type="button" className="text-action" onClick={() => void toggle(debt.key, false)}><Undo2 size={13} /> Desfazer</button>}
      </div>)}
    </section>}
  </div>
}

function StatsView({ games }: { games: RoomSummary[] }) {
  const stats = useMemo(() => {
    let rounds = 0
    let moved = 0
    let biggestPot: { value: number; who: string; game: string } | null = null
    let bestNight: { value: number; who: string; game: string } | null = null
    let worstNight: { value: number; who: string; game: string } | null = null
    let streak: { value: number; who: string; game: string } | null = null
    const wins = new Map<string, { name: string; count: number }>()
    for (const game of games) {
      let run = 0
      let runner = ''
      for (const round of game.rounds) {
        rounds += 1
        const pot = round.value * Math.max(0, round.players - 1)
        moved += pot
        if (!biggestPot || pot > biggestPot.value) biggestPot = { value: pot, who: round.winner, game: game.name }
        const key = nameKey(round.winner)
        if (round.winner) {
          const entry = wins.get(key) ?? { name: round.winner, count: 0 }
          entry.count += 1
          wins.set(key, entry)
        }
        run = key && key === runner ? run + 1 : 1
        runner = key
        if (round.winner && (!streak || run > streak.value)) streak = { value: run, who: round.winner, game: game.name }
      }
      for (const player of game.players) {
        if (!bestNight || player.amount > bestNight.value) bestNight = { value: player.amount, who: player.name, game: game.name }
        if (!worstNight || player.amount < worstNight.value) worstNight = { value: player.amount, who: player.name, game: game.name }
      }
    }
    const topWins = [...wins.values()].sort((a, b) => b.count - a.count)[0]
    return { rounds, moved, biggestPot, bestNight, worstNight, streak, topWins }
  }, [games])
  if (!games.length) return <p className="empty-copy">As estatísticas aparecem depois da primeira partida encerrada.</p>
  const card = (label: string, value: string, detail: string) => <div className="stat-card" key={label}><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>
  return <div className="stats-grid">
    {card('Partidas', String(games.length), `${stats.rounds} ${stats.rounds === 1 ? 'rodada jogada' : 'rodadas jogadas'}`)}
    {card('Dinheiro que rodou', money(stats.moved), 'soma de todos os potes')}
    {stats.topWins && card('Mais rodadas ganhas', stats.topWins.name, `${stats.topWins.count} ${stats.topWins.count === 1 ? 'rodada' : 'rodadas'}`)}
    {stats.biggestPot && card('Maior pote', money(stats.biggestPot.value), `${stats.biggestPot.who} · ${stats.biggestPot.game}`)}
    {stats.streak && stats.streak.value > 1 && card('Maior sequência', `${stats.streak.value} seguidas`, `${stats.streak.who} · ${stats.streak.game}`)}
    {stats.bestNight && stats.bestNight.value > 0 && card('Melhor noite', signedMoney(stats.bestNight.value), `${stats.bestNight.who} · ${stats.bestNight.game}`)}
    {stats.worstNight && stats.worstNight.value < 0 && card('Pior noite', signedMoney(stats.worstNight.value), `${stats.worstNight.who} · ${stats.worstNight.game}`)}
  </div>
}

export function HistoryScreen({ summaries, onBack, onOpen, canDelete }: { summaries: RoomSummary[]; onBack: () => void; onOpen: (code: string) => void; canDelete: boolean }) {
  const settings = useSettings()
  const [view, setView] = useState<'ranking' | 'games' | 'stats' | 'caderneta'>('ranking')
  const [csvStatus, setCsvStatus] = useState('')
  const [person, setPerson] = useState<string | null>(null)
  const [confirming, setConfirming] = useState<string | null>(null)
  const [deleted, setDeleted] = useState<string[]>([])
  const [error, setError] = useState('')
  const finished = summaries.filter((item) => item.status === 'finished' && !deleted.includes(item.code))
    .sort((a, b) => (b.finishedAt ?? b.createdAt).localeCompare(a.finishedAt ?? a.createdAt))

  const ranking = useMemo(() => {
    const map = new Map<string, Ranked>()
    for (const game of finished) {
      for (const player of game.players) {
        const key = normalize(player.name)
        const entry = map.get(key) ?? { name: player.name, total: 0, games: 0, wins: 0 }
        entry.total += player.amount
        entry.games += 1
        entry.wins += game.rounds.filter((round) => normalize(round.winner) === key).length
        map.set(key, entry)
      }
    }
    return [...map.values()].sort((a, b) => b.total - a.total)
  }, [finished])

  const games = person ? finished.filter((game) => game.players.some((player) => normalize(player.name) === person)) : finished

  return <main className="gate-shell history-shell">
    <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
    <section className="gate-panel history-panel">
      <button type="button" className="text-action back-action" onClick={onBack}><ArrowLeft size={15} /> Voltar ao início</button>
      <span className="section-kicker">TODAS AS PARTIDAS ENCERRADAS</span>
      <h1>Histórico geral</h1>
      <div className="history-tabs" role="tablist">
        <button type="button" role="tab" aria-selected={view === 'ranking'} className={view === 'ranking' ? 'selected' : ''} onClick={() => setView('ranking')}>Quem ganhou e perdeu</button>
        <button type="button" role="tab" aria-selected={view === 'games'} className={view === 'games' ? 'selected' : ''} onClick={() => setView('games')}>Partidas ({finished.length})</button>
        <button type="button" role="tab" aria-selected={view === 'caderneta'} className={view === 'caderneta' ? 'selected' : ''} onClick={() => setView('caderneta')}>Caderneta</button>
        {settings.statsEnabled && <button type="button" role="tab" aria-selected={view === 'stats'} className={view === 'stats' ? 'selected' : ''} onClick={() => setView('stats')}>Recordes</button>}
      </div>
      {error && <p className="gate-message" role="alert">{error}</p>}
      {view === 'stats' && settings.statsEnabled && <StatsView games={finished} />}
      {view === 'caderneta' && <Caderneta games={finished} canEdit={canDelete} />}
      {finished.length > 0 && <button type="button" className="text-action csv-action" onClick={() => setCsvStatus(downloadText(buildCsv(finished), `pif-da-mesa-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv;charset=utf-8', 'Planilha'))}><FileSpreadsheet size={15} /> Exportar planilha (Excel)</button>}
      {csvStatus && <p className="form-hint">{csvStatus}</p>}

      {!finished.length && <p className="empty-copy">Ainda não tem partida encerrada. Quando uma mesa for encerrada, o resultado aparece aqui.</p>}

      {view === 'ranking' && ranking.length > 0 && <div className="history-ranking">
        <p className="form-hint">Soma de todas as partidas encerradas. Toque num nome para ver as partidas dele.</p>
        {ranking.map((entry, index) => <button type="button" className="history-rank-row" key={entry.name} onClick={() => { setPerson(normalize(entry.name)); setView('games') }}>
          <span className="history-rank-pos">{index + 1}</span>
          <span className="history-rank-name"><strong>{entry.name}</strong><small>{entry.games} {entry.games === 1 ? 'partida' : 'partidas'} · {entry.wins} {entry.wins === 1 ? 'rodada ganha' : 'rodadas ganhas'}</small></span>
          <strong className={`history-rank-total ${tone(entry.total)}`}>{signedMoney(entry.total)}</strong>
        </button>)}
      </div>}

      {view === 'games' && <div className="history-games">
        {person && <div className="history-filter">
          <span>Partidas de <strong>{ranking.find((entry) => normalize(entry.name) === person)?.name ?? person}</strong></span>
          <button type="button" className="text-action" onClick={() => setPerson(null)}>Ver todas</button>
        </div>}
        {games.map((game) => {
          const sorted = [...game.players].sort((a, b) => b.amount - a.amount)
          const mine = person ? game.players.find((player) => normalize(player.name) === person) : undefined
          return <details className="history-game" key={game.code}>
            <summary>
              <span className="history-game-title"><strong>{game.name}</strong><small>{shortDate(game.startedAt ?? game.createdAt)} · {game.rounds.length} rodadas{game.solo ? ' · solo' : ''}</small></span>
              {mine && <strong className={tone(mine.amount)}>{signedMoney(mine.amount)}</strong>}
            </summary>
            <div className="history-game-body">
              {sorted.map((player) => <div className="result-row" key={player.id}><span>{player.name}</span><strong className={tone(player.amount)}>{signedMoney(player.amount)}</strong></div>)}
              {game.rounds.length > 0 && <ol className="history-game-rounds">{game.rounds.map((round) => <li key={round.number}>Rodada {round.number}: {round.winner || '?'} bateu · {money(round.value)} · {round.players} jogadores · abriu {round.opener || '?'}</li>)}</ol>}
              <div className="history-game-actions">
                <button type="button" className="button button-secondary" onClick={() => onOpen(game.code)}>Abrir partida</button>
                {canDelete && (confirming === game.code
                  ? <button type="button" className="button button-danger" onClick={() => { void deleteRoom(game.code).then(() => { setDeleted([...deleted, game.code]); setConfirming(null) }).catch((reason: unknown) => setError(reason instanceof Error ? reason.message : 'Não foi possível apagar.')) }}><Trash2 size={15} /> Confirmar: apagar de vez</button>
                  : <button type="button" className="text-action delete-action" onClick={() => setConfirming(game.code)}><Trash2 size={14} /> Apagar partida</button>)}
              </div>
            </div>
          </details>
        })}
      </div>}
    </section>
  </main>
}
