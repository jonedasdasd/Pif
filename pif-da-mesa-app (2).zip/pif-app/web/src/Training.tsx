// Modo treino: Pif com cartas de verdade (aleatórias), sozinho ou contra robôs.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, BookOpen, Bot, CalendarDays, Copy, Eye, Gauge, Layers, Lightbulb, Play, RotateCcw, Shuffle, Spade, Trophy, Volume2, VolumeX, X } from 'lucide-react'
import { cardLabel, cardsInGames, bestDiscard, findWinningDiscard, canWinWith, sortByGames, sortHand, waitingCards, type Card, type Difficulty } from './lib/pif'
import {
  advanceClaim, botStep, dailyGoal, tutorialDeck, declareWin, discardCard, drawDeck, drawPile, newGame, personalityLabel, seenCopies, todayKey, userClaim,
  type Config, type Mode, type Result, type Speed, type Step, type TGame,
} from './lib/treino'
import { setLook, useLook, FELTS, FELT_LABEL } from './lib/settings'
import { CardBack, FlyLayer, HandView, PlayingCard } from './training/cards'
import { makeFlight, rectOf, sounds, type Flight } from './training/fx'
import { ACHIEVEMENTS, checkAchievements, unlockedAchievements, type Achievement } from './training/achievements'
import { ReplayModal, TutorialBubble, type TutorialStep } from './training/extras'
import { HelpButton } from './ui'

// ------------------------------------------------------------------ preferências, estatísticas e partida salva

type Back = 'vermelho' | 'azul' | 'preto' | 'verde' | 'roxo' | 'dourado'
const BACKS: Back[] = ['vermelho', 'azul', 'preto', 'verde', 'roxo', 'dourado']
type Prefs = { mode: Mode; bots: number; difficulty: Difficulty; hints: boolean; counter: boolean; speed: Speed; series: 1 | 3 | 5; back: Back; sound: boolean; openHands: boolean }
type Stats = { played: number; won: number; byClaim: number; winDraws: number; fastest: number | null; streak: number; bestStreak: number; bestSolo: number | null; daily: Record<string, number> }
type Series = { target: 1 | 3 | 5; scores: number[] }
type Saved = { game: TGame; series: Series | null }

const PREFS_KEY = 'pif-treino-prefs'
const STATS_KEY = 'pif-treino-stats'
const SAVE_KEY = 'pif-treino-save'
const RULES_KEY = 'pif-treino-regras-vistas'

const defaultPrefs: Prefs = { mode: 'bots', bots: 2, difficulty: 'normal', hints: true, counter: true, speed: 'normal', series: 1, back: 'vermelho', sound: true, openHands: false }
const SPEED: Record<Speed, { step: number; check: number; window: number }> = {
  lenta: { step: 1500, check: 700, window: 2800 },
  normal: { step: 950, check: 450, window: 1900 },
  rapida: { step: 450, check: 220, window: 1000 },
}
const speedLabel: Record<Speed, string> = { lenta: 'Lenta', normal: 'Normal', rapida: 'Rápida' }
const difficultyLabel: Record<Difficulty, string> = { facil: 'Fácil', normal: 'Normal', dificil: 'Difícil', mestre: 'Mestre' }

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback
  } catch {
    return fallback
  }
}
function save(key: string, value: unknown) {
  try {
    if (value === null) localStorage.removeItem(key)
    else localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // sem armazenamento: segue sem salvar
  }
}
function loadSaved(): Saved | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY)
    if (!raw) return null
    const data = JSON.parse(raw) as Saved
    return data?.game?.players?.length && data.game.phase !== 'over' ? data : null
  } catch {
    return null
  }
}
const emptyStats: Stats = { played: 0, won: 0, byClaim: 0, winDraws: 0, fastest: null, streak: 0, bestStreak: 0, bestSolo: null, daily: {} }
const shortDate = (key: string) => key.split('-').reverse().slice(0, 2).join('/')
const plural = (count: number, one: string, many: string) => `${count} ${count === 1 ? one : many}`

// ------------------------------------------------------------------ regras rápidas

function RulesModal({ onClose }: { onClose: () => void }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}>
    <section className="modal rules-modal" role="dialog" aria-modal="true" aria-labelledby="rules-title">
      <div className="modal-heading"><div><span className="section-kicker">REGRAS RÁPIDAS</span><h2 id="rules-title">Como se joga o Pif</h2></div><button className="icon-button" onClick={onClose} aria-label="Fechar"><X size={19} /></button></div>
      <ol className="rules-list">
        <li><b>2 baralhos</b> juntos, sem coringa. Cada um recebe <b>9 cartas</b>.</li>
        <li>Na sua vez: <b>compre</b> do monte ou pegue a carta de cima do <b>lixo</b>. Depois <b>descarte</b> uma.</li>
        <li><b>Bate</b> quem fizer <b>3 jogos</b> com as 9 cartas:
          <div className="rules-examples">
            <span><b>Trinca:</b> mesmo número, naipes diferentes (7♥ 7♠ 7♣)</span>
            <span><b>Sequência:</b> mesmo naipe, em ordem (4♦ 5♦ 6♦). Vale A-2-3 e Q-K-A, mas não K-A-2.</span>
          </div>
        </li>
        <li>A carta que você pegou do lixo <b>não pode voltar</b> para o lixo na mesma jogada.</li>
        <li><b>Pifado</b> é quando falta só uma carta. Se <b>qualquer pessoa</b> descartar a carta que você precisa, você pode <b>bater com ela</b> na hora. Se dois puderem, ganha quem é o próximo da vez.</li>
        <li>Quando o monte acaba, o lixo é embaralhado de novo.</li>
      </ol>
      <p className="form-hint">Dica: arraste as cartas para organizar a mão e solte uma carta em cima do lixo para descartar.</p>
      <button type="button" className="button button-primary full-button" onClick={onClose}>Entendi</button>
    </section>
  </div>
}

// ------------------------------------------------------------------ tela

export function TrainingScreen({ onBack }: { onBack: () => void }) {
  const [prefs, setPrefsState] = useState<Prefs>(() => load(PREFS_KEY, defaultPrefs))
  const [stats, setStats] = useState<Stats>(() => load(STATS_KEY, emptyStats))
  const [saved, setSaved] = useState<Saved | null>(loadSaved)
  const [game, setGame] = useState<TGame | null>(null)
  const [series, setSeries] = useState<Series | null>(null)
  const [selected, setSelected] = useState<string | null>(null)
  const [notice, setNotice] = useState('')
  const [rulesOpen, setRulesOpen] = useState(() => !load<{ seen?: boolean }>(RULES_KEY, {}).seen)
  const [pileOpen, setPileOpen] = useState(false)
  const [flights, setFlights] = useState<Flight[]>([])
  const [pileHover, setPileHover] = useState(false)
  const [copied, setCopied] = useState(false)
  const [dealing, setDealing] = useState(false)
  const [newAchievements, setNewAchievements] = useState<Achievement[]>([])
  const [replayOpen, setReplayOpen] = useState(false)
  const [tutorialStep, setTutorialStep] = useState<TutorialStep | null>(null)
  const frames = useRef<TGame[]>([])
  const statsRef = useRef(stats)
  statsRef.current = stats
  const [pull, setPull] = useState<{ source: 'deck' | 'pile'; x: number; y: number; startX: number; startY: number; moved: boolean } | null>(null)
  const pullRef = useRef(pull)
  pullRef.current = pull
  const look = useLook()

  const deckRef = useRef<HTMLButtonElement>(null)
  const pileRef = useRef<HTMLDivElement>(null)
  const handRef = useRef<HTMLDivElement>(null)
  const opponentRefs = useRef<(HTMLDivElement | null)[]>([])
  const gameRef = useRef<TGame | null>(null)
  gameRef.current = game

  const setPrefs = (patch: Partial<Prefs>) => setPrefsState((current) => {
    const next = { ...current, ...patch }
    save(PREFS_KEY, next)
    return next
  })

  const today = todayKey()
  const goal = useMemo(() => dailyGoal(today), [today])
  const delays = SPEED[prefs.speed]

  // Partida em andamento fica salva para continuar depois.
  useEffect(() => {
    if (!game) return
    if (game.phase === 'over') save(SAVE_KEY, null)
    else save(SAVE_KEY, { game, series })
  }, [game, series])

  // ---------------------------------------------------------------- efeitos visuais

  const fly = useCallback((items: (Flight | null)[]) => {
    const valid = items.filter((item): item is Flight => Boolean(item))
    if (valid.length) setFlights((current) => [...current, ...valid])
  }, [])
  const doneFlight = useCallback((id: number) => setFlights((current) => current.filter((flight) => flight.id !== id)), [])

  const placeOf = useCallback((player: number) => (player === 0 ? rectOf(handRef.current) : rectOf(opponentRefs.current[player - 1])), [])

  /** Aplica um passo do motor: atualiza o jogo, anima as cartas e toca os sons. */
  const apply = useCallback((step: Step, from?: DOMRect | null) => {
    const current = gameRef.current
    const open = current?.config.openHands ?? false
    const moves: (Flight | null)[] = []
    for (const event of step.events) {
      if (event.kind === 'draw-deck') {
        moves.push(makeFlight(event.player === 0 || open ? event.card : null, rectOf(deckRef.current), placeOf(event.player)))
        if (prefs.sound && event.player === 0) sounds.draw()
      } else if (event.kind === 'draw-pile') {
        moves.push(makeFlight(event.card, rectOf(pileRef.current), placeOf(event.player)))
        if (prefs.sound && event.player === 0) sounds.draw()
      } else if (event.kind === 'discard') {
        moves.push(makeFlight(event.card, event.player === 0 ? from ?? rectOf(handRef.current) : placeOf(event.player), rectOf(pileRef.current)))
        if (prefs.sound) sounds.discard()
      } else if (event.kind === 'win' && prefs.sound) {
        if (event.player === 0) sounds.win()
        else sounds.lose()
      } else if (event.kind === 'reshuffle') {
        setNotice('O monte acabou e o lixo foi embaralhado de novo.')
      }
    }
    fly(moves)
    if (frames.current.length < 800 && (!frames.current.length || frames.current[0].id === step.game.id)) frames.current.push(step.game)
    setGame(step.game)
  }, [fly, placeOf, prefs.sound])

  const run = useCallback((result: Result, from?: DOMRect | null) => {
    if ('error' in result) {
      setNotice(result.error)
      return false
    }
    setNotice('')
    apply(result, from)
    return true
  }, [apply])

  // ---------------------------------------------------------------- robôs e batida pelo descarte

  const turnKey = game ? `${game.id}|${game.turn}|${game.phase}|${game.claim?.pos ?? ''}|${game.claim?.userWindow ?? ''}` : ''
  useEffect(() => {
    const current = gameRef.current
    if (!current || current.phase === 'over') return
    if (current.phase === 'claim') {
      const wait = current.claim?.userWindow ? delays.window : delays.check
      const timer = window.setTimeout(() => {
        const latest = gameRef.current
        if (latest && latest.phase === 'claim') apply(advanceClaim(latest))
      }, wait)
      return () => window.clearTimeout(timer)
    }
    if (!current.players[current.turn].bot) return
    const timer = window.setTimeout(() => {
      const latest = gameRef.current
      if (latest && latest.players[latest.turn].bot && latest.phase !== 'over' && latest.phase !== 'claim') apply(botStep(latest))
    }, current.phase === 'draw' ? delays.step : delays.step * 0.8)
    return () => window.clearTimeout(timer)
  }, [turnKey, delays, apply])

  // Toca um aviso quando sai a carta que você espera.
  const claimChance = Boolean(game?.phase === 'claim' && game.claim && game.claim.discarder !== 0 && game.claim.order.indexOf(0) >= game.claim.pos && canWinWith(game.players[0].hand, game.claim.card))
  useEffect(() => {
    if (claimChance && prefs.sound && prefs.hints) sounds.chance()
  }, [claimChance, prefs.sound, prefs.hints])

  // ---------------------------------------------------------------- estatísticas

  const recorded = useRef<string | null>(null)
  useEffect(() => {
    if (!game || game.phase !== 'over' || recorded.current === game.id) return
    recorded.current = game.id
    let seriesWon = false
    if (series) {
      const scores = [...series.scores]
      if (game.winner !== undefined) scores[game.winner] = (scores[game.winner] ?? 0) + 1
      seriesWon = scores[0] >= Math.ceil(series.target / 2)
      setSeries({ ...series, scores })
    }
    if (game.config.tutorial) {
      setTutorialStep(6)
      return
    }
    if (game.config.openHands) return // modo aula não conta
    const current = statsRef.current
    const won = game.winner === 0
    const next: Stats = {
      ...current,
      played: current.played + 1,
      won: current.won + (won ? 1 : 0),
      byClaim: current.byClaim + (won && game.winVia === 'descarte' ? 1 : 0),
      winDraws: current.winDraws + (won ? game.draws : 0),
      fastest: won ? Math.min(current.fastest ?? Infinity, game.draws) : current.fastest,
      streak: won ? current.streak + 1 : 0,
      bestStreak: won ? Math.max(current.bestStreak, current.streak + 1) : current.bestStreak,
      bestSolo: won && game.config.mode === 'solo' && !game.config.daily ? Math.min(current.bestSolo ?? Infinity, game.draws) : current.bestSolo,
      daily: won && game.config.daily ? { ...current.daily, [game.config.daily.date]: Math.min(current.daily[game.config.daily.date] ?? Infinity, game.draws) } : current.daily,
    }
    setStats(next)
    save(STATS_KEY, next)
    const earned = checkAchievements({ game, won: next.won, streak: next.streak, hints: prefs.hints, seriesWon })
    setNewAchievements(earned)
    if (earned.length && prefs.sound) window.setTimeout(() => sounds.chance(), 600)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game, series])

  // ---------------------------------------------------------------- ações

  function start(config?: Partial<Config>, keepSeries = false) {
    const full: Config = { mode: prefs.mode, bots: prefs.bots, difficulty: prefs.difficulty, openHands: prefs.openHands, series: prefs.series, ...config }
    const next = newGame(full, keepSeries ? game?.players : undefined, undefined, full.tutorial ? tutorialDeck() : undefined)
    frames.current = [next]
    setNewAchievements([])
    setTutorialStep(full.tutorial ? 0 : null)
    if (!keepSeries) setSeries(full.mode === 'bots' && full.series > 1 && !full.daily ? { target: full.series, scores: next.players.map(() => 0) } : null)
    recorded.current = null
    setGame(next)
    setSelected(null)
    setNotice('')
    setSaved(null)
    dealAnimation()
  }

  /** Embaralha e distribui na tela (só visual). */
  function dealAnimation() {
    setDealing(true)
    if (prefs.sound) for (let i = 0; i < 6; i += 1) window.setTimeout(() => sounds.draw(), 120 + i * 110)
    window.setTimeout(() => setDealing(false), 1300)
  }

  function startTutorial() {
    start({ mode: 'solo', bots: 0, openHands: false, series: 1, daily: undefined, tutorial: true })
  }

  function startDaily() {
    start({ mode: 'solo', bots: 0, openHands: false, series: 1, daily: { date: today, goal } })
  }

  function resume() {
    if (!saved) return
    frames.current = [saved.game]
    setTutorialStep(saved.game.config.tutorial ? 2 : null)
    setGame(saved.game)
    setSeries(saved.series)
    setSaved(null)
  }

  const me = game?.players[0]
  const myTurn = Boolean(game && game.turn === 0 && (game.phase === 'draw' || game.phase === 'discard'))
  const top = game?.discard[game.discard.length - 1]

  // Comprar arrastando: segure no monte ou no lixo e solte em cima da sua mão.
  function pullStart(source: 'deck' | 'pile', event: React.PointerEvent) {
    if (!game || !myTurn || game.phase !== 'draw') return
    if (source === 'pile' && (!top || game.config.tutorial)) return
    setPull({ source, x: event.clientX, y: event.clientY, startX: event.clientX, startY: event.clientY, moved: false })
  }
  useEffect(() => {
    if (!pull) return
    const move = (event: PointerEvent) => setPull((current) => current && { ...current, x: event.clientX, y: event.clientY, moved: current.moved || Math.hypot(event.clientX - current.startX, event.clientY - current.startY) > 14 })
    const up = (event: PointerEvent) => {
      const current = pullRef.current
      setPull(null)
      if (!current?.moved) return
      const hand = handRef.current?.getBoundingClientRect()
      const latest = gameRef.current
      if (!hand || !latest || event.clientY < hand.top - 30) return
      run(current.source === 'deck' ? drawDeck(latest, 0) : drawPile(latest, 0))
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pull?.source])

  function onDeck() {
    if (!game || !myTurn || game.phase !== 'draw') return
    run(drawDeck(game, 0))
  }

  function discardById(id: string, from?: DOMRect | null) {
    if (!game) return
    if (game.config.tutorial && tutorialStep === 3) {
      const card = game.players[0].hand.find((item) => item.id === id)
      if (card && !(card.rank === 9 && card.suit === 'H')) {
        setNotice('No tutorial, descarte o 9♥ (ele não forma jogo com nada).')
        return
      }
    }
    if (run(discardCard(game, 0, id), from)) setSelected(null)
  }

  function onPile() {
    if (!game) return
    if (game.phase === 'claim') {
      tryClaim()
      return
    }
    if (!myTurn) return
    if (game.phase === 'draw') {
      if (game.config.tutorial) {
        setNotice('No tutorial, compre do monte (a carta virada).')
        return
      }
      run(drawPile(game, 0))
      return
    }
    if (selected) {
      const element = handRef.current?.querySelector(`[data-card="${selected}"]`)
      discardById(selected, element?.getBoundingClientRect() ?? null)
    } else {
      setNotice('Escolha uma carta da mão e toque no lixo (ou arraste a carta até ele).')
    }
  }

  function onDiscardButton() {
    if (!selected) {
      setNotice('Toque numa carta da sua mão para escolher o descarte.')
      return
    }
    const element = handRef.current?.querySelector(`[data-card="${selected}"]`)
    discardById(selected, element?.getBoundingClientRect() ?? null)
  }

  function onWin() {
    if (!game) return
    run(declareWin(game, 0))
  }

  function tryClaim() {
    if (!game) return
    run(userClaim(game))
  }

  function reorder(mode: 'naipe' | 'valor' | 'jogos' | Card[]) {
    if (!game || !me) return
    const hand = Array.isArray(mode) ? mode : mode === 'jogos' ? sortByGames(me.hand) : sortHand(me.hand, mode)
    setGame({ ...game, players: game.players.map((player, index) => (index === 0 ? { ...player, hand } : player)) })
  }

  function closeRules() {
    setRulesOpen(false)
    save(RULES_KEY, { seen: true })
  }

  // ---------------------------------------------------------------- dicas

  const hints = prefs.hints || Boolean(game?.config.tutorial)
  const inGames = useMemo(() => (me && hints ? cardsInGames(me.hand) : new Set<string>()), [me, hints])
  const suggested = useMemo(() => (game && me && hints && myTurn && game.phase === 'discard' ? bestDiscard(me.hand, game.forbiddenId).id : null), [game, me, hints, myTurn])
  const canWin = useMemo(() => (game && me && myTurn && game.phase === 'discard' ? Boolean(findWinningDiscard(me.hand)) : false), [game, me, myTurn])
  const waiting = useMemo(() => (game && me && hints && me.hand.length === 9 ? waitingCards(me.hand) : []), [game, me, hints])
  const selectedCard = me?.hand.find((card) => card.id === selected)
  const counter = game && prefs.counter && selectedCard ? seenCopies(game, selectedCard.rank, selectedCard.suit) : null
  const claimOpen = Boolean(game?.phase === 'claim' && game.claim && game.claim.discarder !== 0 && game.claim.order.indexOf(0) >= game.claim.pos)
  const showClaimButton = claimOpen && (!hints || claimChance)

  // Tutorial: avança sozinho conforme a pessoa faz cada passo.
  const tutorialKey = game?.config.tutorial ? `${game.draws}|${game.phase}` : ''
  useEffect(() => {
    if (!tutorialKey || !game || game.phase === 'over') return
    setTutorialStep((step) => {
      if (step === null || step === 6) return step
      if (game.draws >= 2 && game.phase === 'discard') return 5
      if (game.draws === 1 && game.phase === 'draw') return 4
      if (game.draws === 1 && game.phase === 'discard') return 3
      return step < 2 ? step : 2
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tutorialKey])

  // ---------------------------------------------------------------- configuração
  if (!game) {
    const winRate = stats.played ? Math.round((100 * stats.won) / stats.played) : 0
    const avg = stats.won ? (stats.winDraws / stats.won).toFixed(1) : '—'
    const bestToday = stats.daily[today]
    return <main className="gate-shell training-shell">
      <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
      <section className="gate-panel training-setup">
        <div className="training-setup-top">
          <button type="button" className="text-action back-action" onClick={onBack}><ArrowLeft size={15} /> Voltar ao início</button>
          <span className="training-setup-links"><button type="button" className="text-action" onClick={() => setRulesOpen(true)}><BookOpen size={15} /> Regras</button><HelpButton topic="treino" /></span>
        </div>
        <span className="section-kicker">MODO TREINO · SEM DINHEIRO</span>
        <h1>Treinar Pif</h1>

        {saved && <button type="button" className="button button-primary full-button" onClick={resume}><Play size={16} /> Continuar partida ({saved.game.config.daily ? 'desafio do dia' : saved.game.config.mode === 'solo' ? 'sozinho' : plural(saved.game.players.length - 1, 'robô', 'robôs')}, {plural(saved.game.draws, 'compra', 'compras')})</button>}

        <button type="button" className="button button-secondary full-button tutorial-start" onClick={startTutorial}><BookOpen size={16} /> Tutorial: aprender a jogar em 1 minuto</button>

        <div className="daily-card">
          <CalendarDays size={20} />
          <div><strong>Desafio do dia · {shortDate(today)}</strong><small>Mesma mão para todo mundo hoje. Meta: bater em até {goal} compras.{bestToday ? ` Seu melhor: ${bestToday}.` : ''}</small></div>
          <button type="button" className="button button-secondary" onClick={startDaily}>Jogar</button>
        </div>

        <div className="layout-options" role="radiogroup" aria-label="Modo">
          <button type="button" role="radio" aria-checked={prefs.mode === 'bots'} className={`layout-option ${prefs.mode === 'bots' ? 'selected' : ''}`} onClick={() => setPrefs({ mode: 'bots' })}><Bot size={20} /><strong>Contra o computador</strong><small>Robôs compram, descartam e batem</small></button>
          <button type="button" role="radio" aria-checked={prefs.mode === 'solo'} className={`layout-option ${prefs.mode === 'solo' ? 'selected' : ''}`} onClick={() => setPrefs({ mode: 'solo' })}><Spade size={20} /><strong>Sozinho</strong><small>Bata com o menor número de compras</small></button>
        </div>

        {prefs.mode === 'bots' && <>
          <div className="setting-field">Quantos robôs?<div className="felt-options">{[1, 2, 3].map((count) => <button type="button" key={count} className={`felt-option ${prefs.bots === count ? 'selected' : ''}`} onClick={() => setPrefs({ bots: count })}>{count}</button>)}</div></div>
          <div className="setting-field">Dificuldade<div className="felt-options">{(['facil', 'normal', 'dificil', 'mestre'] as Difficulty[]).map((level) => <button type="button" key={level} className={`felt-option ${prefs.difficulty === level ? 'selected' : ''}`} onClick={() => setPrefs({ difficulty: level })}>{difficultyLabel[level]}</button>)}</div>
            <small className="setting-help">Difícil: lembra o que já saiu e evita entregar carta. Mestre: além disso, pensa nas próximas compras antes de descartar.</small></div>
          <div className="setting-field">Partidas<div className="felt-options">{([1, 3, 5] as const).map((count) => <button type="button" key={count} className={`felt-option ${prefs.series === count ? 'selected' : ''}`} onClick={() => setPrefs({ series: count })}>{count === 1 ? 'Uma só' : `Melhor de ${count}`}</button>)}</div></div>
          <div className="setting-field">Velocidade dos robôs<div className="felt-options">{(['lenta', 'normal', 'rapida'] as Speed[]).map((speed) => <button type="button" key={speed} className={`felt-option ${prefs.speed === speed ? 'selected' : ''}`} onClick={() => setPrefs({ speed })}>{speedLabel[speed]}</button>)}</div></div>
          <label className="solo-toggle"><input id="training-open" type="checkbox" checked={prefs.openHands} onChange={(event) => setPrefs({ openHands: event.target.checked })} /><span><strong>Modo aula (cartas dos robôs abertas)</strong><small>Para aprender como eles jogam. Não conta nas estatísticas.</small></span></label>
        </>}

        <label className="solo-toggle"><input id="training-hints" type="checkbox" checked={prefs.hints} onChange={(event) => setPrefs({ hints: event.target.checked })} /><span><strong>Mostrar dicas</strong><small>Marca jogos prontos, sugere o descarte, avisa quando está pifado e quando dá para bater.</small></span></label>
        <label className="solo-toggle"><input id="training-counter" type="checkbox" checked={prefs.counter} onChange={(event) => setPrefs({ counter: event.target.checked })} /><span><strong>Contador de cartas</strong><small>Ao tocar numa carta, mostra quantas cópias dela já apareceram.</small></span></label>

        <details className="training-appearance">
          <summary>Aparência e som</summary>
          <div className="setting-field">Feltro<div className="felt-options">{FELTS.map((felt) => <button type="button" key={felt} className={`felt-option felt-${felt} ${look.felt === felt ? 'selected' : ''}`} onClick={() => setLook({ felt })}><span />{FELT_LABEL[felt]}</button>)}</div></div>
          <div className="setting-field">Verso das cartas<div className="felt-options">{BACKS.map((back) => <button type="button" key={back} className={`felt-option back-${back} ${prefs.back === back ? 'selected' : ''}`} onClick={() => setPrefs({ back })}><span />{back[0].toUpperCase() + back.slice(1)}</button>)}</div></div>
          <label className="solo-toggle"><input id="training-sound" type="checkbox" checked={prefs.sound} onChange={(event) => setPrefs({ sound: event.target.checked })} /><span><strong>Som e vibração</strong><small>Ao comprar, descartar, quando sai a carta que você espera e ao bater.</small></span></label>
        </details>

        <button type="button" className="button button-primary full-button" onClick={() => start()}><Shuffle size={16} /> Embaralhar e começar</button>

        <section className="training-statsbox" aria-label="Estatísticas do treino">
          <span className="section-kicker">SUAS ESTATÍSTICAS</span>
          <div className="stats-grid">
            <div className="stat-card"><span>Partidas</span><strong>{stats.played}</strong><small>{stats.won} vitórias ({winRate}%)</small></div>
            <div className="stat-card"><span>Média para bater</span><strong>{avg}</strong><small>compras</small></div>
            <div className="stat-card"><span>Mais rápida</span><strong>{stats.fastest ?? '—'}</strong><small>compras</small></div>
            <div className="stat-card"><span>Sequência</span><strong>{stats.streak}</strong><small>melhor: {stats.bestStreak}</small></div>
            <div className="stat-card"><span>Bateu pelo lixo</span><strong>{stats.byClaim}</strong><small>com descarte de outro</small></div>
            <div className="stat-card"><span>Recorde sozinho</span><strong>{stats.bestSolo ?? '—'}</strong><small>compras</small></div>
          </div>
        </section>
        <section className="achievements-box" aria-label="Conquistas">
          <span className="section-kicker">CONQUISTAS · {Object.keys(unlockedAchievements()).length} DE {ACHIEVEMENTS.length}</span>
          <div className="achievements-grid">{ACHIEVEMENTS.map((item) => {
            const done = Boolean(unlockedAchievements()[item.id])
            return <div key={item.id} className={`achievement ${done ? 'done' : ''}`} title={item.text}><span aria-hidden="true">{done ? item.icon : '🔒'}</span><strong>{item.title}</strong><small>{item.text}</small></div>
          })}</div>
        </section>
      </section>
      {rulesOpen && <RulesModal onClose={closeRules} />}
    </main>
  }

  // ---------------------------------------------------------------- partida
  const opponents = game.players.slice(1)
  const decided = series ? series.scores.some((score) => score >= Math.ceil(series.target / 2)) : true
  const title = game.config.tutorial ? 'Tutorial' : game.config.daily ? `Desafio ${shortDate(game.config.daily.date)}` : game.config.mode === 'solo' ? 'Treino sozinho' : `Treino · ${difficultyLabel[game.config.difficulty]}`

  return <main className={`training-table back-${prefs.back}`}>
    <header className="training-top">
      <button type="button" className="share-button" onClick={() => { setGame(null); setSelected(null); setSaved(game.phase === 'over' ? null : { game, series }) }} title="Sair (a partida fica salva)"><ArrowLeft size={16} /><span>Sair</span></button>
      <strong className="training-title">{title}{game.config.openHands ? ' · aula' : ''}</strong>
      <div className="training-top-actions">
        {game.config.mode === 'bots' && <button type="button" className="icon-chip" onClick={() => setPrefs({ speed: prefs.speed === 'lenta' ? 'normal' : prefs.speed === 'normal' ? 'rapida' : 'lenta' })} title="Velocidade dos robôs"><Gauge size={15} /> {speedLabel[prefs.speed]}</button>}
        <button type="button" className="icon-chip" onClick={() => setPrefs({ sound: !prefs.sound })} aria-label={prefs.sound ? 'Desligar som' : 'Ligar som'}>{prefs.sound ? <Volume2 size={15} /> : <VolumeX size={15} />}</button>
        <button type="button" className="icon-chip" onClick={() => setRulesOpen(true)} aria-label="Regras"><BookOpen size={15} /></button>
        <HelpButton topic="treino-jogo" />
        <span className="training-count">{plural(game.draws, 'compra', 'compras')}{game.config.daily ? ` · meta ${game.config.daily.goal}` : ''}</span>
      </div>
    </header>

    {series && <div className="series-bar" aria-label="Placar da série">
      <span>Melhor de {series.target}:</span>
      {game.players.map((player, index) => <b key={player.name} className={index === 0 ? 'me' : ''}>{index === 0 ? 'Você' : player.name.replace('Robô ', '')} {series.scores[index] ?? 0}</b>)}
    </div>}

    {opponents.length > 0 && <div className="training-opponents">
      {opponents.map((player, index) => {
        const turn = game.turn === index + 1 && (game.phase === 'draw' || game.phase === 'discard')
        const knownCards = player.hand.filter((card) => player.known.includes(card.id))
        return <div key={player.name} ref={(element) => { opponentRefs.current[index] = element }} className={`training-opponent ${turn ? 'is-turn' : ''} ${game.winner === index + 1 ? 'is-winner' : ''}`}>
          <span className="training-opponent-name"><Bot size={14} /> {player.name}</span>
          <small className="training-personality">{personalityLabel[player.personality]}</small>
          {game.config.openHands
            ? <span className="training-open-hand">{sortByGames(player.hand).map((card) => <PlayingCard key={card.id} card={card} tiny />)}</span>
            : <span className={`training-backs ${dealing ? 'is-dealing' : ''}`}>{player.hand.map((card, cardIndex) => <i key={card.id} style={{ '--i': cardIndex } as React.CSSProperties} />)}</span>}
          {!game.config.openHands && knownCards.length > 0 && <span className="training-known" title="Cartas que ele pegou do lixo">do lixo: {knownCards.map(cardLabel).join(' ')}</span>}
          <small>{turn ? 'pensando...' : plural(player.hand.length, 'carta', 'cartas')}</small>
        </div>
      })}
    </div>}

    <div className="training-middle">
    <div className="training-center">
      <button ref={deckRef} type="button" className={`training-pile ${myTurn && game.phase === 'draw' ? 'can-take' : ''} ${dealing ? 'is-shuffling' : ''}`} onClick={onDeck} onPointerDown={(event) => pullStart('deck', event)} disabled={!myTurn || game.phase !== 'draw'} aria-label={`Comprar do monte (${game.deck.length} cartas)`}>
        <CardBack />
        <small>Monte · {game.deck.length}</small>
      </button>
      <div ref={pileRef} className={`training-pile pile-drop ${myTurn && game.phase === 'draw' && top ? 'can-take' : ''} ${myTurn && game.phase === 'discard' && selected ? 'can-drop' : ''} ${pileHover ? 'is-hover' : ''} ${claimChance && hints ? 'claim-glow' : ''}`} onPointerDown={(event) => pullStart('pile', event)}>
        {top ? <PlayingCard card={top} onClick={onPile} /> : <span className="pcard pcard-empty" onClick={onPile} />}
        <button type="button" className="pile-view" onClick={() => setPileOpen(true)}><Eye size={12} /> Lixo · ver</button>
      </div>
    </div>

    {showClaimButton && game.claim && <button type="button" className={`claim-button ${claimChance ? 'can-win' : ''}`} onClick={tryClaim}>
      <Trophy size={18} /> BATER com o {cardLabel(game.claim.card)}!
    </button>}

    <p className="training-log" role="status">{game.log}</p>
    {notice && <p className="training-notice" role="alert">{notice}</p>}
    {hints && waiting.length > 0 && game.phase !== 'over' && <p className="pifado-banner">
      <b>Pifado!</b> Espera: {waiting.map((need) => {
        const left = seenCopies(game, need.rank, need.suit).left
        return <span key={`${need.rank}${need.suit}`} className={left === 0 ? 'dead' : ''}>{cardLabel({ id: '', ...need })} <small>({left === 0 ? 'nenhuma resta' : left === 1 ? '1 resta' : '2 restam'})</small></span>
      })}
    </p>}
    </div>

    {tutorialStep !== null && tutorialStep < 6 && game.phase !== 'over' && <TutorialBubble step={tutorialStep} onNext={() => setTutorialStep((step) => (step === null ? step : (Math.min(2, step + 1) as TutorialStep)))} onSkip={() => { setGame(null); setTutorialStep(null) }} />}

    {me && <section className="training-hand-area" ref={handRef}>
      <HandView
        hand={me.hand}
        selected={selected}
        drawnId={game.turn === 0 ? game.drawnId : undefined}
        hints={hints}
        inGames={inGames}
        suggested={suggested}
        pileRef={pileRef}
        canDropOnPile={myTurn && game.phase === 'discard'}
        onSelect={(id) => setSelected(selected === id ? null : id)}
        onReorder={(hand) => reorder(hand)}
        onDropOnPile={(id, rect) => discardById(id, rect)}
        onPileHover={setPileHover}
        dealing={dealing}
      />
      {counter && selectedCard && <p className="counter-line">{cardLabel(selectedCard)}: {counter.mine} na sua mão · {counter.inPile} no lixo · {counter.withBots} com robôs · <b>{counter.left === 0 ? 'nenhuma cópia resta' : counter.left === 1 ? '1 cópia ainda pode sair' : '2 cópias ainda podem sair'}</b></p>}
      <div className="training-actions">
        <button type="button" className="button button-secondary" onClick={() => reorder('jogos')}><Layers size={15} /> Por jogos</button>
        <button type="button" className="button button-secondary" onClick={() => reorder('naipe')}>Naipe</button>
        <button type="button" className="button button-secondary" onClick={() => reorder('valor')}>Número</button>
        <button type="button" className={`button button-secondary ${hints ? 'is-on' : ''}`} onClick={() => setPrefs({ hints: !hints })}><Lightbulb size={15} /> Dica</button>
      </div>
      <div className="training-actions">
        <button type="button" className="button button-primary" disabled={!myTurn || game.phase !== 'discard'} onClick={onDiscardButton}>Descartar {selectedCard ? cardLabel(selectedCard) : ''}</button>
        <button type="button" className={`button button-finish ${hints && canWin ? 'can-win' : ''}`} disabled={!myTurn || game.phase !== 'discard'} onClick={onWin}><Trophy size={15} /> Bater</button>
      </div>
      {hints && <p className="form-hint training-legend"><span className="legend-game" /> já forma jogo · <span className="legend-discard" /> sugestão de descarte · arraste para organizar</p>}
    </section>}

    {pileOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPileOpen(false) }}>
      <section className="modal pile-modal" role="dialog" aria-modal="true" aria-labelledby="pile-title">
        <div className="modal-heading"><div><span className="section-kicker">LIXO</span><h2 id="pile-title">Últimas cartas descartadas</h2></div><button className="icon-button" onClick={() => setPileOpen(false)} aria-label="Fechar"><X size={19} /></button></div>
        <div className="pile-list">{[...game.discard].reverse().slice(0, 18).map((card, index) => <div key={card.id} className="pile-item"><PlayingCard card={card} small />{index === 0 && <small>em cima</small>}</div>)}</div>
        <p className="form-hint">{plural(game.discard.length, 'carta', 'cartas')} no lixo agora · {plural(game.history.length, 'descarte', 'descartes')} na partida.</p>
      </section>
    </div>}

    {game.phase === 'over' && <div className="modal-backdrop" role="presentation">
      <section className="modal training-result" role="dialog" aria-modal="true" aria-labelledby="training-result-title">
        <span className="section-kicker">{game.winner === 0 ? 'PARABÉNS' : game.winner === undefined ? 'FIM' : 'FIM DA PARTIDA'}</span>
        <h2 id="training-result-title">{game.winner === undefined ? 'Ninguém bateu' : game.winner === 0 ? 'Você bateu!' : `${game.players[game.winner].name} bateu`}</h2>
        <p className="form-hint">
          {game.winVia === 'descarte' && game.winCard ? `Com o ${cardLabel(game.winCard)} que saiu no lixo. ` : ''}
          {game.winner === 0 ? `Com ${plural(game.draws, 'compra', 'compras')}.` : ''}
          {game.config.daily && game.winner === 0 ? (game.draws <= game.config.daily.goal ? ' Meta do dia batida! ✅' : ` A meta era ${game.config.daily.goal}.`) : ''}
        </p>
        {game.winGames && <div className="training-games is-reveal">{game.winGames.map((triple, index) => <div className="training-game" key={index} style={{ '--g': index } as React.CSSProperties}>{triple.map((card) => <PlayingCard key={card.id} card={card} small />)}</div>)}</div>}

        {game.config.tutorial && <p className="tutorial-done"><b>Tutorial completo!</b> Agora jogue contra os robôs. Lembre: se alguém descartar a carta que você espera, você também pode bater com ela.</p>}
        {newAchievements.length > 0 && <div className="new-achievements"><span className="section-kicker">NOVA CONQUISTA</span>{newAchievements.map((item) => <div key={item.id} className="achievement done is-new"><span aria-hidden="true">{item.icon}</span><strong>{item.title}</strong><small>{item.text}</small></div>)}</div>}

        {series && <p className="series-result">{game.players.map((player, index) => `${index === 0 ? 'Você' : player.name.replace('Robô ', '')} ${series.scores[index] ?? 0}`).join(' · ')}{decided ? (series.scores[0] >= Math.ceil(series.target / 2) ? ' — você venceu a série! 🏆' : ' — série encerrada') : ''}</p>}

        {opponents.length > 0 && <details className="bot-hands" open={game.winner !== 0}>
          <summary>Mãos dos robôs</summary>
          {opponents.map((player) => <div key={player.name} className="bot-hand"><small>{player.name} ({personalityLabel[player.personality]})</small><div>{sortByGames(player.hand).map((card) => <PlayingCard key={card.id} card={card} tiny />)}</div></div>)}
        </details>}

        {game.config.daily && game.winner === 0 && <button type="button" className="button button-secondary full-button" onClick={() => {
          const text = `Pif da Mesa · Desafio ${shortDate(game.config.daily!.date)}: bati em ${game.draws} compras (meta ${game.config.daily!.goal}) ${game.draws <= game.config.daily!.goal ? '✅' : ''}`
          void navigator.clipboard?.writeText(text).then(() => { setCopied(true); window.setTimeout(() => setCopied(false), 1500) }).catch(() => setNotice(text))
        }}><Copy size={15} /> {copied ? 'Copiado!' : 'Copiar resultado para os amigos'}</button>}

        {series && !decided
          ? <button type="button" className="button button-primary full-button" onClick={() => start(game.config, true)}><Play size={16} /> Próxima partida da série</button>
          : <button type="button" className="button button-primary full-button" onClick={() => (game.config.tutorial ? start({ mode: 'bots', tutorial: false, daily: undefined }) : game.config.daily ? startDaily() : start())}><RotateCcw size={16} /> {game.config.tutorial ? 'Jogar contra os robôs' : series ? 'Nova série' : 'Jogar de novo'}</button>}
        {frames.current.length > 2 && <button type="button" className="button button-secondary full-button" onClick={() => setReplayOpen(true)}><Play size={15} /> Ver replay da partida</button>}
        <button type="button" className="button button-secondary full-button" onClick={() => setGame(null)}>Mudar o modo</button>
        <button type="button" className="text-action" onClick={onBack}>Voltar ao início</button>
      </section>
    </div>}

    {rulesOpen && <RulesModal onClose={closeRules} />}
    {replayOpen && <ReplayModal frames={frames.current} onClose={() => setReplayOpen(false)} />}
    <FlyLayer flights={flights} onDone={doneFlight} />
    {pull?.moved && <div className="pull-ghost" style={{ left: pull.x, top: pull.y }} aria-hidden="true">{pull.source === 'pile' && top ? <PlayingCard card={top} /> : <CardBack />}</div>}
  </main>
}
