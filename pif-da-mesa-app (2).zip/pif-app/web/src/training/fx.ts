// Efeitos do treino: cartas voando entre monte, lixo e mãos, sons curtos e vibração.
import type { Card } from '../lib/pif'

export type Flight = { id: number; card: Card | null; from: DOMRect; to: DOMRect; duration: number }

let nextId = 1
export function makeFlight(card: Card | null, from: DOMRect | null | undefined, to: DOMRect | null | undefined, duration = 380): Flight | null {
  if (!from || !to) return null
  if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return null
  return { id: nextId++, card, from, to, duration }
}

export const rectOf = (element: Element | null | undefined) => element?.getBoundingClientRect() ?? null

// ---------------------------------------------------------------- som

let audio: AudioContext | null = null
function tone(frequency: number, start: number, length: number, volume = 0.12, type: OscillatorType = 'sine') {
  try {
    audio ??= new AudioContext()
    const oscillator = audio.createOscillator()
    const gain = audio.createGain()
    oscillator.type = type
    oscillator.frequency.value = frequency
    const at = audio.currentTime + start
    gain.gain.setValueAtTime(volume, at)
    gain.gain.exponentialRampToValueAtTime(0.001, at + length)
    oscillator.connect(gain).connect(audio.destination)
    oscillator.start(at)
    oscillator.stop(at + length)
  } catch {
    // sem som neste aparelho
  }
}

function vibrate(pattern: number | number[]) {
  try {
    navigator.vibrate?.(pattern)
  } catch {
    // sem vibração
  }
}

export const sounds = {
  draw: () => tone(660, 0, 0.08, 0.07, 'triangle'),
  discard: () => tone(220, 0, 0.12, 0.12, 'triangle'),
  chance: () => { tone(880, 0, 0.12); tone(1175, 0.12, 0.16); vibrate([120, 60, 120]) },
  win: () => { [523, 659, 784, 1047].forEach((frequency, index) => tone(frequency, index * 0.11, 0.25, 0.12)); vibrate([200, 80, 200]) },
  lose: () => { tone(392, 0, 0.2, 0.1); tone(311, 0.2, 0.3, 0.1) },
  tap: () => vibrate(15),
}
