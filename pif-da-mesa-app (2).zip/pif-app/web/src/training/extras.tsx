// Replay da partida e balões do tutorial guiado.
import { useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight, Pause, Play, X } from 'lucide-react'
import { sortByGames } from '../lib/pif'
import type { TGame } from '../lib/treino'
import { CardBack, PlayingCard } from './cards'

/** Ver a partida jogada por jogada (todas as mãos abertas, porque a partida já acabou). */
export function ReplayModal({ frames, onClose }: { frames: TGame[]; onClose: () => void }) {
  const [index, setIndex] = useState(0)
  const [playing, setPlaying] = useState(false)
  const last = frames.length - 1
  useEffect(() => {
    if (!playing) return
    if (index >= last) {
      setPlaying(false)
      return
    }
    const timer = window.setTimeout(() => setIndex((value) => Math.min(last, value + 1)), 700)
    return () => window.clearTimeout(timer)
  }, [playing, index, last])
  const frame = frames[index]
  if (!frame) return null
  const top = frame.discard[frame.discard.length - 1]
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}>
    <section className="modal replay-modal" role="dialog" aria-modal="true" aria-labelledby="replay-title">
      <div className="modal-heading"><div><span className="section-kicker">REPLAY · JOGADA {index + 1} DE {frames.length}</span><h2 id="replay-title">{frame.log}</h2></div><button className="icon-button" onClick={onClose} aria-label="Fechar"><X size={19} /></button></div>
      <div className="replay-table">
        <div className="replay-piles"><span><CardBack small /><small>Monte · {frame.deck.length}</small></span><span>{top ? <PlayingCard card={top} small /> : <span className="pcard pcard-small pcard-empty" />}<small>Lixo</small></span></div>
        {frame.players.map((player, playerIndex) => <div key={player.name} className={`replay-player ${frame.turn === playerIndex && frame.phase !== 'over' ? 'is-turn' : ''} ${frame.winner === playerIndex ? 'is-winner' : ''}`}>
          <small>{player.name}{frame.winner === playerIndex ? ' · bateu!' : ''}</small>
          <div>{sortByGames(player.hand).map((card) => <PlayingCard key={card.id} card={card} tiny />)}</div>
        </div>)}
      </div>
      <input className="replay-slider" type="range" min={0} max={last} value={index} onChange={(event) => { setPlaying(false); setIndex(Number(event.target.value)) }} aria-label="Jogada" />
      <div className="replay-controls">
        <button type="button" className="button button-secondary" onClick={() => { setPlaying(false); setIndex(Math.max(0, index - 1)) }} aria-label="Jogada anterior"><ChevronLeft size={16} /></button>
        <button type="button" className="button button-primary" onClick={() => { if (index >= last) setIndex(0); setPlaying(!playing) }}>{playing ? <><Pause size={16} /> Pausar</> : <><Play size={16} /> Assistir</>}</button>
        <button type="button" className="button button-secondary" onClick={() => { setPlaying(false); setIndex(Math.min(last, index + 1)) }} aria-label="Próxima jogada"><ChevronRight size={16} /></button>
      </div>
    </section>
  </div>
}

export type TutorialStep = 0 | 1 | 2 | 3 | 4 | 5 | 6

export const TUTORIAL_TEXT: Record<TutorialStep, { title: string; text: string; next?: boolean }> = {
  0: { title: 'Bem-vindo ao Pif!', text: 'Estas são as suas 9 cartas. Ganha (bate) quem conseguir formar 3 jogos de 3 cartas.', next: true },
  1: { title: 'Seu primeiro jogo', text: 'Olhe o 7♥ 7♠ 7♣: é uma TRINCA (mesmo número, naipes diferentes). As cartas com faixa verde já formam jogo.', next: true },
  2: { title: 'Comprar', text: 'Toque no MONTE (a carta virada) para comprar. Você também pode arrastar a carta do monte até a sua mão.' },
  3: { title: 'Fechou uma sequência!', text: 'O 6♦ fechou 4♦ 5♦ 6♦ (SEQUÊNCIA: mesmo naipe, em ordem). Agora descarte o 9♥: arraste até o lixo ou toque duas vezes nele.' },
  4: { title: 'Você está pifado', text: 'Falta só uma carta! Q♠ K♠ fecha com J♠ ou com A♠ (Q-K-A vale). Veja o aviso "Pifado!" logo acima. Compre de novo no monte.' },
  5: { title: 'É agora!', text: 'Veio o A♠: Q♠ K♠ A♠ é sequência. Você tem 3 jogos. Toque em BATER!' },
  6: { title: 'Você aprendeu!', text: 'Pronto. Agora é jogar contra os robôs. Lembre: se alguém descartar a carta que você espera, você também pode bater com ela.' },
}

export function TutorialBubble({ step, onNext, onSkip }: { step: TutorialStep; onNext: () => void; onSkip: () => void }) {
  const content = TUTORIAL_TEXT[step]
  return <div className="tutorial-bubble" role="status">
    <span className="section-kicker">TUTORIAL · {step + 1}/7</span>
    <strong>{content.title}</strong>
    <p>{content.text}</p>
    <div className="tutorial-actions">
      <button type="button" className="text-action" onClick={onSkip}>Pular tutorial</button>
      {content.next && <button type="button" className="button button-primary" onClick={onNext}>Próximo</button>}
    </div>
  </div>
}
