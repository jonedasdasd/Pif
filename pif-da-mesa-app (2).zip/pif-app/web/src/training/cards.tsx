// Cartas, verso e a mão (tocar para escolher, arrastar para organizar ou para o lixo).
import { useLayoutEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent, type RefObject } from 'react'
import { cardLabel, isRed, rankLabel, SUIT_SYMBOL, type Card } from '../lib/pif'
import type { Flight } from './fx'

// Posição dos naipes no meio da carta (coluna 0-2, linha 0-1), como num baralho de verdade.
const PIPS: Record<number, [number, number][]> = {
  2: [[1, 0], [1, 1]],
  3: [[1, 0], [1, 0.5], [1, 1]],
  4: [[0, 0], [2, 0], [0, 1], [2, 1]],
  5: [[0, 0], [2, 0], [1, 0.5], [0, 1], [2, 1]],
  6: [[0, 0], [2, 0], [0, 0.5], [2, 0.5], [0, 1], [2, 1]],
  7: [[0, 0], [2, 0], [1, 0.25], [0, 0.5], [2, 0.5], [0, 1], [2, 1]],
  8: [[0, 0], [2, 0], [1, 0.25], [0, 0.5], [2, 0.5], [1, 0.75], [0, 1], [2, 1]],
  9: [[0, 0], [2, 0], [0, 1 / 3], [2, 1 / 3], [1, 0.5], [0, 2 / 3], [2, 2 / 3], [0, 1], [2, 1]],
  10: [[0, 0], [2, 0], [1, 1 / 6], [0, 1 / 3], [2, 1 / 3], [0, 2 / 3], [2, 2 / 3], [1, 5 / 6], [0, 1], [2, 1]],
}
const FACE: Record<number, string> = { 11: '♞', 12: '♛', 13: '♚' }

/** O desenho do meio da carta: naipes espalhados, Ás grande ou figura (J, Q, K). */
function CardArt({ card }: { card: Card }) {
  const symbol = SUIT_SYMBOL[card.suit]
  if (card.rank === 1) return <span className="pcard-ace">{symbol}</span>
  if (card.rank >= 11) return <span className="pcard-face"><b>{FACE[card.rank]}</b><i>{symbol}</i><em>{rankLabel(card.rank)}</em></span>
  return <span className="pcard-pips">{PIPS[card.rank].map(([col, row], index) => <i key={index} style={{ left: `${col * 50}%`, top: `${row * 100}%` }} className={row > 0.5 ? 'flip' : ''}>{symbol}</i>)}</span>
}

export function PlayingCard({ card, selected, hint, fresh, onClick, small, tiny }: { card: Card; selected?: boolean; hint?: 'game' | 'discard'; fresh?: boolean; onClick?: () => void; small?: boolean; tiny?: boolean }) {
  const symbol = SUIT_SYMBOL[card.suit]
  return <button type="button" className={`pcard ${isRed(card) ? 'pcard-red' : ''} ${selected ? 'pcard-selected' : ''} ${hint ? `pcard-hint-${hint}` : ''} ${small ? 'pcard-small' : ''} ${tiny ? 'pcard-tiny' : ''}`} onClick={onClick} aria-label={cardLabel(card)} aria-pressed={selected} tabIndex={onClick ? 0 : -1}>
    <span className="pcard-corner">{rankLabel(card.rank)}<br />{symbol}</span>
    {!tiny && <span className="pcard-corner pcard-corner-end">{rankLabel(card.rank)}<br />{symbol}</span>}
    {!tiny && !small && <CardArt card={card} />}
    {small && <span className="pcard-center">{symbol}</span>}
    {fresh && <span className="pcard-fresh" title="Carta nova">nova</span>}
  </button>
}

export function CardFace({ card }: { card: Card }) {
  const symbol = SUIT_SYMBOL[card.suit]
  return <span className={`pcard ${isRed(card) ? 'pcard-red' : ''}`}>
    <span className="pcard-corner">{rankLabel(card.rank)}<br />{symbol}</span>
    <span className="pcard-corner pcard-corner-end">{rankLabel(card.rank)}<br />{symbol}</span>
    <CardArt card={card} />
  </span>
}

export function CardBack({ small }: { small?: boolean }) {
  return <span className={`pcard pcard-back ${small ? 'pcard-small' : ''}`} aria-hidden="true"><span className="pcard-back-emblem">♠</span></span>
}

/** Camada das cartas voando (animação de compra e descarte). */
export function FlyLayer({ flights, onDone }: { flights: Flight[]; onDone: (id: number) => void }) {
  return <div className="fly-layer" aria-hidden="true">
    {flights.map((flight) => <FlyingCard key={flight.id} flight={flight} onDone={onDone} />)}
  </div>
}

function FlyingCard({ flight, onDone }: { flight: Flight; onDone: (id: number) => void }) {
  const ref = useRef<HTMLDivElement>(null)
  useLayoutEffect(() => {
    const element = ref.current
    if (!element) return
    const dx = flight.to.left + flight.to.width / 2 - (flight.from.left + flight.from.width / 2)
    const dy = flight.to.top + flight.to.height / 2 - (flight.from.top + flight.from.height / 2)
    const animation = element.animate(
      [{ transform: 'translate(0, 0) rotate(0deg)', opacity: 1 }, { transform: `translate(${dx}px, ${dy}px) rotate(${dx > 0 ? 6 : -6}deg)`, opacity: 0.95 }],
      { duration: flight.duration, easing: 'cubic-bezier(.25,.8,.3,1)', fill: 'forwards' },
    )
    animation.onfinish = () => onDone(flight.id)
    return () => animation.cancel()
  }, [flight, onDone])
  const left = flight.from.left + flight.from.width / 2
  const top = flight.from.top + flight.from.height / 2
  return <div ref={ref} className="fly-card" style={{ left, top }}>
    {flight.card ? <CardFace card={flight.card} /> : <CardBack />}
  </div>
}

type Drag = { id: string; startX: number; startY: number; dx: number; dy: number; moving: boolean; overPile: boolean }

/**
 * A mão do jogador. Toque escolhe a carta; arrastar muda a ordem; soltar em cima do lixo descarta.
 */
export function HandView({ hand, selected, drawnId, hints, inGames, suggested, pileRef, canDropOnPile, onSelect, onReorder, onDropOnPile, onPileHover, dealing = false }: {
  dealing?: boolean
  hand: Card[]
  selected: string | null
  drawnId?: string
  hints: boolean
  inGames: Set<string>
  suggested: string | null
  pileRef: RefObject<HTMLDivElement | null>
  canDropOnPile: boolean
  onSelect: (id: string) => void
  onReorder: (hand: Card[]) => void
  onDropOnPile: (id: string, rect: DOMRect | null) => void
  onPileHover: (over: boolean) => void
}) {
  const [drag, setDrag] = useState<Drag | null>(null)
  const container = useRef<HTMLDivElement>(null)
  const lastTap = useRef<{ id: string; at: number } | null>(null)

  function overPile(x: number, y: number) {
    const rect = pileRef.current?.getBoundingClientRect()
    if (!rect) return false
    return x > rect.left - 20 && x < rect.right + 20 && y > rect.top - 20 && y < rect.bottom + 20
  }

  function down(event: ReactPointerEvent<HTMLDivElement>, id: string) {
    if (event.button !== 0) return
    event.currentTarget.setPointerCapture(event.pointerId)
    setDrag({ id, startX: event.clientX, startY: event.clientY, dx: 0, dy: 0, moving: false, overPile: false })
  }

  function move(event: ReactPointerEvent<HTMLDivElement>) {
    if (!drag) return
    const dx = event.clientX - drag.startX
    const dy = event.clientY - drag.startY
    const moving = drag.moving || Math.hypot(dx, dy) > 8
    const over = moving && canDropOnPile && overPile(event.clientX, event.clientY)
    if (over !== drag.overPile) onPileHover(over)
    setDrag({ ...drag, dx, dy, moving, overPile: over })
  }

  function up(event: ReactPointerEvent<HTMLDivElement>) {
    if (!drag) return
    const current = drag
    setDrag(null)
    onPileHover(false)
    if (!current.moving) {
      // Toque duplo rápido na mesma carta: descarta direto.
      const now = Date.now()
      const previous = lastTap.current
      lastTap.current = { id: current.id, at: now }
      if (previous && previous.id === current.id && now - previous.at < 380 && canDropOnPile) {
        lastTap.current = null
        const element = container.current?.querySelector(`[data-card="${current.id}"]`)
        onDropOnPile(current.id, element?.getBoundingClientRect() ?? null)
        return
      }
      onSelect(current.id)
      return
    }
    if (current.overPile) {
      const element = container.current?.querySelector(`[data-card="${current.id}"]`)
      onDropOnPile(current.id, element?.getBoundingClientRect() ?? null)
      return
    }
    // Solta na mão: encaixa na posição onde o dedo parou.
    const others = [...(container.current?.querySelectorAll<HTMLElement>('[data-card]') ?? [])].filter((element) => element.dataset.card !== current.id)
    const index = others.findIndex((element) => {
      const rect = element.getBoundingClientRect()
      return event.clientX < rect.left + rect.width / 2
    })
    const moving = hand.find((card) => card.id === current.id)
    if (!moving) return
    const rest = hand.filter((card) => card.id !== current.id)
    const at = index < 0 ? rest.length : rest.findIndex((card) => card.id === others[index].dataset.card)
    rest.splice(at < 0 ? rest.length : at, 0, moving)
    onReorder(rest)
  }

  return <div className={`training-hand ${dealing ? 'is-dealing' : ''}`} ref={container}>
    {hand.map((card, index) => {
      const dragging = drag?.id === card.id && drag.moving
      return <div
        key={card.id}
        data-card={card.id}
        className={`hand-slot ${dragging ? 'is-dragging' : ''} ${dragging && drag?.overPile ? 'over-pile' : ''}`}
        style={dragging ? { transform: `translate(${drag!.dx}px, ${drag!.dy}px)` } : ({ '--i': index } as CSSProperties)}
        onPointerDown={(event) => down(event, card.id)}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={() => { setDrag(null); onPileHover(false) }}
      >
        <PlayingCard card={card} selected={selected === card.id} fresh={card.id === drawnId} hint={hints ? (suggested === card.id ? 'discard' : inGames.has(card.id) ? 'game' : undefined) : undefined} />
      </div>
    })}
  </div>
}
