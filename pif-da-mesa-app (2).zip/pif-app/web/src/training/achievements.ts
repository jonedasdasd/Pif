// Conquistas do treino: medalhas que a pessoa ganha jogando.
import { isTrinca, isSequencia } from '../lib/pif'
import type { TGame } from '../lib/treino'

export type Achievement = { id: string; icon: string; title: string; text: string }

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'primeira', icon: '🎉', title: 'Primeira batida', text: 'Bater pela primeira vez.' },
  { id: 'lixo', icon: '🦅', title: 'Olho de águia', text: 'Bater com a carta que outro descartou.' },
  { id: 'relampago', icon: '⚡', title: 'Relâmpago', text: 'Bater com 8 compras ou menos.' },
  { id: 'chamas', icon: '🔥', title: 'Em chamas', text: 'Ganhar 3 partidas seguidas.' },
  { id: 'imparavel', icon: '🚀', title: 'Imparável', text: 'Ganhar 5 partidas seguidas.' },
  { id: 'trincas', icon: '🎯', title: 'Trio de trincas', text: 'Bater com 3 trincas.' },
  { id: 'escadinha', icon: '🪜', title: 'Escadinha', text: 'Bater com 3 sequências.' },
  { id: 'sem-rodinhas', icon: '🚲', title: 'Sem rodinhas', text: 'Ganhar com as dicas desligadas.' },
  { id: 'mesa-cheia', icon: '👥', title: 'Mesa cheia', text: 'Ganhar contra 3 robôs.' },
  { id: 'dificil', icon: '🧠', title: 'Cabeça fria', text: 'Ganhar do robô difícil.' },
  { id: 'mestre', icon: '👑', title: 'Mestre do Pif', text: 'Ganhar do robô mestre.' },
  { id: 'serie', icon: '🏆', title: 'Campeão', text: 'Vencer uma série (melhor de 3 ou de 5).' },
  { id: 'desafio', icon: '📅', title: 'Desafio cumprido', text: 'Bater na meta do desafio do dia.' },
  { id: 'solitario', icon: '🌙', title: 'Solitário', text: 'Bater sozinho com 15 compras ou menos.' },
  { id: 'veterano', icon: '🎖️', title: 'Veterano', text: 'Ganhar 10 partidas.' },
  { id: 'lenda', icon: '💎', title: 'Lenda', text: 'Ganhar 50 partidas.' },
]

const KEY = 'pif-treino-conquistas'

export function unlockedAchievements(): Record<string, string> {
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? '{}') as Record<string, string>
  } catch {
    return {}
  }
}

/** Confere o fim da partida e devolve as conquistas novas (já salvas). */
export function checkAchievements(context: { game: TGame; won: number; streak: number; hints: boolean; seriesWon: boolean }): Achievement[] {
  const { game, won, streak, hints, seriesWon } = context
  const unlocked = unlockedAchievements()
  const earned: string[] = []
  const add = (id: string, condition: boolean) => { if (condition && !unlocked[id]) earned.push(id) }
  const iWon = game.winner === 0
  const games = game.winGames ?? []
  add('primeira', iWon)
  add('lixo', iWon && game.winVia === 'descarte')
  add('relampago', iWon && game.draws <= 8)
  add('chamas', streak >= 3)
  add('imparavel', streak >= 5)
  add('trincas', iWon && games.length === 3 && games.every(isTrinca))
  add('escadinha', iWon && games.length === 3 && games.every(isSequencia))
  add('sem-rodinhas', iWon && !hints)
  add('mesa-cheia', iWon && game.config.mode === 'bots' && game.config.bots === 3)
  add('dificil', iWon && game.config.mode === 'bots' && game.config.difficulty === 'dificil')
  add('mestre', iWon && game.config.mode === 'bots' && game.config.difficulty === 'mestre')
  add('serie', seriesWon)
  add('desafio', iWon && Boolean(game.config.daily) && game.draws <= (game.config.daily?.goal ?? 0))
  add('solitario', iWon && game.config.mode === 'solo' && !game.config.daily && game.draws <= 15)
  add('veterano', won >= 10)
  add('lenda', won >= 50)
  if (!earned.length) return []
  const now = new Date().toISOString()
  const next = { ...unlocked, ...Object.fromEntries(earned.map((id) => [id, now])) }
  try {
    localStorage.setItem(KEY, JSON.stringify(next))
  } catch {
    // sem armazenamento
  }
  return ACHIEVEMENTS.filter((item) => earned.includes(item.id))
}
