// Mesa com cartas virtuais: cada amigo joga no próprio celular e vê só as próprias cartas.
import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import { Layers, Shuffle, Trophy, X } from 'lucide-react'
import type { Action } from './lib/engine'
import { canWinWith, cardLabel, cardsInGames, findWinningDiscard, sortByGames, sortHand, waitingCards, type Card } from './lib/pif'
import type { Room } from './lib/roomApi'
import { CardBack, HandView, PlayingCard } from './training/cards'
import { askConfirm } from './ui'

const money = (value: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)

export function VirtualTable({ room, playerId, isHost, busy, onMutate }: {
  room: Room
  playerId: string
  isHost: boolean
  busy: boolean
  onMutate: (action: Action, silent?: boolean) => Promise<boolean>
}) {
  const state = room.virtual!
  const game = state.game
  const myIndex = state.ids.indexOf(playerId)
  const me = game && myIndex >= 0 ? game.players[myIndex] : null
  const [order, setOrder] = useState<string[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [pileHover, setPileHover] = useState(false)
  const [now, setNow] = useState(() => Date.now())
  const pileRef = useRef<HTMLDivElement>(null)

  // A ordem da mão é só deste celular: cartas novas entram no fim.
  useEffect(() => { setOrder([]); setSelected(null) }, [game?.id])
  const hand: Card[] = useMemo(() => {
    if (!me) return []
    const byId = new Map(me.hand.map((card) => [card.id, card]))
    const kept = order.filter((id) => byId.has(id)).map((id) => byId.get(id)!)
    const fresh = me.hand.filter((card) => !order.includes(card.id))
    return [...kept, ...fresh]
  }, [me, order])

  const inClaim = game?.phase === 'claim' && game.claim
  // Durante o tempo de bater, o próximo da vez já pode comprar (aí acaba a chance dos outros).
  const nextUp = Boolean(inClaim && game?.claim && game.claim.order[0] === myIndex)
  const myTurn = Boolean(game && ((game.turn === myIndex && (game.phase === 'draw' || game.phase === 'discard')) || nextUp))
  const drawPhase = Boolean(game && (game.phase === 'draw' || nextUp))
  const deadline = state.claimDeadline ?? 0
  useEffect(() => {
    if (!inClaim) return
    const timer = window.setInterval(() => setNow(Date.now()), 250)
    return () => window.clearInterval(timer)
  }, [inClaim])
  // Quando o tempo de bater pelo descarte acaba, qualquer celular resolve (o primeiro que chegar vale).
  const resolving = useRef('')
  useEffect(() => {
    if (!inClaim || now < deadline) return
    const key = `${game!.id}-${game!.history.length}`
    if (resolving.current === key) return
    resolving.current = key
    const delay = isHost ? 0 : 400 + Math.random() * 600
    window.setTimeout(() => { void onMutate({ type: 'v-resolve' }, true) }, delay)
  }, [inClaim, now, deadline, game, isHost, onMutate])

  const opener = room.players.find((player) => player.id === room.nextOpenerId)
  const canDeal = isHost || opener?.id === playerId
  const top = game?.discard[game.discard.length - 1]
  const inGames = useMemo(() => (me ? cardsInGames(me.hand) : new Set<string>()), [me])
  const waiting = useMemo(() => (me && me.hand.length === 9 && game?.phase !== 'over' ? waitingCards(me.hand) : []), [me, game?.phase])
  const canWin = Boolean(me && myTurn && game?.phase === 'discard' && findWinningDiscard(me.hand))
  const left = inClaim ? Math.max(0, Math.ceil((deadline - now) / 1000)) : 0

  async function discard(id: string) {
    if (await onMutate({ type: 'v-discard', cardId: id })) setSelected(null)
  }

  function onPile() {
    if (!game) return
    if (inClaim && game.claim && !(nextUp && me && !canWinWith(me.hand, game.claim.card))) {
      void onMutate({ type: 'v-claim' })
      return
    }
    if (!myTurn) return
    if (drawPhase) void onMutate({ type: 'v-draw', source: 'pile' })
    else if (selected) void discard(selected)
  }

  async function cancelHand() {
    if (await askConfirm('Cancelar a mão?', 'Ninguém ganha nem perde nesta mão. As cartas são recolhidas.', 'Cancelar a mão', true)) void onMutate({ type: 'v-cancel' })
  }

  if (!game) {
    return <section className="panel virtual-panel">
      <span className="section-kicker">CARTAS VIRTUAIS · {money(state.stake)} POR RODADA</span>
      <h2>Pronto para distribuir</h2>
      <p className="hand-instructions">Cada um vê só as próprias cartas no celular. Quem bate recebe {money(state.stake)} de cada jogador da mão.</p>
      {canDeal ? <button type="button" className="button button-primary" disabled={busy} onClick={() => void onMutate({ type: 'v-deal' })}><Shuffle size={16} /> Distribuir cartas</button>
        : <span className="waiting-host">Aguardando {opener?.name ?? 'o anfitrião'} distribuir.</span>}
    </section>
  }

  const others = game.players.map((player, index) => ({ player, index })).filter(({ index }) => index !== myIndex)
  const winnerName = game.winner !== undefined ? game.players[game.winner].name : null

  return <section className="panel virtual-panel virtual-table">
    <div className="virtual-head">
      <span className="section-kicker">MÃO {room.roundNumber} · CARTAS VIRTUAIS · {money(state.stake)} DE CADA</span>
      {isHost && game.phase !== 'over' && <button type="button" className="text-action" onClick={() => void cancelHand()}><X size={14} /> Cancelar mão</button>}
    </div>

    <div className="virtual-others">
      {others.map(({ player, index }) => {
        const roomPlayer = room.players.find((item) => item.id === state.ids[index])
        const known = player.hand.filter((card) => player.known.includes(card.id))
        const turn = game.turn === index && (game.phase === 'draw' || game.phase === 'discard')
        return <div key={state.ids[index]} className={`virtual-other ${turn ? 'is-turn' : ''} ${game.winner === index ? 'is-winner' : ''}`}>
          <strong>{roomPlayer?.avatar ? `${roomPlayer.avatar} ` : ''}{player.name}</strong>
          <span className="training-backs">{player.hand.map((card) => <i key={card.id} />)}</span>
          <small>{turn ? 'jogando...' : `${player.hand.length} cartas`}</small>
          {known.length > 0 && game.phase !== 'over' && <span className="training-known">do lixo: {known.map(cardLabel).join(' ')}</span>}
        </div>
      })}
    </div>

    <div className="training-center virtual-center">
      <button type="button" className={`training-pile ${myTurn && drawPhase ? 'can-take' : ''}`} disabled={!myTurn || !drawPhase || busy} onClick={() => void onMutate({ type: 'v-draw', source: 'deck' })} aria-label={`Comprar do monte (${game.deck.length} cartas)`}>
        <CardBack />
        <small>Monte · {game.deck.length}</small>
      </button>
      <div ref={pileRef} className={`training-pile pile-drop ${myTurn && drawPhase && top ? 'can-take' : ''} ${myTurn && game.phase === 'discard' && selected ? 'can-drop' : ''} ${pileHover ? 'is-hover' : ''}`}>
        {top ? <PlayingCard card={top} onClick={onPile} /> : <span className="pcard pcard-empty" />}
        <small>Lixo</small>
      </div>
    </div>

    <p className="training-log virtual-log" role="status">{game.log}</p>

    {inClaim && game.claim && (game.claim.discarder !== myIndex && myIndex >= 0
      ? <button type="button" className="claim-button" onClick={() => void onMutate({ type: 'v-claim' })}><Trophy size={18} /> BATER com o {cardLabel(game.claim.card)}! <small>{left}s</small></button>
      : <p className="waiting-host virtual-wait">Quem precisar do {cardLabel(game.claim.card)} pode bater ({left}s).</p>)}

    {waiting.length > 0 && <p className="pifado-banner"><b>Pifado!</b> Espera: {waiting.map((need) => <span key={`${need.rank}${need.suit}`}>{cardLabel({ id: '', ...need })}</span>)}</p>}

    {game.phase === 'over' && <div className="virtual-result">
      <strong>{winnerName ? `${winnerName === me?.name ? 'Você' : winnerName} bateu!` : 'Acabaram as cartas: ninguém bateu.'}</strong>
      {game.winVia === 'descarte' && game.winCard && <small>Com o {cardLabel(game.winCard)} que saiu no lixo.</small>}
      {winnerName && <small>Recebe {money(state.stake * (state.ids.length - 1))} ({money(state.stake)} de cada um).</small>}
      {game.winGames && <div className="training-games is-reveal">{game.winGames.map((triple, index) => <div className="training-game" key={index} style={{ '--g': index } as CSSProperties}>{triple.map((card) => <PlayingCard key={card.id} card={card} small />)}</div>)}</div>}
      {canDeal ? <button type="button" className="button button-primary" disabled={busy} onClick={() => void onMutate({ type: 'v-deal' })}><Shuffle size={16} /> Distribuir próxima mão</button>
        : <span className="waiting-host">Aguardando {opener?.name ?? 'o anfitrião'} distribuir a próxima.</span>}
    </div>}

    {me && game.phase !== 'over' && <div className="virtual-hand">
      <HandView
        hand={hand}
        selected={selected}
        drawnId={game.turn === myIndex ? game.drawnId : undefined}
        hints
        inGames={inGames}
        suggested={null}
        pileRef={pileRef}
        canDropOnPile={myTurn && game.phase === 'discard'}
        onSelect={(id) => setSelected(selected === id ? null : id)}
        onReorder={(next) => setOrder(next.map((card) => card.id))}
        onDropOnPile={(id) => void discard(id)}
        onPileHover={setPileHover}
      />
      <div className="training-actions">
        <button type="button" className="button button-secondary" onClick={() => setOrder(sortByGames(hand).map((card) => card.id))}><Layers size={15} /> Por jogos</button>
        <button type="button" className="button button-secondary" onClick={() => setOrder(sortHand(hand, 'naipe').map((card) => card.id))}>Naipe</button>
        <button type="button" className="button button-secondary" onClick={() => setOrder(sortHand(hand, 'valor').map((card) => card.id))}>Número</button>
      </div>
      <div className="training-actions">
        <button type="button" className="button button-primary" disabled={!myTurn || game.phase !== 'discard' || !selected || busy} onClick={() => selected && void discard(selected)}>Descartar {selected ? cardLabel(hand.find((card) => card.id === selected) ?? hand[0]) : ''}</button>
        <button type="button" className={`button button-finish ${canWin ? 'can-win' : ''}`} disabled={!myTurn || game.phase !== 'discard' || busy} onClick={() => void onMutate({ type: 'v-win' })}><Trophy size={15} /> Bater</button>
      </div>
      <p className="form-hint virtual-legend">{myTurn ? drawPhase ? nextUp ? 'Sua vez: compre. Até você comprar, quem precisar da carta do lixo ainda pode bater.' : 'Sua vez: toque no monte ou no lixo.' : 'Descarte: arraste até o lixo, toque duas vezes na carta ou use o botão.' : 'Arraste as cartas para organizar. Só você vê a sua mão.'}</p>
    </div>}
    {myIndex < 0 && game.phase !== 'over' && <p className="waiting-host">Você não está nesta mão. Vai entrar na próxima.</p>}
  </section>
}
