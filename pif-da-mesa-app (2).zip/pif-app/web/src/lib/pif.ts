// Regras do Pif para o modo treino.
// 2 baralhos sem coringa (104 cartas), 9 cartas por jogador.
// Jogo = 3 cartas: trinca (mesmo valor, naipes diferentes) ou sequência (mesmo naipe,
// valores seguidos; Ás vale antes do 2 e depois do K, mas K-A-2 não vale).
// Bate quem tiver as 9 cartas formando 3 jogos.

export type Suit = 'S' | 'H' | 'D' | 'C'
export type Card = { id: string; rank: number; suit: Suit }

export const SUITS: Suit[] = ['S', 'H', 'D', 'C']
export const SUIT_SYMBOL: Record<Suit, string> = { S: '♠', H: '♥', D: '♦', C: '♣' }
export const SUIT_NAME: Record<Suit, string> = { S: 'espadas', H: 'copas', D: 'ouros', C: 'paus' }
export const isRed = (card: Card) => card.suit === 'H' || card.suit === 'D'
export const rankLabel = (rank: number) => (rank === 1 ? 'A' : rank === 11 ? 'J' : rank === 12 ? 'Q' : rank === 13 ? 'K' : String(rank))
export const cardLabel = (card: Card) => `${rankLabel(card.rank)}${SUIT_SYMBOL[card.suit]}`

export function newDeck(): Card[] {
  const cards: Card[] = []
  for (const deck of [0, 1]) for (const suit of SUITS) for (let rank = 1; rank <= 13; rank += 1) cards.push({ id: `${deck}${suit}${rank}`, rank, suit })
  return cards
}

/** Embaralha (Fisher-Yates com números aleatórios do sistema). */
export function shuffle<T>(items: T[], random: () => number = secureRandom): T[] {
  const copy = [...items]
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1))
    ;[copy[i], copy[j]] = [copy[j], copy[i]]
  }
  return copy
}

function secureRandom() {
  const buffer = new Uint32Array(1)
  crypto.getRandomValues(buffer)
  return buffer[0] / 2 ** 32
}

// ------------------------------------------------------------------ jogos

export function isTrinca(cards: Card[]) {
  return cards.length === 3 && cards.every((card) => card.rank === cards[0].rank) && new Set(cards.map((card) => card.suit)).size === 3
}

export function isSequencia(cards: Card[]) {
  if (cards.length !== 3 || !cards.every((card) => card.suit === cards[0].suit)) return false
  const ranks = cards.map((card) => card.rank).sort((a, b) => a - b)
  if (ranks[1] === ranks[0] + 1 && ranks[2] === ranks[1] + 1) return true
  // Q-K-A (Ás depois do K)
  return ranks[0] === 1 && ranks[1] === 12 && ranks[2] === 13
}

export const isGame = (cards: Card[]) => isTrinca(cards) || isSequencia(cards)

/** Divide 9 cartas em 3 jogos, se der. Devolve os jogos ou null. */
export function findWin(hand: Card[]): Card[][] | null {
  if (hand.length !== 9) return null
  const search = (rest: Card[], found: Card[][]): Card[][] | null => {
    if (!rest.length) return found
    const [first, ...others] = rest
    for (let i = 0; i < others.length; i += 1) {
      for (let j = i + 1; j < others.length; j += 1) {
        const triple = [first, others[i], others[j]]
        if (isGame(triple)) {
          const result = search(others.filter((_, index) => index !== i && index !== j), [...found, triple])
          if (result) return result
        }
      }
    }
    return null
  }
  return search(hand, [])
}

/** Com 10 cartas na mão: qual carta descartar para bater (ou null se não dá). */
export function findWinningDiscard(hand: Card[]): { discard: Card; games: Card[][] } | null {
  for (const card of hand) {
    const games = findWin(hand.filter((item) => item.id !== card.id))
    if (games) return { discard: card, games }
  }
  return null
}

// ------------------------------------------------------------------ avaliação (dicas e robôs)

/** Duas cartas que viram jogo com mais uma. */
function isPartial(a: Card, b: Card) {
  if (a.rank === b.rank) return a.suit !== b.suit
  if (a.suit !== b.suit) return false
  const low = Math.min(a.rank, b.rank)
  const high = Math.max(a.rank, b.rank)
  if (high - low <= 2) return true
  // Ás com Q ou K (Q-K-A)
  return low === 1 && high >= 12
}

/** Maior número de jogos completos e separados na mão (com os jogos encontrados). */
function maxGames(hand: Card[]): { count: number; used: Set<string>; games: Card[][] } {
  let best = { count: 0, used: new Set<string>(), games: [] as Card[][] }
  const search = (rest: Card[], games: Card[][]) => {
    if (games.length > best.count) best = { count: games.length, used: new Set(games.flat().map((card) => card.id)), games }
    if (best.count === 3) return
    for (let a = 0; a < rest.length; a += 1) {
      for (let b = a + 1; b < rest.length; b += 1) {
        for (let c = b + 1; c < rest.length; c += 1) {
          const triple = [rest[a], rest[b], rest[c]]
          if (!isGame(triple)) continue
          search(rest.filter((_, index) => index > a && index !== b && index !== c), [...games, triple])
        }
      }
    }
  }
  search(hand, [])
  return best
}

/** Nota da mão: jogos completos valem muito, pares que quase viram jogo valem um pouco. */
export function handScore(hand: Card[]) {
  const { count, used } = maxGames(hand)
  const loose = hand.filter((card) => !used.has(card.id))
  let partials = 0
  const paired = new Set<string>()
  for (let i = 0; i < loose.length; i += 1) {
    for (let j = i + 1; j < loose.length; j += 1) {
      if (isPartial(loose[i], loose[j])) {
        partials += 1
        paired.add(loose[i].id)
        paired.add(loose[j].id)
      }
    }
  }
  return count * 100 + Math.min(partials, 6) * 12 + paired.size * 3
}

export type Difficulty = 'facil' | 'normal' | 'dificil' | 'mestre'
export type Personality = 'equilibrado' | 'arrojado' | 'cauteloso'

/** O que um robô difícil lembra da mesa: cartas que o próximo jogador pegou do lixo e o que já foi descartado. */
export type Memory = { nextPicked: Card[]; discarded: Card[]; seen?: (rank: number, suit: Suit) => number; otherPicked?: Card[]; master?: boolean }

/** Cartas que completam um par (para contar quantas ainda podem sair). */
function needsFor(a: Card, b: Card): { rank: number; suit: Suit }[] {
  if (a.rank === b.rank) return SUITS.filter((suit) => suit !== a.suit && suit !== b.suit).map((suit) => ({ rank: a.rank, suit }))
  const suit = a.suit
  const ranks = [a.rank, b.rank].sort((x, y) => x - y)
  const needs: number[] = []
  if (ranks[0] === 1 && ranks[1] >= 12) needs.push(ranks[1] === 13 ? 12 : 13) // A-K pede Q, A-Q pede K
  else if (ranks[1] - ranks[0] === 2) needs.push(ranks[0] + 1)
  else if (ranks[1] - ranks[0] === 1) {
    if (ranks[0] > 1) needs.push(ranks[0] - 1)
    if (ranks[1] < 13) needs.push(ranks[1] + 1)
    else needs.push(1) // Q-K pede A
  }
  return needs.map((rank) => ({ rank, suit }))
}

/** Nota "esperta": como a normal, mas cada par vale pelas cartas que ainda podem sair. */
function liveScore(hand: Card[], seen: (rank: number, suit: Suit) => number) {
  const { count, used } = maxGames(hand)
  const loose = hand.filter((card) => !used.has(card.id))
  let total = count * 100
  const counted = new Set<string>()
  for (let i = 0; i < loose.length; i += 1) {
    for (let j = i + 1; j < loose.length; j += 1) {
      if (!isPartial(loose[i], loose[j])) continue
      const outs = needsFor(loose[i], loose[j]).reduce((sum, need) => sum + Math.max(0, 2 - seen(need.rank, need.suit) - hand.filter((card) => card.rank === need.rank && card.suit === need.suit).length), 0)
      total += outs === 0 ? 1 : 6 + Math.min(outs, 4) * 4
      counted.add(loose[i].id)
      counted.add(loose[j].id)
    }
  }
  return total + counted.size * 2
}

/** Perigo de soltar uma carta: ela combina com o que o próximo jogador já pegou do lixo. */
function danger(card: Card, memory?: Memory) {
  if (!memory) return 0
  const near = (picked: Card) => (picked.rank === card.rank && picked.suit !== card.suit) || (picked.suit === card.suit && Math.abs(picked.rank - card.rank) <= 2)
  const next = memory.nextPicked.some(near) ? 1 : 0
  // O mestre também cuida dos outros jogadores, não só do próximo.
  const others = memory.master && memory.otherPicked?.some(near) ? 0.6 : 0
  return next + others
}

/** Mestre: nota média da mão depois da próxima compra, contando só as cartas que ainda podem sair. */
function expectedAfterDraw(rest: Card[], seen: (rank: number, suit: Suit) => number) {
  let total = 0
  let weight = 0
  for (const suit of SUITS) {
    for (let rank = 1; rank <= 13; rank += 1) {
      const live = 2 - seen(rank, suit) - rest.filter((card) => card.rank === rank && card.suit === suit).length
      if (live <= 0) continue
      total += live * handScore([...rest, { id: `sim-${suit}${rank}`, rank, suit }])
      weight += live
    }
  }
  return weight ? total / weight : 0
}

/** Melhor carta para descartar (a que deixa a mão com a maior nota). */
export function bestDiscard(hand: Card[], forbiddenId?: string, memory?: Memory, personality: Personality = 'equilibrado'): Card {
  let best = hand.find((card) => card.id !== forbiddenId) ?? hand[0]
  let bestScore = -Infinity
  for (const card of hand) {
    if (card.id === forbiddenId) continue
    const rest = hand.filter((item) => item.id !== card.id)
    let score = memory?.seen ? liveScore(rest, memory.seen) : handScore(rest)
    if (memory?.master && memory.seen) score = score * 0.4 + expectedAfterDraw(rest, memory.seen) * 0.6
    // Robô esperto: se já fica pifado, prefere a espera com mais cartas vivas.
    if (memory?.seen && rest.length === 9 && score >= 200) {
      const live = waitingCards(rest).reduce((sum, need) => sum + Math.max(0, 2 - memory.seen!(need.rank, need.suit) - rest.filter((item) => item.rank === need.rank && item.suit === need.suit).length), 0)
      if (live > 0) score = 300 + live * 15
    }
    if (memory) {
      score -= danger(card, memory) * (memory.master ? 22 : 14)
      // Carta igual a uma que alguém já jogou fora costuma ser segura de soltar.
      if (memory.discarded.some((item) => item.rank === card.rank && item.suit === card.suit)) score += 4
    }
    // O cauteloso prefere soltar cartas altas e soltas; o arrojado não liga.
    if (personality === 'cauteloso') score += card.rank >= 10 ? 2 : 0
    if (score > bestScore || (score === bestScore && card.rank > best.rank)) {
      best = card
      bestScore = score
    }
  }
  return best
}

/** Com 9 cartas na mão: dá para bater pegando esta carta? */
export function canWinWith(hand: Card[], card: Card): { discard: Card; games: Card[][] } | null {
  if (hand.length !== 9) return null
  const win = findWinningDiscard([...hand, card])
  return win && win.discard.id !== card.id ? win : null
}

/** Com 9 cartas: quais cartas fazem bater (a pessoa está "pifada"). */
export function waitingCards(hand: Card[]): { rank: number; suit: Suit }[] {
  if (hand.length !== 9) return []
  const result: { rank: number; suit: Suit }[] = []
  for (const suit of SUITS) {
    for (let rank = 1; rank <= 13; rank += 1) {
      if (canWinWith(hand, { id: `probe-${suit}${rank}`, rank, suit })) result.push({ rank, suit })
    }
  }
  return result
}

/** Vale a pena pegar a carta do lixo? */
export function wantsDiscard(hand: Card[], top: Card, personality: Personality = 'equilibrado', memory?: Memory): boolean {
  const withTop = [...hand, top]
  const win = findWinningDiscard(withTop)
  if (win && win.discard.id !== top.id) return true
  const before = handScore(hand)
  const after = handScore(withTop.filter((card) => card.id !== bestDiscard(withTop, top.id, memory, personality).id))
  const threshold = personality === 'arrojado' ? 0 : personality === 'cauteloso' ? 22 : 10
  return after > before + threshold
}

/** Decisão do robô para a compra. */
export function botDraw(hand: Card[], top: Card | undefined, difficulty: Difficulty, random: () => number = Math.random, personality: Personality = 'equilibrado', memory?: Memory): 'deck' | 'discard' {
  if (!top) return 'deck'
  if (difficulty === 'facil' && random() < 0.5) return 'deck'
  const smart = difficulty === 'dificil' || difficulty === 'mestre'
  return wantsDiscard(hand, top, personality, smart ? memory : undefined) ? 'discard' : 'deck'
}

/** Decisão do robô depois de comprar (10 cartas): bater ou descartar. */
export function botAfterDraw(hand: Card[], forbiddenId: string | undefined, difficulty: Difficulty, random: () => number = Math.random, personality: Personality = 'equilibrado', memory?: Memory): { type: 'win'; discard: Card; games: Card[][] } | { type: 'discard'; card: Card } {
  const win = findWinningDiscard(hand)
  if (win && (difficulty !== 'facil' || random() < 0.85)) return { type: 'win', ...win }
  if (difficulty === 'facil' && random() < 0.35) {
    const options = hand.filter((card) => card.id !== forbiddenId)
    return { type: 'discard', card: options[Math.floor(random() * options.length)] }
  }
  const smart = difficulty === 'dificil' || difficulty === 'mestre'
  return { type: 'discard', card: bestDiscard(hand, forbiddenId, smart ? (difficulty === 'mestre' && memory ? { ...memory, master: true } : memory) : undefined, personality) }
}

/** Robô decide se bate com a carta que outro descartou. */
export function botClaims(hand: Card[], card: Card, difficulty: Difficulty, random: () => number = Math.random) {
  const win = canWinWith(hand, card)
  if (!win) return null
  if (difficulty === 'facil' && random() > 0.7) return null
  return win
}

/** Ordena a mão por naipe e valor (ou por valor). */
export function sortHand(hand: Card[], mode: 'naipe' | 'valor'): Card[] {
  const suitOrder: Record<Suit, number> = { S: 0, H: 1, C: 2, D: 3 }
  return [...hand].sort((a, b) => (mode === 'naipe' ? suitOrder[a.suit] - suitOrder[b.suit] || a.rank - b.rank : a.rank - b.rank || suitOrder[a.suit] - suitOrder[b.suit]))
}

/** Ordena por jogos: primeiro os jogos completos, depois os pares, depois as cartas soltas. */
export function sortByGames(hand: Card[]): Card[] {
  const { games, used } = maxGames(hand)
  const ordered: Card[] = games.flatMap((game) => sortHand(game, isTrinca(game) ? 'naipe' : 'valor'))
  let loose = sortHand(hand.filter((card) => !used.has(card.id)), 'naipe')
  const pairs: Card[] = []
  for (let i = 0; i < loose.length; i += 1) {
    const partner = loose.findIndex((other, j) => j > i && isPartial(loose[i], other))
    if (partner > 0) {
      pairs.push(loose[i], loose[partner])
      loose = loose.filter((_, j) => j !== i && j !== partner)
      i -= 1
    }
  }
  return [...ordered, ...pairs, ...loose]
}

/** Ids das cartas que já formam jogos completos (para a dica). */
export function cardsInGames(hand: Card[]): Set<string> {
  return maxGames(hand).used
}

/** Gerador de números com semente (para o desafio diário ser igual para todo mundo). */
export function seededRandom(seed: number): () => number {
  let state = seed >>> 0
  return () => {
    state = (state + 0x6d2b79f5) >>> 0
    let t = state
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
