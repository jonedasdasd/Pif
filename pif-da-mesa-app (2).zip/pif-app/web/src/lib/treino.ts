// Motor do modo treino, sem tela: quem joga, compras, descartes, batidas e robôs.
// Tudo aqui é função pura (recebe o jogo e devolve o jogo novo), para dar para testar e salvar.
import {
  botAfterDraw, botClaims, botDraw, canWinWith, cardLabel, findWinningDiscard, newDeck, seededRandom, shuffle,
  type Card, type Difficulty, type Memory, type Personality,
} from './pif'

export type Mode = 'solo' | 'bots'
export type Speed = 'lenta' | 'normal' | 'rapida'
export type Config = {
  mode: Mode
  bots: number
  difficulty: Difficulty
  /** Modo aula: as cartas dos robôs ficam viradas para cima. */
  openHands: boolean
  /** Série: 1 = partida única, 3 = melhor de 3, 5 = melhor de 5. */
  series: 1 | 3 | 5
  /** Desafio do dia: mesma mão para todo mundo naquele dia. */
  daily?: { date: string; goal: number }
  /** Tutorial guiado: baralho montado para ensinar. */
  tutorial?: boolean
}
export type TPlayer = { name: string; hand: Card[]; bot: boolean; personality: Personality; known: string[] }
/** Depois de um descarte, quem pode bater com a carta, em ordem de prioridade. */
export type Claim = { card: Card; discarder: number; order: number[]; pos: number; userWindow: boolean }
export type TGame = {
  id: string
  config: Config
  seed: number
  players: TPlayer[]
  deck: Card[]
  discard: Card[]
  turn: number
  phase: 'draw' | 'discard' | 'claim' | 'over'
  forbiddenId?: string
  drawnId?: string
  draws: number
  winner?: number
  winGames?: Card[][]
  winVia?: 'propria' | 'descarte'
  winCard?: Card
  claim?: Claim
  log: string
  reshuffles: number
  /** Tudo o que já foi descartado na partida (é público). */
  history: Card[]
}
export type TEvent =
  | { kind: 'draw-deck'; player: number; card: Card }
  | { kind: 'draw-pile'; player: number; card: Card }
  | { kind: 'discard'; player: number; card: Card }
  | { kind: 'win'; player: number; via: 'propria' | 'descarte'; card?: Card }
  | { kind: 'reshuffle' }
  | { kind: 'empty' }
export type Step = { game: TGame; events: TEvent[] }
export type Result = Step | { error: string }

const BOT_NAMES = ['Robô Zé', 'Robô Lia', 'Robô Tião']
const PERSONALITIES: Personality[] = ['equilibrado', 'arrojado', 'cauteloso']

export const personalityLabel: Record<Personality, string> = { equilibrado: 'equilibrado', arrojado: 'arrojado', cauteloso: 'cauteloso' }

export function dateSeed(date: string) {
  let hash = 2166136261
  for (const char of date) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619) >>> 0
  return hash
}

export function todayKey(now = new Date()) {
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
}

/** Distribui uma partida nova. Em série, mantém os mesmos robôs (nomes e jeitos). */
export function newGame(config: Config, previous?: TPlayer[], seedOverride?: number, presetDeck?: Card[]): TGame {
  const seed = seedOverride ?? (config.daily ? dateSeed(config.daily.date) : Math.floor(Math.random() * 2 ** 32))
  const random = seededRandom(seed)
  const deck = presetDeck ? [...presetDeck] : shuffle(newDeck(), random)
  const players: TPlayer[] = [{ name: 'Você', hand: deck.splice(0, 9), bot: false, personality: 'equilibrado', known: [] }]
  if (config.mode === 'bots') {
    for (let i = 0; i < config.bots; i += 1) {
      const kept = previous?.[i + 1]
      players.push({
        name: kept?.name ?? BOT_NAMES[i],
        hand: deck.splice(0, 9),
        bot: true,
        personality: kept?.personality ?? PERSONALITIES[Math.floor(Math.random() * PERSONALITIES.length)],
        known: [],
      })
    }
  }
  const first = deck.shift()!
  return {
    id: `${Date.now()}-${Math.floor(Math.random() * 1e9)}`,
    config, seed, players, deck, discard: [first], turn: 0, phase: 'draw', draws: 0,
    log: 'Sua vez: compre do monte ou pegue a carta do lixo.', reshuffles: 0, history: [first],
  }
}

function withPlayer(game: TGame, index: number, patch: Partial<TPlayer>): TPlayer[] {
  return game.players.map((player, i) => (i === index ? { ...player, ...patch } : player))
}

/** Tira do monte; se acabou, embaralha o lixo (menos a carta de cima). */
function takeFromDeck(game: TGame): { game: TGame; card: Card; reshuffled: boolean } | null {
  let { deck, discard, reshuffles } = game
  let reshuffled = false
  if (!deck.length) {
    if (discard.length <= 1) return null
    const top = discard[discard.length - 1]
    deck = shuffle(discard.slice(0, -1), seededRandom(game.seed + (reshuffles + 1) * 7919))
    discard = [top]
    reshuffles += 1
    reshuffled = true
  }
  const [card, ...rest] = deck
  return { game: { ...game, deck: rest, discard, reshuffles }, card, reshuffled }
}

function endEmpty(game: TGame): Step {
  return { game: { ...game, phase: 'over', winner: undefined, log: 'Acabaram as cartas. Ninguém bateu.' }, events: [{ kind: 'empty' }] }
}

export function drawDeck(game: TGame, player: number): Result {
  if (game.phase !== 'draw' || game.turn !== player) return { error: 'Não é a vez de comprar.' }
  const taken = takeFromDeck(game)
  if (!taken) return endEmpty(game)
  const who = game.players[player]
  const next: TGame = {
    ...taken.game,
    players: withPlayer(taken.game, player, { hand: [...who.hand, taken.card] }),
    phase: 'discard',
    forbiddenId: undefined,
    drawnId: taken.card.id,
    draws: player === 0 ? game.draws + 1 : game.draws,
    log: who.bot ? `${who.name} comprou do monte.` : `Você comprou ${cardLabel(taken.card)}.`,
  }
  const events: TEvent[] = []
  if (taken.reshuffled) events.push({ kind: 'reshuffle' })
  events.push({ kind: 'draw-deck', player, card: taken.card })
  return { game: next, events }
}

export function drawPile(game: TGame, player: number): Result {
  if (game.phase !== 'draw' || game.turn !== player) return { error: 'Não é a vez de comprar.' }
  const top = game.discard[game.discard.length - 1]
  if (!top) return { error: 'O lixo está vazio.' }
  const who = game.players[player]
  return {
    game: {
      ...game,
      discard: game.discard.slice(0, -1),
      players: withPlayer(game, player, { hand: [...who.hand, top], known: [...who.known, top.id] }),
      phase: 'discard',
      forbiddenId: top.id,
      drawnId: top.id,
      draws: player === 0 ? game.draws + 1 : game.draws,
      log: who.bot ? `${who.name} pegou ${cardLabel(top)} do lixo.` : `Você pegou ${cardLabel(top)} do lixo. Ela não pode voltar para o lixo agora.`,
    },
    events: [{ kind: 'draw-pile', player, card: top }],
  }
}

/** Ordem de quem pode bater com a carta descartada: começa pelo próximo da vez. */
function claimOrder(game: TGame, discarder: number) {
  const order: number[] = []
  for (let step = 1; step < game.players.length; step += 1) order.push((discarder + step) % game.players.length)
  return order
}

export function discardCard(game: TGame, player: number, cardId: string): Result {
  if (game.phase !== 'discard' || game.turn !== player) return { error: 'Primeiro compre uma carta.' }
  const who = game.players[player]
  const card = who.hand.find((item) => item.id === cardId)
  if (!card) return { error: 'Escolha uma carta da sua mão.' }
  if (card.id === game.forbiddenId) return { error: 'A carta que veio do lixo não pode voltar para o lixo na mesma jogada.' }
  const base: TGame = {
    ...game,
    players: withPlayer(game, player, { hand: who.hand.filter((item) => item.id !== card.id), known: who.known.filter((id) => id !== card.id) }),
    discard: [...game.discard, card],
    history: [...game.history, card],
    forbiddenId: undefined,
    drawnId: undefined,
    log: who.bot ? `${who.name} descartou ${cardLabel(card)}.` : `Você descartou ${cardLabel(card)}.`,
  }
  const events: TEvent[] = [{ kind: 'discard', player, card }]
  if (game.config.mode === 'solo') return { game: { ...base, turn: 0, phase: 'draw', log: `${base.log} Compre de novo.` }, events }
  return { game: { ...base, phase: 'claim', claim: { card, discarder: player, order: claimOrder(game, player), pos: 0, userWindow: false } }, events }
}

function win(game: TGame, player: number, hand10: Card[], result: { discard: Card; games: Card[][] }, via: 'propria' | 'descarte', card?: Card): Step {
  const who = game.players[player]
  const rest = hand10.filter((item) => item.id !== result.discard.id)
  return {
    game: {
      ...game,
      players: withPlayer(game, player, { hand: rest }),
      discard: [...game.discard, result.discard],
      history: [...game.history, result.discard],
      phase: 'over',
      winner: player,
      winGames: result.games,
      winVia: via,
      winCard: card,
      claim: undefined,
      log: via === 'descarte' && card ? `${who.bot ? who.name : 'Você'} bateu com o ${cardLabel(card)} do lixo!` : `${who.bot ? `${who.name} bateu` : 'Você bateu'}!`,
    },
    events: [{ kind: 'win', player, via, card }],
  }
}

/** Bater com as próprias 10 cartas (depois de comprar). */
export function declareWin(game: TGame, player: number): Result {
  if (game.phase !== 'discard' || game.turn !== player) return { error: 'Você só pode bater depois de comprar.' }
  const hand = game.players[player].hand
  const result = findWinningDiscard(hand)
  if (!result) return { error: 'Ainda não dá para bater: 9 cartas precisam formar 3 jogos (trinca de naipes diferentes ou sequência do mesmo naipe).' }
  return win(game, player, hand, result, 'propria')
}

function afterClaims(game: TGame): Step {
  const claim = game.claim!
  const turn = (claim.discarder + 1) % game.players.length
  const next = game.players[turn]
  return { game: { ...game, phase: 'draw', claim: undefined, turn, log: next.bot ? `${game.log}` : `${game.log} Sua vez.` }, events: [] }
}

function tryBotClaim(game: TGame, index: number): Step | null {
  const claim = game.claim!
  const bot = game.players[index]
  const result = botClaims(bot.hand, claim.card, game.config.difficulty)
  if (!result) return null
  // A carta sai do lixo e vai para a mão de quem bateu.
  const withoutTop: TGame = { ...game, discard: game.discard.slice(0, -1) }
  return win(withoutTop, index, [...bot.hand, claim.card], result, 'descarte', claim.card)
}

/**
 * Avança a fase de batida pelo descarte. Os robôs na frente de você (na ordem) têm prioridade;
 * quando chega a sua vez na ordem, abre a "janela" para você bater e o motor espera.
 */
export function advanceClaim(game: TGame): Step {
  if (game.phase !== 'claim' || !game.claim) return { game, events: [] }
  let current = game
  let { pos, userWindow } = current.claim!
  const order = current.claim!.order
  while (pos < order.length) {
    const index = order[pos]
    if (index === 0) {
      if (!userWindow) return { game: { ...current, claim: { ...current.claim!, pos, userWindow: true } }, events: [] }
      pos += 1
      userWindow = false
      continue
    }
    const claimed = tryBotClaim(current, index)
    if (claimed) return claimed
    pos += 1
  }
  current = { ...current, claim: { ...current.claim!, pos, userWindow: false } }
  return afterClaims(current)
}

/** Você tenta bater com a carta que outro descartou. */
export function userClaim(game: TGame): Result {
  if (game.phase !== 'claim' || !game.claim) return { error: 'Não tem carta para pegar agora.' }
  const claim = game.claim
  if (claim.discarder === 0) return { error: 'Você não pode bater com a carta que acabou de jogar fora.' }
  const userPos = claim.order.indexOf(0)
  if (userPos < claim.pos) return { error: 'Já passou a sua vez de bater com essa carta.' }
  // Robôs antes de você na ordem têm prioridade.
  for (let pos = claim.pos; pos < userPos; pos += 1) {
    const claimed = tryBotClaim(game, claim.order[pos])
    if (claimed) return claimed
  }
  const result = canWinWith(game.players[0].hand, claim.card)
  if (!result) return { error: `Com o ${cardLabel(claim.card)} ainda não dá para bater.` }
  return win({ ...game, discard: game.discard.slice(0, -1) }, 0, [...game.players[0].hand, claim.card], result, 'descarte', claim.card)
}

function memoryFor(game: TGame, player: number): Memory {
  const next = game.players[(player + 1) % game.players.length]
  // O que este robô consegue ver: o lixo e as cartas que os outros pegaram do lixo.
  const visible = [...game.discard, ...game.players.flatMap((other, index) => (index === player ? [] : other.hand.filter((card) => other.known.includes(card.id))))]
  const nextIndex = (player + 1) % game.players.length
  return {
    nextPicked: next.hand.filter((card) => next.known.includes(card.id)),
    otherPicked: game.players.flatMap((other, index) => (index === player || index === nextIndex ? [] : other.hand.filter((card) => other.known.includes(card.id)))),
    discarded: game.history,
    seen: (rank, suit) => visible.filter((card) => card.rank === rank && card.suit === suit).length,
  }
}

/** Uma ação do robô da vez: comprar (do monte ou do lixo) ou descartar/bater. */
export function botStep(game: TGame): Step {
  const index = game.turn
  const bot = game.players[index]
  if (!bot.bot || game.phase === 'over') return { game, events: [] }
  const memory = memoryFor(game, index)
  if (game.phase === 'draw') {
    const top = game.discard[game.discard.length - 1]
    const choice = botDraw(bot.hand, top, game.config.difficulty, Math.random, bot.personality, memory)
    const result = choice === 'discard' ? drawPile(game, index) : drawDeck(game, index)
    return 'error' in result ? (drawDeck(game, index) as Step) : result
  }
  if (game.phase === 'discard') {
    const action = botAfterDraw(bot.hand, game.forbiddenId, game.config.difficulty, Math.random, bot.personality, memory)
    if (action.type === 'win') return win(game, index, bot.hand, { discard: action.discard, games: action.games }, 'propria')
    const result = discardCard(game, index, action.card.id)
    return 'error' in result ? { game, events: [] } : result
  }
  return { game, events: [] }
}

/** Meta do desafio do dia: quantas compras um jogador "esperto" levaria com a mesma mão. */
export function dailyGoal(date: string): number {
  const config: Config = { mode: 'solo', bots: 0, difficulty: 'normal', openHands: false, series: 1, daily: { date, goal: 0 } }
  let game = newGame(config)
  for (let guard = 0; guard < 400 && game.phase !== 'over'; guard += 1) {
    const me = game.players[0]
    const top = game.discard[game.discard.length - 1]
    const draw = botDraw(me.hand, top, 'normal') === 'discard' ? drawPile(game, 0) : drawDeck(game, 0)
    if ('error' in draw) break
    game = draw.game
    if (game.phase === 'over') break
    const action = botAfterDraw(game.players[0].hand, game.forbiddenId, 'normal')
    if (action.type === 'win') return game.draws
    const next = discardCard(game, 0, action.card.id)
    if ('error' in next) break
    game = next.game
  }
  return Math.max(1, game.draws)
}

/** Quantas cópias de uma carta você já viu (sua mão, lixo, e o que os robôs pegaram do lixo). */
export function seenCopies(game: TGame, rank: number, suit: Card['suit']) {
  const same = (card: Card) => card.rank === rank && card.suit === suit
  const mine = game.players[0].hand.filter(same).length
  const inPile = game.discard.filter(same).length
  const withBots = game.players.slice(1).reduce((total, player) => total + player.hand.filter((card) => same(card) && player.known.includes(card.id)).length, 0)
  return { mine, inPile, withBots, left: Math.max(0, 2 - mine - inPile - withBots) }
}

/** Baralho do tutorial: você recebe uma trinca pronta, compra o 6♦ (fecha 4-5-6) e depois o A♠ (fecha Q-K-A). */
export function tutorialDeck(): Card[] {
  const pick = (rank: number, suit: Card['suit'], copy = 0) => ({ id: `${copy}${suit}${rank}`, rank, suit })
  const hand = [pick(7, 'H'), pick(7, 'S'), pick(7, 'C'), pick(4, 'D'), pick(5, 'D'), pick(12, 'S'), pick(13, 'S'), pick(2, 'C'), pick(9, 'H')]
  const first = pick(8, 'C')
  const draws = [pick(6, 'D'), pick(1, 'S')]
  const used = new Set([...hand, first, ...draws].map((card) => card.id))
  const rest = shuffle(newDeck().filter((card) => !used.has(card.id)), seededRandom(20261104))
  return [...hand, first, ...draws, ...rest]
}

/** Cartas virtuais entre amigos: tenta bater pelo descarte com o jogador `index`. */
export function claimFor(game: TGame, index: number): Step | null {
  const claim = game.claim
  if (game.phase !== 'claim' || !claim || index === claim.discarder) return null
  const hand = game.players[index].hand
  const result = canWinWith(hand, claim.card)
  if (!result) return null
  return win({ ...game, discard: game.discard.slice(0, -1) }, index, [...hand, claim.card], result, 'descarte', claim.card)
}

/** Cartas virtuais: ninguém bateu com o descarte, segue para o próximo. */
export function passClaims(game: TGame): Step {
  if (game.phase !== 'claim' || !game.claim) return { game, events: [] }
  return afterClaims(game)
}

/** Cartas virtuais: monta a mão de cada amigo (todos humanos), começando por quem abre. */
export function newHumanGame(names: string[]): TGame {
  const config: Config = { mode: 'bots', bots: names.length - 1, difficulty: 'normal', openHands: false, series: 1 }
  const base = newGame(config)
  return { ...base, players: base.players.map((player, index) => ({ ...player, name: names[index], bot: false })), log: `Vez de ${names[0]}: compre do monte ou do lixo.` }
}
