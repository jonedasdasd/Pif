import { canWinWith as cardsCanWin, cardLabel as cardName } from './pif'
import { claimFor, declareWin as vDeclareWin, discardCard as vDiscard, drawDeck as vDrawDeck, drawPile as vDrawPile, newHumanGame, passClaims, type TGame } from './treino'
// Regras da mesa, portadas de server/index.js. Rodam no navegador de quem age
// e gravam o resultado no banco compartilhado da página.
import type { Room } from './roomApi'

export type Action =
  | { type: 'join'; name: string; pin?: string; avatar?: string }
  | { type: 'set-avatar'; playerId: string; avatar: string }
  | { type: 'expire' }
  | { type: 'v-deal' }
  | { type: 'v-draw'; source: 'deck' | 'pile' }
  | { type: 'v-discard'; cardId: string }
  | { type: 'v-win' }
  | { type: 'v-claim' }
  | { type: 'v-resolve' }
  | { type: 'v-cancel' }
  | { type: 'leave'; playerId: string }
  | { type: 'claim'; playerId: string; pin?: string }
  | { type: 'start' }
  | { type: 'round-start' }
  | { type: 'add-player'; name: string }
  | { type: 'undo-round' }
  | { type: 'rename-player'; playerId: string; name: string }
  | { type: 'solo-round'; openerId: string; value: number; playerIds: string[]; doubledIds: string[]; winnerId: string }
  | { type: 'cards-check'; playerId: string; count?: number | null }
  | { type: 'announce'; playerId: string; value: number }
  | { type: 'response'; playerId: string; choice: 'play' | 'fold' }
  | { type: 'double'; playerId: string }
  | { type: 'cancel-vote'; playerId: string }
  | { type: 'round-result'; winnerId: string }
  | { type: 'correct'; roundId: string; winnerId: string; reason: string }
  | { type: 'entry'; playerId: string; amount: number; description: string }
  | { type: 'finish' }

const MAX_ACTIVITY = 400
const codeAlphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'

// crypto.randomUUID só existe em HTTPS; no Wi-Fi local (http://192.168...) usamos getRandomValues.
export function uuid() {
  const bytes = crypto.getRandomValues(new Uint8Array(16))
  bytes[6] = (bytes[6] & 0x0f) | 0x40
  bytes[8] = (bytes[8] & 0x3f) | 0x80
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}

export function makeCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(8))
  return Array.from(bytes, (byte) => codeAlphabet[byte % codeAlphabet.length]).join('')
}

function fail(message: string): never {
  throw new Error(message)
}

function record(room: Room, type: string, message: string, actor = 'Sistema', details: Record<string, unknown> = {}) {
  room.activity.push({ id: uuid(), type, message, actor, details, createdAt: new Date().toISOString() })
  if (room.activity.length > MAX_ACTIVITY) room.activity.splice(0, room.activity.length - MAX_ACTIVITY)
}

const cents = (value: number) => Math.round(Number(value) * 100)
const hostName = (room: Room) => room.players.find((player) => player.id === room.ownerPlayerId)?.name ?? 'Organização'
const nameOf = (room: Room, id: string | null | undefined, fallback: string) => room.players.find((player) => player.id === id)?.name ?? fallback

export function calculateBalances(room: Room) {
  const balances = new Map(room.players.map((player) => [player.id, 0]))
  for (const round of room.rounds) {
    if (!round.winnerId) continue
    const participantIds = round.playerIds ?? [...balances.keys()]
    if (!participantIds.includes(round.winnerId)) continue
    const stake = cents(round.value)
    for (const playerId of participantIds) {
      if (!balances.has(playerId)) continue
      balances.set(playerId, (balances.get(playerId) ?? 0) + (playerId === round.winnerId ? stake * (participantIds.length - 1) : -stake))
    }
  }
  for (const entry of room.entries) balances.set(entry.playerId, (balances.get(entry.playerId) ?? 0) + cents(entry.amount))
  return balances
}

export function calculateReport(room: Room) {
  const balances = calculateBalances(room)
  const debtors = room.players.map((player) => ({ player, balance: balances.get(player.id) ?? 0 })).filter((item) => item.balance < 0)
  const creditors = room.players.map((player) => ({ player, balance: balances.get(player.id) ?? 0 })).filter((item) => item.balance > 0)
  const transfers = []
  let debtorIndex = 0
  let creditorIndex = 0
  while (debtorIndex < debtors.length && creditorIndex < creditors.length) {
    const debtor = debtors[debtorIndex]
    const creditor = creditors[creditorIndex]
    const amount = Math.min(-debtor.balance, creditor.balance)
    transfers.push({ fromPlayerId: debtor.player.id, from: debtor.player.name, toPlayerId: creditor.player.id, to: creditor.player.name, amount: amount / 100 })
    debtor.balance += amount
    creditor.balance -= amount
    if (debtor.balance === 0) debtorIndex += 1
    if (creditor.balance === 0) creditorIndex += 1
  }
  return {
    transfers,
    balances: room.players.map((player) => ({ playerId: player.id, playerName: player.name, amount: (balances.get(player.id) ?? 0) / 100 })),
  }
}

function finishRoom(room: Room, actor: string, message: string) {
  room.status = 'finished'
  room.finishedAt = new Date().toISOString()
  room.activeRound = null
  room.finalReport = calculateReport(room)
  record(room, 'game_finished', message, actor, { transfers: room.finalReport.transfers })
}

function advanceOpener(room: Room, currentOpenerId: string | null) {
  const activePlayers = room.players.filter((player) => player.inGame)
  if (!activePlayers.length) {
    room.nextOpenerId = null
    return
  }
  const currentIndex = room.players.findIndex((player) => player.id === currentOpenerId)
  for (let offset = 1; offset <= room.players.length; offset += 1) {
    const player = room.players[(Math.max(currentIndex, -1) + offset) % room.players.length]
    if (player?.inGame) {
      room.nextOpenerId = player.id
      return
    }
  }
  room.nextOpenerId = activePlayers[0].id
}

function cancelActiveHand(room: Room, type: string, message: string, actor = 'Sistema', details: Record<string, unknown> = {}) {
  const hand = room.activeRound!
  const openerId = hand.firstPlayerId
  const roundNumber = hand.number
  room.activeRound = null
  advanceOpener(room, openerId)
  record(room, type, message, actor, { roundNumber, nextOpenerId: room.nextOpenerId, ...details })
}

function completeResponsePhase(room: Room) {
  const hand = room.activeRound!
  const players = hand.playerIds
  const folded = players.filter((id) => hand.responses[id] === 'fold')
  if (players.some((id) => hand.responses[id] === 'pending')) return
  const playing = players.filter((id) => hand.responses[id] === 'play')
  hand.foldedPlayerIds = folded
  if (playing.length < 2) {
    cancelActiveHand(room, 'round_no_game', `Rodada ${hand.number} não teve jogo: todos desistiram, exceto ${nameOf(room, hand.firstPlayerId, 'Quem abriu')}. Nenhum saldo foi alterado.`, 'Sistema', { foldedPlayerIds: folded })
    return
  }
  hand.phase = 'playing'
  hand.playingPlayerIds = playing
  hand.playerIds = playing
  record(room, 'round_play_started', `Rodada ${hand.number} começou valendo R$ ${(hand.value ?? 0).toFixed(2)} com ${playing.length} jogadores.`, 'Sistema', { roundNumber: hand.number, playerIds: playing, foldedPlayerIds: folded, value: hand.value })
}

const money = (value: number) => `R$ ${value.toFixed(2).replace('.', ',')}`

/** Fim de uma mão de cartas virtuais: vira uma rodada normal (entra no saldo e no histórico). */
function finishVirtualHand(room: Room, game: TGame) {
  const state = room.virtual!
  const opener = state.ids[0]
  if (game.winner === undefined) {
    record(room, 'round_no_game', `Mão ${room.roundNumber} (cartas virtuais): acabaram as cartas e ninguém bateu.`, 'Sistema')
    advanceOpener(room, opener)
    return
  }
  const winnerId = state.ids[game.winner]
  const winner = room.players.find((player) => player.id === winnerId)!
  const now = new Date().toISOString()
  room.rounds.push({ id: uuid(), number: room.roundNumber, firstPlayerId: opener, winnerId, winnerName: winner.name, playerIds: [...state.ids], value: state.stake, createdAt: now, startedAt: now, announcedAt: now, foldedPlayerIds: [], doubledByPlayerIds: [] })
  advanceOpener(room, opener)
  const via = game.winVia === 'descarte' && game.winCard ? ` com o ${cardName(game.winCard)} do lixo` : ''
  record(room, 'round_recorded', `Mão ${room.roundNumber} (cartas virtuais): ${winner.name} bateu${via} e recebe ${money(state.stake * (state.ids.length - 1))}.`, winner.name, { winnerId })
}

/** Código do PIN (não guarda o número em texto na mesa). */
export function pinHash(pin: string, code: string) {
  let hash = 2166136261
  for (const char of `${code}:${pin.trim()}`) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619) >>> 0
  return hash.toString(36)
}

export const AVATARS = ['🙂', '😎', '🤠', '🦊', '🐯', '🐸', '🦁', '🐼', '👑', '🔥', '🍀', '🎩', '🦄', '🐙', '🌵', '⚡']

/** Tem mão em andamento (física ou com cartas virtuais)? */
export function handInProgress(room: Room) {
  return Boolean(room.activeRound || (room.virtual?.game && room.virtual.game.phase !== 'over'))
}

export type RoomOptions = { pin?: string; avatar?: string; turnSeconds?: number; virtualStake?: number }

export function newRoom(name: string, playerName: string, userId: string, code: string, soloNames?: string[], options: RoomOptions = {}): Room {
  name = name.trim()
  playerName = playerName.trim()
  if (!name || name.length > 80 || !playerName || playerName.length > 50) fail('Informe o nome da mesa e o seu nome.')
  const others = (soloNames ?? []).map((item) => item.trim()).filter(Boolean)
  if (soloNames && !others.length) fail('No modo solo, escreva o nome de pelo menos mais um jogador.')
  const allNames = [playerName, ...others].map((item) => item.toLocaleLowerCase('pt-BR'))
  if (new Set(allNames).size !== allNames.length) fail('Tem nomes repetidos. Use um apelido para diferenciar.')
  if (others.some((item) => item.length > 50)) fail('Cada nome pode ter até 50 caracteres.')
  const now = new Date().toISOString()
  const player = { id: uuid(), userId, name: playerName, inGame: true, joinedAt: now, leftAt: null, ...(options.avatar ? { avatar: options.avatar } : {}) }
  const room: Room = {
    id: uuid(), code, name, hostUserId: userId, ownerPlayerId: player.id, nextOpenerId: player.id, roundNumber: 0,
    status: 'waiting', createdAt: now, startedAt: null, finishedAt: null,
    players: [player], rounds: [], activeRound: null, entries: [], activity: [], finalReport: null,
  }
  if (options.pin && options.pin.trim()) {
    if (!/^\d{4}$/.test(options.pin.trim())) fail('O PIN precisa ter 4 números.')
    room.pinHash = pinHash(options.pin, code)
  }
  if (options.turnSeconds) room.turnSeconds = Math.max(10, Math.min(300, Math.round(options.turnSeconds)))
  if (options.virtualStake !== undefined) {
    if (soloNames) fail('Cartas virtuais não funcionam no modo solo: cada um joga no próprio celular.')
    const stake = Math.round(Number(options.virtualStake) * 100) / 100
    if (!Number.isFinite(stake) || stake <= 0 || stake > 10000000) fail('Informe o valor por rodada das cartas virtuais.')
    room.virtual = { stake, game: null, ids: [] }
  }
  record(room, 'room_created', `A mesa "${name}" foi criada.`, player.name)
  record(room, 'player_joined', `${player.name} entrou na mesa.`, player.name)
  if (soloNames) {
    room.solo = true
    for (const other of others) {
      room.players.push({ id: uuid(), userId, name: other, inGame: true, joinedAt: now, leftAt: null })
      record(room, 'player_joined', `${other} foi colocado na mesa por ${player.name}.`, player.name)
    }
    room.status = 'playing'
    room.startedAt = now
    record(room, 'game_started', `Mesa no modo solo: ${player.name} marca as rodadas de todos. ${player.name} abre a primeira mão.`, player.name)
  }
  return room
}

/** Saldo de cada participante, em reais. */
export function balancesInReais(room: Room) {
  return new Map([...calculateBalances(room)].map(([id, amount]) => [id, amount / 100]))
}

export type RoomSummary = {
  code: string
  name: string
  status: Room['status']
  solo: boolean
  createdAt: string
  startedAt: string | null
  finishedAt: string | null
  host: string
  activePlayers: number
  players: { id: string; name: string; amount: number; inGame: boolean; avatar?: string }[]
  rounds: { number: number; value: number; winner: string; opener: string; players: number }[]
  /** Quem paga quem no fim (para a caderneta de dívidas). */
  transfers?: { from: string; to: string; amount: number }[]
  virtual?: boolean
}

/** Resumo leve da mesa, usado na lista de mesas e no histórico geral. */
export function buildSummary(room: Room): RoomSummary {
  const balances = balancesInReais(room)
  const nameOf = (id?: string) => room.players.find((player) => player.id === id)?.name ?? ''
  return {
    code: room.code,
    name: room.name,
    status: room.status,
    solo: Boolean(room.solo),
    createdAt: room.createdAt,
    startedAt: room.startedAt,
    finishedAt: room.finishedAt,
    host: nameOf(room.ownerPlayerId),
    activePlayers: room.players.filter((player) => player.inGame).length,
    players: room.players.map((player) => ({ id: player.id, name: player.name, amount: balances.get(player.id) ?? 0, inGame: player.inGame, ...(player.avatar ? { avatar: player.avatar } : {}) })),
    transfers: room.finalReport?.transfers.map((transfer) => ({ from: transfer.from, to: transfer.to, amount: transfer.amount })),
    virtual: Boolean(room.virtual),
    rounds: room.rounds.map((round) => ({ number: round.number, value: round.value, winner: round.winnerName ?? '', opener: nameOf(round.firstPlayerId), players: round.playerIds?.length ?? 0 })),
  }
}

/** O participante desta conta nesta mesa (o mais recente, se houver mais de um). */
export function playerForUser(room: Room, userId: string) {
  // No modo solo todos os nomes ficam na conta do anfitrião; ele é sempre o próprio jogador.
  if (room.hostUserId === userId) {
    const owner = room.players.find((player) => player.id === room.ownerPlayerId)
    if (owner) return owner
  }
  return [...room.players].reverse().find((player) => player.userId === userId)
}

/** Aplica uma ação a uma cópia da mesa e devolve a cópia. Lança Error com a mensagem para o usuário. */
export function applyAction(source: Room, action: Action, userId: string): Room {
  const room: Room = structuredClone(source)
  const isHost = room.hostUserId === userId
  const requireHost = () => { if (!isHost) fail('Esta ação é exclusiva de quem organiza a mesa.') }
  const requirePlaying = () => { if (room.status !== 'playing') fail('A partida não está em andamento.') }
  // Cada conta só age pelo próprio participante.
  const ownPlayer = (playerId: string) => {
    const player = room.players.find((item) => item.id === playerId)
    if (!player || player.userId !== userId) fail('Você só pode agir pelo seu próprio nome na mesa.')
    return player
  }

  switch (action.type) {
    case 'join': {
      if (room.status === 'finished') fail('Essa partida já foi encerrada.')
      if (handInProgress(room)) fail('A rodada já começou. Você poderá entrar assim que ela terminar ou for cancelada.')
      if (room.pinHash && pinHash(action.pin ?? '', room.code) !== room.pinHash) fail('PIN errado. Peça o código de 4 números para quem criou a mesa.')
      const existing = room.players.find((player) => player.userId === userId && player.inGame)
      if (existing) fail(`Você já está nesta mesa como ${existing.name}.`)
      const name = action.name.trim()
      if (!name || name.length > 50) fail('Informe seu nome (até 50 caracteres).')
      if (room.players.some((player) => player.inGame && player.name.trim().toLocaleLowerCase('pt-BR') === name.toLocaleLowerCase('pt-BR'))) fail('Já tem alguém com esse nome na mesa. Use outro, como um apelido.')
      room.players.push({ id: uuid(), userId, name, inGame: true, joinedAt: new Date().toISOString(), leftAt: null, ...(action.avatar ? { avatar: action.avatar } : {}) })
      record(room, 'player_joined', `${name} entrou ${room.status === 'waiting' ? 'na mesa' : 'na partida entre rodadas'}.`, name)
      return room
    }
    case 'set-avatar': {
      const player = ownPlayer(action.playerId)
      if (action.avatar && !AVATARS.includes(action.avatar)) fail('Avatar inválido.')
      if (action.avatar) player.avatar = action.avatar
      else delete player.avatar
      return room
    }
    case 'expire': {
      // Tempo para decidir acabou: quem não respondeu sai da mão (sem pagar nada).
      const hand = room.activeRound
      if (!hand || hand.phase !== 'responding' || !room.turnSeconds || !hand.respondingSince) fail('Não há tempo correndo agora.')
      if (Date.now() - new Date(hand.respondingSince).getTime() < room.turnSeconds * 1000 - 500) fail('Ainda tem tempo.')
      const late = hand.playerIds.filter((id) => hand.responses[id] === 'pending')
      if (!late.length) fail('Todo mundo já respondeu.')
      for (const id of late) {
        hand.responses[id] = 'fold'
        if (!hand.foldedPlayerIds.includes(id)) hand.foldedPlayerIds.push(id)
      }
      record(room, 'player_timeout', `Acabou o tempo: ${late.map((id) => nameOf(room, id, '?')).join(', ')} ${late.length === 1 ? 'saiu' : 'saíram'} da mão sem pagar.`, 'Sistema', { roundNumber: hand.number, playerIds: late })
      completeResponsePhase(room)
      return room
    }
    case 'v-deal': {
      const state = room.virtual
      if (!state) fail('Esta mesa não usa cartas virtuais.')
      requirePlaying()
      if (state.game && state.game.phase !== 'over') fail('A mão atual ainda não terminou.')
      const active = room.players.filter((player) => player.inGame)
      if (active.length < 2) fail('São necessários pelo menos dois jogadores na mesa.')
      if (!isHost && room.players.find((player) => player.id === room.nextOpenerId)?.userId !== userId) fail('Quem distribui é o anfitrião ou quem abre a mão.')
      const start = Math.max(0, active.findIndex((player) => player.id === room.nextOpenerId))
      const ordered = [...active.slice(start), ...active.slice(0, start)]
      state.ids = ordered.map((player) => player.id)
      state.game = newHumanGame(ordered.map((player) => player.name))
      state.claimDeadline = undefined
      state.claimRequests = []
      room.roundNumber += 1
      record(room, 'round_started', `Mão ${room.roundNumber} (cartas virtuais): ${ordered[0].name} começa. Valendo ${money(state.stake)} de cada um.`, hostName(room), { roundNumber: room.roundNumber })
      return room
    }
    case 'v-draw':
    case 'v-discard':
    case 'v-win':
    case 'v-claim':
    case 'v-resolve':
    case 'v-cancel': {
      const state = room.virtual
      if (!state || !state.game) fail('Não tem mão de cartas virtuais agora.')
      const game: TGame = state.game
      if (action.type === 'v-cancel') {
        requireHost()
        state.game = null
        record(room, 'round_cancelled', `Mão ${room.roundNumber} de cartas virtuais cancelada pelo anfitrião. Ninguém ganhou nem perdeu.`, hostName(room))
        return room
      }
      if (game.phase === 'over') fail('Essa mão já terminou.')
      const me = room.players.find((player) => player.userId === userId && state.ids.includes(player.id))
      const index = me ? state.ids.indexOf(me.id) : -1
      const take = (result: { game: TGame } | { error: string }) => {
        if ('error' in result) fail(result.error)
        return result.game
      }
      let next: TGame
      if (action.type === 'v-resolve') {
        if (game.phase !== 'claim' || !game.claim) fail('Nada para resolver.')
        const order = game.claim.order
        const requests = state.claimRequests ?? []
        const firstAsked = requests.includes(order[0])
        if (!firstAsked && Date.now() < (state.claimDeadline ?? 0) - 300) fail('Ainda dá tempo de alguém bater.')
        const winner = order.find((candidate) => requests.includes(candidate))
        next = winner !== undefined ? (claimFor(game, winner)?.game ?? passClaims(game).game) : passClaims(game).game
      } else {
        if (index < 0) fail('Você não está nesta mão.')
        if (action.type === 'v-claim') {
          if (game.phase !== 'claim' || !game.claim) fail('Não tem carta para pegar agora.')
          if (game.claim.discarder === index) fail('Você não pode bater com a carta que acabou de jogar fora.')
          if (!cardsCanWin(game.players[index].hand, game.claim.card)) fail(`Com o ${cardName(game.claim.card)} ainda não dá para bater.`)
          const already = (state.claimRequests ?? []).includes(index)
          state.claimRequests = [...new Set([...(state.claimRequests ?? []), index])]
          // Quem é o primeiro na ordem não precisa esperar: ninguém tem prioridade sobre ele.
          if (game.claim.order[0] !== index) {
            if (already) return room
            record(room, 'virtual_claim', `${me!.name} pediu para bater com o ${cardName(game.claim.card)}.`, me!.name)
            return room
          }
          next = claimFor(game, index)!.game
        } else if (action.type === 'v-draw') {
          // Como na mesa de verdade: quem quer bater com o descarte tem que pedir antes do próximo comprar.
          let base = game
          if (game.phase === 'claim' && game.claim) {
            if (game.claim.order[0] !== index) fail('Espere: ainda dá para bater com a carta que saiu.')
            const requests = state.claimRequests ?? []
            const winner = game.claim.order.find((candidate) => requests.includes(candidate))
            if (winner !== undefined) {
              next = claimFor(game, winner)?.game ?? passClaims(game).game
              base = next
            } else base = passClaims(game).game
          }
          if (base.phase === 'draw') next = take(action.source === 'deck' ? vDrawDeck(base, index) : vDrawPile(base, index))
          else next = base
        } else if (action.type === 'v-discard') {
          next = take(vDiscard(game, index, action.cardId))
          if (next.phase === 'claim') {
            state.claimDeadline = Date.now() + 6000
            state.claimRequests = []
          }
        } else {
          next = take(vDeclareWin(game, index))
        }
      }
      // A mensagem do jogo usa "Você"; na mesa mostramos o nome de quem jogou,
      // sem revelar a carta comprada do monte e dizendo de quem é a vez.
      let log = next.log.replace(/^Você/, next.phase === 'over' && next.winner !== undefined ? next.players[next.winner].name : me?.name ?? 'Alguém')
      if (action.type === 'v-draw' && action.source === 'deck' && next.phase !== 'over') log = `${me?.name ?? 'Alguém'} comprou do monte.`
      log = log.replace(/ Sua vez\.$/, '')
      if (next.phase === 'draw') log = `${log} Vez de ${next.players[next.turn].name}.`
      next = { ...next, log }
      state.game = next
      if (next.phase === 'claim' && action.type !== 'v-discard' && action.type !== 'v-claim') state.claimRequests = []
      if (next.phase === 'over') finishVirtualHand(room, next)
      return room
    }
    case 'claim': {
      // Volta para o próprio lugar depois de trocar de aparelho ou navegador.
      const player = room.players.find((item) => item.id === action.playerId)
      if (!player) fail('Esse nome não está registrado na partida.')
      if (player.userId === userId) return room
      if (room.pinHash && room.status !== 'finished' && pinHash(action.pin ?? '', room.code) !== room.pinHash) fail('PIN errado. Peça o código de 4 números para quem criou a mesa.')
      player.userId = userId
      record(room, 'player_reconnected', `${player.name} voltou à mesa por outro aparelho.`, player.name, { playerId: player.id })
      return room
    }
    case 'leave': {
      if (room.status === 'finished') fail('Essa partida já foi encerrada.')
      if (handInProgress(room)) fail('Só é possível sair entre rodadas. Esta rodada precisa terminar ou ser cancelada primeiro.')
      const player = ownPlayer(action.playerId)
      if (!player.inGame) fail('Participante não encontrado nesta mesa.')
      const willAutoFinish = room.status === 'playing' && room.players.filter((item) => item.inGame).length - 1 <= 2
      const difference = [...calculateBalances(room).values()].reduce((total, amount) => total + amount, 0)
      if (willAutoFinish && difference !== 0) fail(`A saída deixaria dois jogadores e encerraria a partida, mas os acertos ainda diferem em R$ ${(Math.abs(difference) / 100).toFixed(2)}. Equilibre o livro-caixa antes de sair.`)
      player.inGame = false
      player.leftAt = new Date().toISOString()
      record(room, 'player_left', `${player.name} saiu da partida entre rodadas.`, player.name)
      if (room.nextOpenerId === player.id) advanceOpener(room, player.id)
      if (room.status === 'playing' && room.players.filter((item) => item.inGame).length <= 2) {
        finishRoom(room, player.name, 'A partida foi encerrada porque restaram dois jogadores ou menos. O resultado foi salvo.')
      }
      return room
    }
    case 'start': {
      requireHost()
      if (room.status !== 'waiting') fail('A lista fica fechada depois que a partida começa.')
      if (room.players.filter((player) => player.inGame).length < 2) fail('São necessários pelo menos dois jogadores para iniciar.')
      room.status = 'playing'
      room.startedAt = new Date().toISOString()
      room.nextOpenerId = room.players.find((player) => player.id === room.nextOpenerId && player.inGame)?.id ?? room.players.find((player) => player.inGame)?.id ?? null
      record(room, 'game_started', `A partida começou. ${nameOf(room, room.nextOpenerId, 'O primeiro jogador')} abre a primeira mão.`, hostName(room), { firstPlayerId: room.nextOpenerId })
      return room
    }
    case 'round-start': {
      requirePlaying()
      if (room.activeRound) fail('A rodada atual ainda não terminou.')
      const activeIds = room.players.filter((player) => player.inGame).map((player) => player.id)
      const firstPlayerId = activeIds.includes(room.nextOpenerId ?? '') ? room.nextOpenerId! : activeIds[0]
      const opener = room.players.find((player) => player.id === firstPlayerId)
      if (!isHost && opener?.userId !== userId) fail('Quem começa a rodada é o anfitrião ou quem abre a mão.')
      if (activeIds.length < 2) fail('São necessários pelo menos dois jogadores na mesa.')
      room.roundNumber += 1
      room.activeRound = {
        number: room.roundNumber, phase: 'announcing', value: null, firstPlayerId, playerIds: activeIds, startedAt: new Date().toISOString(),
        cardConfirmations: [...activeIds], responses: Object.fromEntries(activeIds.map((id) => [id, id === firstPlayerId ? 'play' : 'pending'])),
        playingPlayerIds: [firstPlayerId], foldedPlayerIds: [], cancelVotes: [], doubledByPlayerIds: [], redealCount: 0, lastDealError: null,
      }
      record(room, 'round_started', `Mão ${room.roundNumber} começou. ${nameOf(room, firstPlayerId, 'Quem abre')} anuncia o valor.`, opener?.userId === userId ? opener.name : hostName(room), { roundNumber: room.roundNumber, playerIds: activeIds, firstPlayerId })
      return room
    }
    case 'undo-round': {
      requireHost()
      if (room.status === 'waiting') fail('Ainda não tem rodada para desfazer.')
      if (room.activeRound) fail('Termine ou cancele a rodada atual antes de desfazer a anterior.')
      const last = room.rounds.at(-1)
      if (!last) fail('Ainda não tem rodada para desfazer.')
      room.rounds.pop()
      // A vez de abrir volta para quem abriu a rodada desfeita.
      if (last.firstPlayerId && room.players.some((player) => player.id === last.firstPlayerId && player.inGame)) room.nextOpenerId = last.firstPlayerId
      if (room.status === 'finished') room.finalReport = calculateReport(room)
      record(room, 'round_undone', `Rodada ${last.number} foi desfeita (${last.winnerName ?? '?'} tinha batido valendo R$ ${last.value.toFixed(2)}). Os saldos voltaram ao que eram antes dela.`, hostName(room), { roundId: last.id, roundNumber: last.number })
      return room
    }
    case 'rename-player': {
      requireHost()
      const player = room.players.find((item) => item.id === action.playerId)
      if (!player) fail('Jogador não encontrado.')
      const name = action.name.trim()
      if (!name || name.length > 50) fail('Informe o novo nome (até 50 caracteres).')
      if (room.players.some((item) => item.id !== player.id && item.inGame && item.name.trim().toLocaleLowerCase('pt-BR') === name.toLocaleLowerCase('pt-BR'))) fail('Já tem alguém com esse nome na mesa.')
      const previous = player.name
      if (previous === name) return room
      player.name = name
      for (const round of room.rounds) if (round.winnerId === player.id) round.winnerName = name
      for (const entry of room.entries) if (entry.playerId === player.id) entry.playerName = name
      if (room.finalReport) room.finalReport = calculateReport(room)
      record(room, 'player_renamed', `${previous} agora se chama ${name}.`, hostName(room), { playerId: player.id, previous, name })
      return room
    }
    case 'add-player': {
      requireHost()
      if (room.status === 'finished') fail('Essa partida já foi encerrada.')
      if (room.activeRound) fail('Adicione jogadores entre as rodadas.')
      const name = action.name.trim()
      if (!name || name.length > 50) fail('Informe o nome do jogador (até 50 caracteres).')
      if (room.players.some((player) => player.inGame && player.name.trim().toLocaleLowerCase('pt-BR') === name.toLocaleLowerCase('pt-BR'))) fail('Já tem alguém com esse nome na mesa.')
      room.players.push({ id: uuid(), userId, name, inGame: true, joinedAt: new Date().toISOString(), leftAt: null })
      record(room, 'player_joined', `${name} foi colocado na mesa por ${hostName(room)}.`, hostName(room))
      return room
    }
    case 'solo-round': {
      requireHost()
      requirePlaying()
      if (room.activeRound) fail('Termine a rodada atual primeiro.')
      const activeIds = room.players.filter((player) => player.inGame).map((player) => player.id)
      const playerIds = [...new Set(action.playerIds)].filter((id) => activeIds.includes(id))
      if (!activeIds.includes(action.openerId)) fail('Escolha quem abriu a mão.')
      if (!playerIds.includes(action.openerId)) playerIds.unshift(action.openerId)
      if (playerIds.length < 2) fail('Marque pelo menos dois jogadores nesta rodada.')
      const value = Number(action.value)
      if (!Number.isFinite(value) || value <= 0 || value > 10000000) fail('Informe o valor por jogador.')
      const doubled = [...new Set(action.doubledIds)].filter((id) => playerIds.includes(id) && id !== action.openerId)
      const finalValue = Math.round(value * 100 * 2 ** doubled.length) / 100
      if (finalValue > 10000000) fail('O valor final passou do limite da mesa.')
      const winner = room.players.find((player) => player.id === action.winnerId && playerIds.includes(player.id))
      if (!winner) fail('Escolha quem bateu entre os jogadores da rodada.')
      room.roundNumber += 1
      const now = new Date().toISOString()
      const folded = activeIds.filter((id) => !playerIds.includes(id))
      const round = {
        id: uuid(), number: room.roundNumber, firstPlayerId: action.openerId, winnerId: winner.id, winnerName: winner.name,
        playerIds, value: finalValue, createdAt: now, startedAt: now, announcedAt: now, foldedPlayerIds: folded, doubledByPlayerIds: doubled,
      }
      room.rounds.push(round)
      advanceOpener(room, action.openerId)
      const doubledText = doubled.length ? ` Dobraram: ${doubled.map((id) => nameOf(room, id, '?')).join(', ')}.` : ''
      record(room, 'round_recorded', `Rodada ${round.number}: ${winner.name} venceu valendo R$ ${finalValue.toFixed(2)} por jogador (${playerIds.length} jogadores).${doubledText}`, hostName(room), { roundId: round.id, winnerId: winner.id, winnerName: winner.name, valuePerLoser: finalValue, playerIds })
      return room
    }
    case 'cards-check': {
      requirePlaying()
      const hand = room.activeRound
      if (!hand || hand.phase !== 'dealing') fail('A conferência de cartas não está aberta.')
      const player = ownPlayer(action.playerId)
      if (!hand.playerIds.includes(player.id)) fail('Você não recebeu cartas nesta mão.')
      const hasCount = action.count !== undefined && action.count !== null
      const count = hasCount ? Number(action.count) : null
      if (hasCount && (!Number.isInteger(count) || count! < 0 || count! > 20)) fail('Informe a quantidade de cartas ou confirme a distribuição sem contar.')
      if (hasCount && count !== 9) {
        hand.cardConfirmations = []
        hand.redealCount += 1
        hand.lastDealError = { playerId: player.id, playerName: player.name, count: count!, createdAt: new Date().toISOString() }
        record(room, 'cards_redealt', `${player.name} informou ${count} cartas. O baralho foi recolhido para distribuir novamente.`, player.name, { roundNumber: hand.number, playerId: player.id, count })
        return room
      }
      if (hand.cardConfirmations.includes(player.id)) fail('Você já confirmou a distribuição desta mão.')
      hand.cardConfirmations.push(player.id)
      record(room, 'cards_confirmed', `${player.name} confirmou a distribuição da mão. (${hand.cardConfirmations.length}/${hand.playerIds.length})`, player.name, { roundNumber: hand.number, playerId: player.id, count: count ?? 9 })
      if (hand.cardConfirmations.length === hand.playerIds.length) {
        hand.phase = 'announcing'
        hand.lastDealError = null
        record(room, 'cards_checked', `Todos confirmaram a distribuição. ${nameOf(room, hand.firstPlayerId, 'Quem abre')} pode anunciar o valor.`, 'Sistema', { roundNumber: hand.number, firstPlayerId: hand.firstPlayerId })
      }
      return room
    }
    case 'announce': {
      requirePlaying()
      const hand = room.activeRound
      if (!hand || hand.phase !== 'announcing') fail('A mão ainda não está pronta para anunciar o valor.')
      ownPlayer(action.playerId)
      if (action.playerId !== hand.firstPlayerId) fail('Só quem abre a mão anuncia o primeiro valor.')
      const value = Number(action.value)
      if (!Number.isFinite(value) || value <= 0 || value > 10000000) fail('Informe um valor por jogador válido.')
      hand.value = Math.round(value * 100) / 100
      hand.announcedAt = new Date().toISOString()
      hand.respondingSince = hand.announcedAt
      hand.phase = 'responding'
      hand.responses = Object.fromEntries(hand.playerIds.map((id) => [id, id === hand.firstPlayerId ? 'play' : 'pending']))
      const opener = nameOf(room, hand.firstPlayerId, 'Quem abre')
      record(room, 'value_announced', `${opener} anunciou R$ ${hand.value.toFixed(2)} por jogador. Cada um pode entrar ou sair da mão.`, opener, { roundNumber: hand.number, value: hand.value, playerIds: hand.playerIds })
      return room
    }
    case 'response': {
      requirePlaying()
      const hand = room.activeRound
      if (!hand || hand.phase !== 'responding') fail('As confirmações de participação não estão abertas.')
      const player = ownPlayer(action.playerId)
      if (!hand.playerIds.includes(player.id) || !['play', 'fold'].includes(action.choice)) fail('Resposta de participação inválida.')
      if (player.id === hand.firstPlayerId && action.choice === 'fold') fail('Quem abriu a mão é obrigado a continuar.')
      if (hand.responses[player.id] === 'fold') fail('Você já saiu desta mão.')
      hand.responses[player.id] = action.choice
      if (action.choice === 'fold' && !hand.foldedPlayerIds.includes(player.id)) hand.foldedPlayerIds.push(player.id)
      if (action.choice === 'play' && !hand.playingPlayerIds.includes(player.id)) hand.playingPlayerIds.push(player.id)
      record(room, action.choice === 'fold' ? 'player_folded' : 'player_confirmed', `${player.name} ${action.choice === 'fold' ? 'saiu desta mão sem alteração de saldo' : 'confirmou que vai jogar por R$ ' + (hand.value ?? 0).toFixed(2)}.`, player.name, { roundNumber: hand.number, playerId: player.id, choice: action.choice, value: hand.value })
      completeResponsePhase(room)
      return room
    }
    case 'double': {
      requirePlaying()
      const hand = room.activeRound
      if (!hand || hand.phase !== 'responding') fail('A aposta só pode ser dobrada antes de começar a jogar.')
      const player = ownPlayer(action.playerId)
      if (!hand.playerIds.includes(player.id) || hand.responses[player.id] !== 'play') fail('Só quem confirmou que vai jogar pode dobrar a aposta.')
      if (player.id === hand.firstPlayerId) fail('Quem anunciou o valor não pode dobrar. Só os outros jogadores.')
      if (hand.doubledByPlayerIds.includes(player.id)) fail('Cada jogador pode dobrar a aposta uma vez nesta mão.')
      if ((hand.value ?? 0) * 2 > 10000000) fail('A aposta máxima por jogador nesta mesa é R$ 10.000.000,00.')
      hand.value = (hand.value ?? 0) * 2
      hand.doubledByPlayerIds.push(player.id)
      hand.respondingSince = new Date().toISOString()
      for (const id of hand.playerIds) {
        if (hand.responses[id] !== 'fold') hand.responses[id] = id === hand.firstPlayerId || id === player.id ? 'play' : 'pending'
      }
      hand.playingPlayerIds = hand.playerIds.filter((id) => hand.responses[id] === 'play')
      record(room, 'round_doubled', `${player.name} dobrou a aposta para R$ ${hand.value.toFixed(2)} por jogador. Os demais precisam confirmar ou sair.`, player.name, { roundNumber: hand.number, playerId: player.id, value: hand.value, doubledByPlayerIds: hand.doubledByPlayerIds })
      completeResponsePhase(room)
      return room
    }
    case 'cancel-vote': {
      requirePlaying()
      const hand = room.activeRound
      if (!hand || hand.phase !== 'playing') fail('A votação só pode cancelar uma mão depois que ela começar a ser jogada.')
      const player = ownPlayer(action.playerId)
      if (!hand.playerIds.includes(player.id)) fail('Só quem está jogando esta rodada pode votar para cancelá-la.')
      if (hand.cancelVotes.includes(player.id)) fail('Seu voto para cancelar já foi registrado.')
      hand.cancelVotes.push(player.id)
      const threshold = Math.floor(hand.playerIds.length / 2) + 1
      record(room, 'round_cancel_vote', `${player.name} votou para cancelar a rodada ${hand.number} (${hand.cancelVotes.length}/${threshold}).`, player.name, { roundNumber: hand.number, playerId: player.id, votes: hand.cancelVotes.length, threshold })
      if (hand.cancelVotes.length >= threshold) {
        const voteNames = room.players.filter((item) => hand.cancelVotes.includes(item.id)).map((item) => item.name)
        cancelActiveHand(room, 'round_cancelled', `Mão ${hand.number} cancelada por maioria (${voteNames.join(', ')}). Nenhum saldo foi alterado.`, 'Sistema', { votes: voteNames, threshold })
      }
      return room
    }
    case 'round-result': {
      requireHost()
      requirePlaying()
      const hand = room.activeRound
      if (!hand) fail('Comece uma rodada antes de registrar o vencedor.')
      if (hand.phase !== 'playing') fail('A mão só pode ser concluída depois que os jogadores confirmarem participação.')
      const winner = room.players.find((player) => player.id === action.winnerId && hand.playingPlayerIds.includes(player.id))
      if (!winner) fail('O vencedor precisa ser um dos participantes desta rodada.')
      const round = {
        id: uuid(), number: hand.number, firstPlayerId: hand.firstPlayerId, winnerId: winner.id, winnerName: winner.name,
        playerIds: hand.playingPlayerIds, value: hand.value ?? 0, createdAt: new Date().toISOString(), startedAt: hand.startedAt,
        announcedAt: hand.announcedAt, foldedPlayerIds: hand.foldedPlayerIds, doubledByPlayerIds: hand.doubledByPlayerIds,
      }
      room.rounds.push(round)
      room.activeRound = null
      advanceOpener(room, round.firstPlayerId)
      record(room, 'round_recorded', `Rodada ${round.number}: ${winner.name} venceu. Cada outro participante perde R$ ${round.value.toFixed(2)}.`, hostName(room), { roundId: round.id, winnerId: winner.id, winnerName: winner.name, valuePerLoser: round.value, playerIds: round.playerIds })
      return room
    }
    case 'correct': {
      requireHost()
      if (room.status === 'waiting') fail('A rodada só pode ser corrigida depois que a partida começar.')
      const round = room.rounds.find((item) => item.id === action.roundId)
      if (!round?.winnerId) fail('Essa rodada ainda não tem um vencedor registrado para corrigir.')
      const reason = action.reason.trim()
      const participantIds = round.playerIds ?? room.players.filter((player) => player.inGame).map((player) => player.id)
      const winner = room.players.find((player) => player.id === action.winnerId && participantIds.includes(player.id))
      if (!winner || !reason || reason.length > 240) fail('Selecione o vencedor correto e informe o motivo da correção.')
      if (round.winnerId === winner.id) fail('O vencedor selecionado já está registrado.')
      const previousWinnerId = round.winnerId
      const previousWinnerName = round.winnerName
      round.winnerId = winner.id
      round.winnerName = winner.name
      round.correctedAt = new Date().toISOString()
      record(room, 'round_corrected', `Rodada ${round.number} corrigida: vencedor alterado de ${previousWinnerName} para ${winner.name}. Motivo: ${reason}`, hostName(room), { roundId: round.id, previousWinnerId, previousWinnerName, winnerId: winner.id, winnerName: winner.name, reason })
      if (room.status === 'finished') room.finalReport = calculateReport(room)
      return room
    }
    case 'entry': {
      requireHost()
      requirePlaying()
      if (room.activeRound) fail('Lançamentos manuais podem ser feitos entre rodadas.')
      const player = room.players.find((item) => item.id === action.playerId && item.inGame)
      const amount = Number(action.amount)
      const description = (action.description || 'Acerto manual').trim().slice(0, 160)
      if (!player || !Number.isFinite(amount) || amount === 0 || Math.abs(amount) > 10000000) fail('Selecione um jogador e informe um valor válido.')
      const entry = { id: uuid(), playerId: player.id, playerName: player.name, description, amount: Math.round(amount * 100) / 100, createdAt: new Date().toISOString() }
      room.entries.push(entry)
      record(room, 'entry_recorded', `${player.name}: ${entry.amount > 0 ? 'crédito' : 'débito'} de R$ ${Math.abs(entry.amount).toFixed(2)} (${description}).`, hostName(room), { entryId: entry.id, playerId: player.id, amount: entry.amount, description })
      return room
    }
    case 'finish': {
      requireHost()
      if (room.status === 'finished') fail('Essa partida já foi encerrada.')
      if (room.activeRound) fail('Encerre ou cancele a rodada atual antes de fechar a partida.')
      const difference = [...calculateBalances(room).values()].reduce((total, amount) => total + amount, 0)
      if (difference !== 0) fail(`Os lançamentos ainda têm uma diferença de R$ ${(Math.abs(difference) / 100).toFixed(2)}. Registre os créditos/débitos correspondentes antes de fechar.`)
      finishRoom(room, hostName(room), 'A partida foi encerrada para todos. O resumo final foi salvo.')
      return room
    }
  }
}
