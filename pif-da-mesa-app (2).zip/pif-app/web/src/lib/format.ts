// Pequenos formatadores usados em várias telas.

export function formatMoney(value: number) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)
}

export function initialsOf(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('')
}

/** Cor fixa de cada jogador (a mesma em todas as listas e no layout Mesa). */
export function playerColor(id: string) {
  let hash = 0
  for (const char of id) hash = (hash * 31 + char.charCodeAt(0)) >>> 0
  return ['coral', 'blue', 'green', 'yellow', 'violet'][hash % 5]
}
