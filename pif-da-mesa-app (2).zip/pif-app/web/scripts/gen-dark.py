#!/usr/bin/env python3
"""Gera src/dark.css (tema escuro) a partir de App.css e index.css.

Para cada regra com cor fixa de texto, fundo ou borda, cria a mesma regra com
[data-theme="escuro"] na frente, invertendo a claridade da cor e mantendo o tom.
Cartas, feltro, QR code e telas de jogo ficam de fora (já são escuras ou precisam
continuar iguais). Rode de novo sempre que mudar as cores do App.css:
    python3 scripts/gen-dark.py
"""
import colorsys, re, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent / 'src'
SKIP = ('pcard', 'felt', 'seat-', 'training', 'fly-', 'splash', 'celebration', 'qr-box', 'virtual-', 'podium-block', 'podium-avatar', 'confetti', 'preview-mesa', 'claim-button',
        'pifado', 'counter-line', 'series-bar', 'icon-chip', 'pile-', 'daily-card', 'turn-flash', 'night-image', 'back-', 'legend-')
PROPS = ('color', 'background', 'background-color', 'border-color', 'border', 'border-top', 'border-bottom', 'border-left', 'border-right', 'outline')
HEX = re.compile(r'#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b')

def to_rgb(h):
    if len(h) == 3: h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))

def flip(match, prop):
    r, g, b = to_rgb(match.group(1))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    if prop == 'color' or prop.startswith('border') or prop == 'outline':
        nl = 1 - l
        nl = min(0.92, max(0.30 if prop == 'color' else 0.22, nl))
    else:  # fundos: claros viram superfícies escuras
        nl = 0.10 + (1 - l) * 0.9 if l > 0.5 else min(0.85, 1 - l)
        s *= 0.75
    r, g, b = colorsys.hls_to_rgb(h, nl, s)
    return '#%02x%02x%02x' % tuple(round(v * 255) for v in (r, g, b))

def prefix(selector):
    out = []
    for part in selector.split(','):
        part = part.strip()
        if not part: continue
        if part.startswith(':root'): return None
        if part.startswith('[data-'):
            out.append('[data-theme="escuro"]' + part)
        elif part in ('body', 'html'):
            out.append(f'[data-theme="escuro"] {part}' if part == 'body' else '[data-theme="escuro"]')
        else:
            out.append('[data-theme="escuro"] ' + part)
    return ', '.join(out)

rules = []
for name in ('index.css', 'App.css'):
    css = (root / name).read_text()
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
    # só regras simples de nível superior ou dentro de @media
    for media, body in re.findall(r'(@media[^{]+)\{((?:[^{}]*\{[^}]*\})*)\s*\}', css):
        for sel, decls in re.findall(r'([^{}]+)\{([^}]*)\}', body):
            rules.append((media.strip(), sel.strip(), decls))
    flat = re.sub(r'@media[^{]+\{(?:[^{}]*\{[^}]*\})*\s*\}', '', css)
    flat = re.sub(r'@keyframes[^{]+\{(?:[^{}]*\{[^}]*\})*\s*\}', '', flat)
    for sel, decls in re.findall(r'([^{}]+)\{([^}]*)\}', flat):
        rules.append(('', sel.strip(), decls))

out = ['/* Gerado por scripts/gen-dark.py — não edite à mão. */']
for media, sel, decls in rules:
    if any(word in sel for word in SKIP) or sel.startswith('@') or 'keyframes' in sel: continue
    new = []
    for decl in decls.split(';'):
        if ':' not in decl: continue
        prop, value = decl.split(':', 1)
        prop = prop.strip()
        if prop not in PROPS or not HEX.search(value) or 'gradient' in value or 'var(' in value: continue
        new.append(f'{prop}: {HEX.sub(lambda m: flip(m, prop), value.strip())}')
    if not new: continue
    pre = prefix(sel)
    if not pre: continue
    rule = f'{pre} {{ {"; ".join(new)}; }}'
    out.append(f'{media} {{ {rule} }}' if media else rule)

out.append('''
/* Tokens e fundos com gradiente (feitos à mão) */
[data-theme="escuro"] { --ink: #e6ece6; --line: #2c3a31; --paper: #101813; color-scheme: dark; color: var(--ink); background: var(--paper); }
[data-theme="escuro"] .felt-option { background: #18211b; color: var(--ink); }
[data-theme="escuro"] .felt-option.selected { border-color: #8fbf9a; }
[data-theme="escuro"] .avatar-picker button { background: #18211b; }
[data-theme="escuro"] .avatar-picker button.selected { background: #22382a; border-color: #8fbf9a; }
[data-theme="escuro"] .avatar.avatar-emoji { background: #22382a !important; }
[data-theme="escuro"] .decision-clock { background: #1d2a21; color: #b9d4bf; }
[data-theme="escuro"] .podium-avatar { background: #22382a; }
[data-theme="escuro"] body { background-color: var(--paper); background-image: none; }
[data-theme="escuro"] .gate-shell { background: linear-gradient(140deg, #0e1611, #141e18 52%, #0f1712); }
[data-theme="escuro"] .form-stack input, [data-theme="escuro"] .form-stack select, [data-theme="escuro"] .form-stack textarea, [data-theme="escuro"] .setting-field input { color: var(--ink); background: #18221c; border-color: #33443a; }
[data-theme="escuro"][data-layout="mesa"] .panel, [data-theme="escuro"][data-layout="mesa"] .summary-card:not(.balance-card), [data-theme="escuro"][data-layout="mesa"] .gate-panel, [data-theme="escuro"][data-layout="mesa"] .sidebar, [data-theme="escuro"][data-layout="mesa"] .modal, [data-theme="escuro"][data-layout="mesa"] .mobile-nav { background: #1c2620; }
[data-theme="escuro"] .seat-balance { background: #1c2620; color: #d6ded8; }
[data-theme="escuro"] .training-setup .daily-card { background: #2a2414; color: var(--ink); }
[data-theme="escuro"] .training-actions .button-secondary { background: rgb(28 38 32 / 92%); color: var(--ink); }
''')
(root / 'dark.css').write_text('\n'.join(out) + '\n')
print(f'dark.css: {len(out)} regras')
