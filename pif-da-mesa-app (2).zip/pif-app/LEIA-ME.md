# Pif da Mesa — app Android

O app transforma o celular do anfitrião no servidor da mesa:

- **Abriu o app:** a mesa liga sozinha e aparece o link e o QR code para os amigos.
- **Os amigos** abrem o link no navegador do celular, digitam o nome e jogam. Ninguém precisa de conta nem de instalar nada.
- **Você** joga pela própria tela do app.
- **Fechou o app** (botão voltar → "Desligar", botão "Desligar" na notificação, ou tirou o app dos recentes): tudo desliga.

As partidas e o histórico ficam salvos no celular e continuam lá na próxima vez que você abrir o app.

**Importante:** os amigos precisam estar na mesma rede que o seu celular. O jeito mais fácil é ligar o **roteador do celular** (hotspot) e todo mundo se conectar nele. Quem estiver usando os próprios dados móveis (4G/5G) não consegue entrar.

---

## 1. Gerar o APK (uma vez só, pelo GitHub)

1. Crie uma conta grátis em https://github.com e clique em **New repository**. Dê um nome (ex.: `pif-da-mesa`), deixe **Private** e clique em **Create repository**.
2. Na página do repositório, clique em **uploading an existing file**.
3. Descompacte o `pif-da-mesa-app.zip` no computador, abra a pasta `pif-app` e **arraste tudo o que está dentro dela** para a página (as pastas `android`, `web`, `.github` e os arquivos). Clique em **Commit changes**.
   - Se a pasta `.github` não aparecer (ela pode estar oculta), crie o arquivo à mão: **Add file → Create new file**, digite o nome `.github/workflows/gerar-apk.yml` e cole o conteúdo do arquivo `gerar-apk.yml` que está no zip.
4. Abra a aba **Actions**. Vai aparecer **Gerar APK** rodando (bolinha amarela). Espere uns 5 a 10 minutos até ficar verde ✓.
   - Se ficar vermelho ✗, clique nele, abra o passo que falhou e mande um print pro Claude.
5. Clique na execução verde e, lá embaixo em **Artifacts**, baixe **PifDaMesa-apk**. Vem um `.zip` com o arquivo `app-debug.apk` dentro.

## 2. Instalar no celular

1. Passe o `app-debug.apk` para o celular (ou baixe direto pelo navegador do celular, logado no GitHub) e toque nele.
2. O Android vai pedir para **permitir instalar apps desta fonte**: permita.
3. Se o Play Protect avisar que o app é desconhecido, toque em **Mais detalhes → Instalar assim mesmo**. Isso acontece com todo app que não veio da Play Store.
4. Na primeira vez, permita as **notificações**. É a notificação que mantém a mesa ligada com a tela apagada.
5. Samsung: em **Configurações → Aplicativos → Pif da Mesa → Bateria**, escolha **Sem restrições**. Assim o Android não desliga a mesa no meio da partida.

## Novidades da versão 1.6

- **Cartas virtuais:** ao criar a sala, escolha **Cartas virtuais** e o valor por rodada. Cada amigo joga no próprio celular e vê só as próprias cartas. Quem bate recebe o valor de cada um, e isso entra nos saldos e no histórico. Dá para bater com o descarte de qualquer um (tem 5 segundos, e se dois puderem ganha quem é o próximo da vez).
- **PIN da mesa** (em *Mais opções*): só entra quem souber os 4 números.
- **Tempo para decidir** (em *Mais opções*, cartas de verdade): quem não responder a tempo sai da mão sem pagar.
- **Mesa rápida:** o botão no topo da tela inicial cria a mesa igual à última, com um toque. O app lembra o nome, o avatar e as opções.
- **Avatares:** escolha um emoji ao criar ou entrar. Para trocar, toque no seu nome na mesa.
- **Confirmação** antes de registrar quem bateu, salvar rodada solo, lançar acerto e cancelar mão (dá para desligar em Configurações).
- **Aviso de vez:** a borda da tela brilha quando é a sua vez (pode desligar em Configurações).
- **Fim de noite:** pódio com os 3 primeiros, confete e pódio também na imagem para o grupo.
- **Caderneta:** em Histórico geral → **Caderneta**, as dívidas das noites anteriores que ainda não foram pagas, com o total em aberto de cada dupla. O anfitrião toca em **Pago** quando acertarem.
- **Planilha:** em Histórico geral, **Exportar planilha (Excel)** salva um arquivo .csv em Downloads, com saldos, rodadas e quem paga quem.
- **Treino:** tutorial guiado, robô **Mestre** (acima do difícil), conquistas (medalhas), **Ver replay** da partida no fim, toque duplo na carta para descartar, arrastar do monte ou do lixo até a mão para comprar, cartas redesenhadas e animação ao distribuir e ao bater.
- **Visual:** tema escuro (ou automático), letra maior, modo uma mão (botões grandes embaixo), feltros novos (madeira, couro preto e roxo), versos novos, tela de abertura e botão **?** de ajuda em cada tela.

## 3. Jogar

1. Ligue o **roteador do celular** (hotspot) e peça para os amigos se conectarem.
2. Abra o **Pif da Mesa**. O link e o QR code aparecem no topo.
3. Crie a sala. Os amigos leem o QR code com a câmera (ou abrem o link) e entram com o nome.
4. Quando todos estiverem, toque em **Iniciar partida**. A cada mão, você ou quem abre toca em **Começar rodada**: entram todos que estão na mesa, sem escolher e sem conferir cartas.
5. Quem abre anuncia o valor. Os outros dizem se jogam, saem ou dobram (quem anunciou não pode dobrar).
6. Se alguém trocar de celular ou fechar o navegador, é só abrir o link de novo e digitar o mesmo nome.

**Sair:** o botão **Sair** encerra a mesa para quem saiu (o saldo fica salvo e os outros continuam). Se for o anfitrião, encerra para todos. Antes de voltar ao início aparece o resultado completo, com todas as rodadas.

**Modo solo:** ao criar a sala, marque **Modo solo** e escreva o nome dos amigos, um por linha. Ninguém precisa entrar pelo link: você toca em **Registrar rodada** e marca quem abriu, o valor, quem jogou, quem dobrou e quem bateu. Dá para **Adicionar jogador** no meio da noite.

**Histórico geral:** na tela inicial, **Histórico geral** mostra quanto cada pessoa ganhou ou perdeu somando todas as partidas encerradas, e a lista de partidas com o resultado de cada uma. Toque num nome para ver só as partidas dele.

**Imagem para o grupo:** no resultado da mesa, **Gerar imagem para o grupo** cria uma imagem com o resultado da noite. **Salvar imagem** guarda na galeria, na pasta PifDaMesa.

**Corrigir:** o anfitrião pode **Desfazer última rodada** (apaga a rodada e volta os saldos) e **Renomear jogador**. Tudo fica anotado no histórico da mesa.

**Apagar mesas de teste:** em Histórico geral → Partidas, abra a partida e toque em **Apagar partida** (só no celular do anfitrião).

**Visual:** o botão de quadradinhos no topo da mesa troca entre **Clássico** e **Mesa**. No layout Mesa, os jogadores aparecem sentados em volta de uma mesa de feltro, com saldo, quem abre (A), quem dobrou (2x), quem está decidindo e o pote no meio. A cor do feltro (verde, azul, vinho, madeira, couro preto ou roxo) se escolhe em Configurações. Cada celular escolhe o seu visual.

**Comemoração:** quando alguém bate, aparece na tela de todos quem bateu e quanto levou.

**Conexão:** se um celular perder a conexão com o anfitrião, aparece um aviso no topo, que some sozinho quando a conexão volta.

**Modo treino:** na tela inicial, **Treinar com cartas**. O app embaralha 2 baralhos (104 cartas, sem coringa) e dá 9 cartas. Na primeira vez aparecem as regras rápidas (dá para rever no botão de livro).
- **Jogos:** trinca de 3 cartas do mesmo valor com naipes diferentes, ou sequência de 3 cartas seguidas do mesmo naipe (vale A-2-3 e Q-K-A, não vale K-A-2). A carta pega do lixo não volta para o lixo na mesma jogada.
- **Jogar:** toque no monte ou no lixo para comprar. Para descartar, toque na carta e depois no lixo, ou arraste a carta até o lixo. Arraste as cartas na mão para organizar, ou use **Por jogos** (jogos prontos, depois pares, depois soltas), **Naipe** ou **Número**.
- **Bater com o descarte de qualquer um:** se você está pifado e alguém joga a carta que você precisa, aparece **BATER com o X!** por alguns segundos. Os robôs também podem. Se dois puderem, ganha quem é o próximo da vez.
- **Robôs:** 1 a 3, nível fácil, normal, difícil ou mestre (o difícil lembra o que já saiu e evita entregar carta; o mestre também calcula quais cartas ainda podem vir e o que cada um está juntando), cada um com um jeito (equilibrado, arrojado ou cauteloso). Velocidade lenta, normal ou rápida, que dá para trocar no meio da partida. As cartas que eles compram do monte ficam escondidas; o que pegam do lixo aparece.
- **Dicas** (ligue/desligue no meio da partida): cartas que já formam jogo em verde, sugestão de descarte em amarelo, aviso **Pifado!** com as cartas que você espera e quantas cópias ainda podem sair, e o botão Bater piscando quando dá. Com a dica desligada, o botão BATER aparece em todo descarte e é você quem decide.
- **Contador de cartas:** ao tocar numa carta, mostra quantas cópias dela já apareceram.
- **Ver lixo:** mostra as últimas cartas descartadas.
- **Série:** partida única, melhor de 3 ou melhor de 5, com placar no topo.
- **Desafio do dia:** a mesma mão para todo mundo no dia, com meta de compras. Dá para copiar o resultado e mandar para os amigos.
- **Modo aula:** cartas dos robôs abertas para aprender como eles jogam (não conta nas estatísticas).
- **No fim:** os 3 jogos de quem bateu e as mãos dos robôs.
- **Estatísticas, aparência e som:** taxa de vitória, média de compras, vitória mais rápida, sequência e batidas pelo lixo; feltro, verso das cartas (vermelho, azul ou preto) e som/vibração.
- **Pausar:** ao sair, a partida fica salva; na próxima vez aparece **Continuar partida**.
- **Celular deitado:** os robôs vão para a esquerda e a mão fica maior embaixo.

O treino não usa dinheiro e não entra no histórico das mesas.

## 4. Configurações e backup

Na tela inicial, **Configurações e backup**. Os recursos opcionais vêm **desligados** e não mudam nada no jogo até você ligar:

- **Visual** (vale só para o celular onde foi escolhido): Clássico ou Mesa, cor do feltro, tema claro/escuro/automático, letra maior, modo uma mão, confirmar jogadas importantes e brilho na sua vez.
- **Manter a tela ligada** (só no app): a tela não apaga enquanto o app estiver aberto.
- **Aviso de vez** (vale só para o celular onde foi ligado): vibra e toca um bipe quando é a sua vez.
- **Valor padrão:** o valor já vem preenchido no anúncio e no modo solo.
- **Chave Pix no fechamento:** cadastre a chave de cada um; no resultado aparece a chave de quem recebe, com botão de copiar.
- **Enviar imagem direto:** junto do "Salvar imagem" aparece "Enviar", que abre o WhatsApp e outros apps.
- **Estatísticas no histórico:** aba "Recordes" com maior pote, melhor e pior noite, maior sequência de vitórias.

**Backup:** o histórico fica só no celular do anfitrião. **Exportar backup** salva um arquivo em Downloads; **Importar backup** restaura as mesas (as que já existem no celular ficam como estão). Faça um backup antes de trocar de celular ou desinstalar o app.

Se o QR code não abrir nos celulares dos amigos, confira se eles estão mesmo no seu hotspot. Alguns aparelhos isolam quem está no hotspot; nesse caso use um roteador Wi-Fi comum, com todo mundo na mesma rede.

---

## Para quem mexe no código

- `web/` — interface React (a mesma do Pif da Mesa). As regras do jogo ficam em `web/src/lib/engine.ts` e rodam no navegador de quem age. `npm run build` gera um único `dist/index.html`.
- `android/app/src/main/java/com/urs/pifdamesa/PifServer.java` — servidor HTTP sem dependências. Guarda cada sala como JSON com número de versão e recusa (409) quem tentar salvar em cima de uma versão antiga; o navegador então refaz a ação. Também roda no PC para testar: `javac -d out PifServer.java && java -cp out com.urs.pifdamesa.PifServer dados web/dist/index.html 8080`.
- `ServerService.java` — mantém o servidor ligado (serviço em primeiro plano, trava de Wi-Fi e de CPU) e mostra a notificação com o link e o botão Desligar.
- `MainActivity.java` — liga o servidor, abre a mesa numa WebView e desliga tudo ao sair.
- `ImageBridge.java` — salva a imagem da partida na galeria (chamada pela página via `window.PifAndroid`).
- `web/src/extras.tsx` — histórico geral, resultado ao sair, lista de rodadas e imagem da noite.
- `.github/workflows/gerar-apk.yml` — compila a interface, coloca dentro do app e gera o APK.
