package com.urs.pifdamesa;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

/**
 * Tela do app: liga o servidor, abre a mesa numa WebView e desliga tudo ao sair.
 */
public class MainActivity extends Activity {
    public static final String EXTRA_SHUTDOWN = "shutdown";

    private static final int PICK_FILE = 42;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private boolean shuttingDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent().getBooleanExtra(EXTRA_SHUTDOWN, false)) {
            shutdown();
            return;
        }
        getWindow().setStatusBarColor(Color.parseColor("#1B402D"));

        // Tela de abertura: feltro verde com o naipe e o nome do app.
        TextView loading = new TextView(this);
        SpannableStringBuilder brand = new SpannableStringBuilder();
        brand.append("\u2660\n");
        brand.setSpan(new RelativeSizeSpan(3.2f), 0, 1, 0);
        brand.setSpan(new ForegroundColorSpan(Color.parseColor("#E9C46A")), 0, 1, 0);
        int nameStart = brand.length();
        brand.append("Pif da Mesa\n");
        brand.setSpan(new RelativeSizeSpan(1.6f), nameStart, brand.length(), 0);
        brand.setSpan(new StyleSpan(Typeface.BOLD), nameStart, brand.length(), 0);
        int subStart = brand.length();
        brand.append("Ligando a mesa...");
        brand.setSpan(new ForegroundColorSpan(Color.parseColor("#C9DCCB")), subStart, brand.length(), 0);
        loading.setText(brand);
        loading.setGravity(Gravity.CENTER);
        loading.setTextSize(18);
        loading.setLineSpacing(0, 1.15f);
        loading.setTextColor(Color.WHITE);
        loading.setBackgroundColor(Color.parseColor("#1B402D"));
        setContentView(loading);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 1);
        }

        startForegroundService(new Intent(this, ServerService.class));

        new Thread(() -> {
            try {
                PifServer server = ServerService.ensureServer(this);
                runOnUiThread(() -> showTable(server.port()));
            } catch (Exception error) {
                runOnUiThread(() -> loading.setText("Não foi possível ligar a mesa.\n" + error.getMessage()));
            }
        }, "pif-open").start();
    }

    private void showTable(int port) {
        if (shuttingDown || isFinishing()) return;
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#F4F5F1"));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new ImageBridge(this), "PifAndroid");
        // Permite escolher um arquivo (importar backup) dentro do app.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), PICK_FILE);
                    return true;
                } catch (Exception error) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("http://127.0.0.1:" + port + "/");
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getBooleanExtra(EXTRA_SHUTDOWN, false)) shutdown();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("Desligar a mesa?")
            .setMessage("Os amigos vão perder a conexão. As partidas ficam salvas neste celular.")
            .setPositiveButton("Desligar", (dialog, which) -> shutdown())
            .setNegativeButton("Continuar jogando", null)
            .show();
    }

    private void shutdown() {
        if (shuttingDown) return;
        shuttingDown = true;
        stopService(new Intent(this, ServerService.class));
        finishAndRemoveTask();
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) stopService(new Intent(this, ServerService.class));
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
